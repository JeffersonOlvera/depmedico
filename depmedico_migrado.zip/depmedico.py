from flask import Blueprint, json, request, flash, redirect, url_for, render_template, jsonify, session, current_app, send_file
from pydantic import BaseModel, constr, validator, ValidationError
from datetime import datetime
from werkzeug.utils import secure_filename
from werkzeug.exceptions import RequestEntityTooLarge
from functools import wraps
import os
import json
import re
import requests
import pandas as pd
import base64
from typing import Optional 
import fitz #Manipular el PDF
from io import BytesIO
import io
import openpyxl
from openpyxl import Workbook
from PIL import Image
import PIL
from tempfile import NamedTemporaryFile
import urllib3
from openpyxl.drawing.image import Image as ExcelImage


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

depmedico = Blueprint('depmedico', __name__)

# Leer el archivo Excel
excel_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'CIE10.xlsx')
df = pd.read_excel(excel_path)

def base64_to_image(base64_str):
    # Decodifica la cadena base64
    img_data = base64.b64decode(base64_str)
    # Abre la imagen en memoria
    return Image.open(BytesIO(img_data))

def resize_image_base64(image_base64, width, height):
    # Decodifica la imagen base64
    image_data = base64.b64decode(image_base64)
    image = Image.open(io.BytesIO(image_data))
    # Redimensiona la imagen
    image = image.resize((width, height), PIL.Image.LANCZOS)
    # Guarda la imagen redimensionada en un buffer
    buffer = io.BytesIO()
    image.save(buffer, format='PNG')
    return base64.b64encode(buffer.getvalue()).decode('utf-8')

class Form(BaseModel):
    usuario_registro: Optional[str] = None
    ci_colaborador: Optional[str] = None
    nombre_colaborador: Optional[str] = None
    edad: Optional[str] = None
    sexo: Optional[str] = None
    cargo: Optional[str] = None
    tiempo_cargo: Optional[str] = None
    motivo_consulta: Optional[str] = None
    antecep_clinicos: Optional[str] = None
    antecep_quirurgicos: Optional[str] = None
    act_fisica: Optional[str] = None
    act_fisica_obser: Optional[str] = None
    medi_actual: Optional[str] = None
    medi_actual_obser: Optional[str] = None
    alcohol: Optional[str] = None
    alcohol_obser: Optional[str] = None
    tabaco: Optional[str] = None
    tabaco_obser: Optional[str] = None
    otros: Optional[str] = None
    otros_obser: Optional[str] = None
    incidente_trabajo: Optional[str] = None
    accidente_trabajo: Optional[str] = None
    accidente_trabajo_calif: Optional[str] = None
    accidente_trabajo_fecha: Optional[str] = None
    enfermedad_prof: Optional[str] = None
    enfermedad_prof_calif: Optional[str] = None
    enfermedad_prof_fecha: Optional[str] = None
    antecf_cardio_vas: Optional[str] = None
    antecf_metabotica: Optional[str] = None
    antecf_neurologica: Optional[str] = None
    antecf_oncologica: Optional[str] = None
    antecf_infecciosa: Optional[str] = None
    antecf_hereditario: Optional[str] = None
    antecf_observacion: Optional[str] = None
    fact_risg_trabajo_ruido: Optional[str] = None
    fact_risg_trabajo_iluminacion: Optional[str] = None
    fact_risg_trabajo_ventilacion: Optional[str] = None
    fact_risg_trabajo_caidas_mismonivel: Optional[str] = None
    fact_risg_trabajo_atropellamiento_vehi: Optional[str] = None
    fact_risg_trabajo_caidas_desnivel: Optional[str] = None
    fact_risg_trabajo_polvos: Optional[str] = None
    fact_risg_trabajo_liquidos: Optional[str] = None
    fact_risg_trabajo_virus: Optional[str] = None
    fact_risg_trabajo_posturas: Optional[str] = None
    fact_risg_trabajo_mov_repetitivo: Optional[str] = None
    fact_risg_trabajo_monotomia: Optional[str] = None
    fact_risg_trabajo_alta_respo: Optional[str] = None
    fact_risg_trabajo_conflic_rol: Optional[str] = None
    fact_risg_trabajo_sobrecarga_lab: Optional[str] = None
    fact_risg_trabajo_inestabilidad_lab: Optional[str] = None
    fact_risg_trabajo_rela_interp: Optional[str] = None
    sso_salud_mental: Optional[str] = None
    sso_riesgo_lab: Optional[str] = None
    sso_pausas_activas: Optional[str] = None
    inmuni_influenza: Optional[str] = None
    inmuni_tetano: Optional[str] = None
    inmuni_hepatitisB: Optional[str] = None
    inmuni_coviddosis: Optional[str] = None
    organosysis_piel_anexo: Optional[str] = None
    organosysis_genito_urinario: Optional[str] = None
    organosysis_respiratorio: Optional[str] = None
    organosysis_endocrino: Optional[str] = None
    organosysis_digestivo: Optional[str] = None
    organosysis_nervioso: Optional[str] = None
    organosysis_musculo_esqueletico: Optional[str] = None
    organosysis_cardiovascular: Optional[str] = None
    organosysis_hemolinf: Optional[str] = None
    organosysis_orgsentidos: Optional[str] = None
    organosysis_tipo_descripcion: Optional[str] = None
    organosysis_descripcion: Optional[str] = None
    examn_fis_cabeza: Optional[str] = None
    examn_fis_extremidades: Optional[str] = None
    examn_fis_garganta: Optional[str] = None
    examn_fis_ojos: Optional[str] = None
    examn_fis_oidos: Optional[str] = None
    examn_fis_umbilical: Optional[str] = None
    examn_fis_ingual_dere: Optional[str] = None
    examn_fis_clural_dere: Optional[str] = None
    examn_fis_sup_izquierda: Optional[str] = None
    examn_fis_infer_dere: Optional[str] = None
    examn_fis_infer_izquierda: Optional[str] = None
    examn_fis_nariz: Optional[str] = None
    examn_fis_boca: Optional[str] = None
    examn_fis_dentudura: Optional[str] = None
    examn_fis_inguinal_izquierdo: Optional[str] = None
    examn_fis_clural_izq: Optional[str] = None
    examn_fis_reflejos_tndinosos: Optional[str] = None
    examn_fis_corazon: Optional[str] = None
    examn_fis_pulmones: Optional[str] = None
    examn_fis_masas_musculares: Optional[str] = None
    examn_fis_sencibilidad_sup: Optional[str] = None
    examn_fis_reflejos_pupilares: Optional[str] = None
    examn_fis_ojo_derecho: Optional[str] = None
    examn_fis_ojo_izquierdo: Optional[str] = None
    examn_fis_inspeccion: Optional[str] = None
    examn_fis_palpacion: Optional[str] = None
    examn_fis_percsusion: Optional[str] = None
    examn_fis_tracto_urinario: Optional[str] = None
    examn_fis_tracto_genital: Optional[str] = None
    examn_fis_regio_anoperineal: Optional[str] = None
    examn_fis_oido_derecho: Optional[str] = None
    examn_fis_oido_izquierdo: Optional[str] = None
    examn_fis_descripcion: Optional[str] = None
    diagnostico_1: Optional[str] = None
    diagnostico_2: Optional[str] = None
    diagnostico_3: Optional[str] = None
    diagnostico_4: Optional[str] = None
    cie10_1: Optional[str] = None
    cie10_2: Optional[str] = None
    cie10_3: Optional[str] = None
    cie10_4: Optional[str] = None
    def_1: Optional[str] = None
    def_2: Optional[str] = None
    def_3: Optional[str] = None
    def_4: Optional[str] = None
    prest_1: Optional[str] = None
    prest_2: Optional[str] = None
    prest_3: Optional[str] = None
    prest_4: Optional[str] = None
    laboratorio: Optional[str] = None
    rx: Optional[str] = None
    audiometria: Optional[str] = None
    optometria: Optional[str] = None
    ekg: Optional[str] = None
    aptitud: Optional[str] = None
    aptitud_observ: Optional[str] = None
    aptitud_limitacion: Optional[str] = None
    recomendaciones_tto: Optional[str] = None
    firma_colaborador: Optional[str] = None
    fecha: Optional[str] = None
    firmaysello_doc: Optional[str] = None
    estatus: Optional[str] = None

@validator('ci_colaborador')
def validar_cedula(cls, v):
        # Verificar primero si todos los caracteres son dígitos
        if not v.isdigit():
            raise ValueError('El número de cedula debe contener solo dígitos')
        # Luego, verificar la longitud de la cadena
        if len(v) < 10:
            raise ValueError('Son mínimo 10 dígitos')
        elif len(v) > 10:
            raise ValueError('Son máximo 10 dígitos')
        return v
    
class InitialForm(BaseModel):
    cedula: str

@validator('cedula')
def cedula_valida(cls, v):
        # Primero, verificar si la longitud es correcta
        if len(v) < 10:
            raise ValueError('Son mínimo 10 dígitos')
        elif len(v) > 13:
            raise ValueError('Son máximo 13 dígitos')
        elif not re.match(r'^[0-9A-Za-z]+$', v):
            raise ValueError('Ingrese un número de cédula/pasaporte/ruc válido')
        return v
    
@depmedico.route('/autocomplete', methods=['GET'])
def autocomplete():
    query = request.args.get('query', '').lower()
    if not query:
        return jsonify([])

    # Filtrar las enfermedades que contienen la consulta
    filtered_df = df[df['DESCRIPCION'].str.contains(query, case=False, na=False)]
    suggestions = filtered_df[['DESCRIPCION', 'COD_3']].to_dict(orient='records')

    return jsonify(suggestions)

#Valida la cedual en intelisis
@depmedico.route('/validador_mod/<campaign>', methods=['GET', 'POST'])
def validador_formulario(campaign):
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        try:
            cedula = session.get('cedula', 'No disponible')
            payload = {
                "cedula": cedula
            }
            response = requests.post('https://localhost:7220/FormDepMedico/Validar/intelisis', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

            if response.status_code == 201:
                response_text = response.content.decode('utf-8')
                response_data = json.loads(response_text)

                if response_data.get("registro") == "0":
                    flash('No se encontraron registros con el teléfono especificado en el mes actual.', 'warning')
                    return render_template('page_Portabilidad.html', errores={}, form_data={})
                else:
                    flash('El formulario ha sido enviado con éxito. Código de respuesta: 200', 'success')
                    payload = {
                        "cedula": cedula
                    }

                    response = requests.post('https://localhost:7220/FormDepMedico/Cargar/intelisis', json=payload, headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'}, verify=False)

                    if response.status_code == 201:
                        data = response.json()
                        fecha_nacimiento1 = data.get('FechaNacimiento', '')
                        fecha_nacimiento = datetime.strptime(fecha_nacimiento1, "%m/%d/%Y %I:%M:%S %p")
                        fecha_actual = datetime.now()
                        edad = fecha_actual.year - fecha_nacimiento.year
                        if (fecha_actual.month, fecha_actual.day) < (fecha_nacimiento.month, fecha_nacimiento.day):
                            edad -= 1

                        processed_data = {
                            'personal': data.get('Personal', ''),
                            'apellido_paterno': data.get('ApellidoPaterno', ''),
                            'apellido_materno': data.get('ApellidoMaterno', ''),
                            'nombre': session['nombreColaborador'],
                            'edad': edad,
                            'sexo': data.get('Sexo', ''),
                            'estado_civil': data.get('EstadoCivil', ''),
                            'puesto': data.get('Puesto', ''),
                            'estatus': data.get('Estatus', '')
                        }

                        response_third_api = requests.post('https://localhost:7220/FormDepMedico/Cargar/fichaOcupacional', json=payload, headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'}, verify=False)

                        if response_third_api.status_code == 201:
                            response_text_third = response_third_api.content.decode('utf-8')
                            response_data_third = json.loads(response_text_third)

                            if response_data_third.get("Registro") != "0":
                                additional_data = {
                                    'Tiempo_cargo': response_data_third.get('Tiempo_cargo', ''),
                                    'antecep_clinicos': response_data_third.get('antecep_clinicos', ''),
                                    'antecep_quirurgicos': response_data_third.get('antecep_quirurgicos', ''),
                                    'act_fisica_obser': response_data_third.get('act_fisica_obser', ''),
                                    'antecf_cardio_vas': response_data_third.get('antecf_cardio_vas', ''),
                                    'antecf_metabotica': response_data_third.get('antecf_metabotica', ''),
                                    'antecf_neurologica': response_data_third.get('antecf_neurologica', ''),
                                    'antecf_oncologica': response_data_third.get('antecf_oncologica', ''),
                                    'antecf_infecciosa': response_data_third.get('antecf_infecciosa', ''),
                                    'antecf_hereditario': response_data_third.get('antecf_hereditario', '')
                                }
                                processed_data.update(additional_data)


                        else:
                            flash('No se ha proporcionado ninguna firma.', 'error')


                        return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={}, **processed_data)
                    else:
                        flash('Error al enviar datos a la segunda API.', 'error')
                        return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={})
            else:
                flash('Error al enviar datos a la primera API.', 'error')
                return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={})
        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
            return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={})
        except ValidationError as e:
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            return render_template('depmedico/depmedico_formocupacional_colab.html', errores=errores, form_data={})
        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={})
    elif request.method == 'GET' and request.args.get('query'):
        query = request.args.get('query', '').lower()
        if not query:
            return jsonify([])

        filtered_df = df[df['DESCRIPCION'].str.contains(query, case=False, na=False)]
        suggestions = filtered_df[['DESCRIPCION', 'COD_3']].to_dict(orient='records')

        return jsonify(suggestions)

    return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data={}, show_full_form=session.get('show_full_form', False))


# Decorador para proteger rutas según el rol
def role_required(allowed_roles):
    def wrapper(func):
        @wraps(func)
        def decorated_view(*args, **kwargs):
            campaign = kwargs.get('campaign')  # Obtener el parámetro 'campaign' de la URL
            if 'rol' not in session:
                flash('Acceso denegado. Por favor inicie sesión.', 'error')
                error= 'Acceso denegado. Por favor inicie sesión.', 'error'
                # Asegurarse de pasar el valor de 'campaign' en la redirección
                return render_template('error.html', web=error), 403
            if session['rol'] not in allowed_roles:
                flash('No tiene permisos para acceder a esta página.', 'error')
                error= 'Acceso denegado. Por favor inicie sesión.', 'error'
                return render_template('error.html', web=error), 403
            return func(*args, **kwargs)
        return decorated_view
    return wrapper

#=================================== RUTAS
#Rutas Personal Médico

@depmedico.route('/Ocupacionales')
@role_required(['doctora', 'doctora2'])  
def dashboard_ocupacionales():
    return render_template('depmedico/dash_ocupacional.html')

@depmedico.route('/Preocupacionales')
@role_required(['doctora', 'doctora2'])  
def dashboard_preocupacionales():
    return render_template('depmedico/dash_preocupacional.html')

@depmedico.route('/ConsentimientoInformado')
@role_required(['doctora', 'doctora2'])  
def dashboard_consentimiento():
    return render_template('depmedico/dash_consentimiento.html')

@depmedico.route('/CertificadoOcupacional')
@role_required(['doctora', 'doctora2'])  
def dashboard_certificado():
    return render_template('depmedico/dash_certificado.html')

@depmedico.route('/SeguimientoDrogas')
@role_required(['doctora', 'doctora2'])  
def dashboard_seg_drogas():
    return render_template('depmedico/dash_seg_drogas.html')

@depmedico.route('/ConsumoDrogas')
@role_required(['doctora', 'doctora2'])  
def dashboard_cons_drogas():
    return render_template('depmedico/dash_cons_drogas.html')

@depmedico.route('/RegistroOcupacional', methods=['GET', 'POST'])
def registro_ocupacional():    
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
           
            try:
                # Obtener la cédula desde la sesión
                cedula = session.get('cedula', 'No disponible')
                payload = {
                    "cedula": cedula
                }
                print(payload)

                # Solicitud POST a la API con los datos en el cuerpo
                response = requests.post(
                    'https://localhost:7220/FormDepMedico/Cargar/intelisis',  # URL actualizada
                    json=payload,  # Datos enviados como JSON
                    headers={
                        "AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s",  # AuthKey proporcionada
                        "Content-Type": "application/json"  # Content-Type también proporcionado
                    },
                    verify=False  # Ignorar verificación SSL (para localhost)
                )

                # Imprimir el estado de la respuesta y el cuerpo
                print(f'Status Code: {response.status_code}')
                print(f'Response Body: {response.text}')

                if response.status_code == 201:
                    datos = response.json()
                    fecha_ingreso = datos.get('FechaAntiguedad')  # Obtener la fecha de antigüedad
                    print(fecha_ingreso)

                    año_actual = datetime.now().year
                    print(año_actual)
                    # Construir la fecha límite con el año actual y el 31 de diciembre
                    fecha_tope = datetime.strptime(f'{año_actual}-12-31', '%Y-%m-%d')
                    
                    #De prueba
                    #fecha_tope = datetime.strptime( '2020-12-31', '%Y-%m-%d')

                    if fecha_ingreso:
                        # Convertir la fecha recibida de la API con el formato adecuado
                        fecha_ingreso_dt = datetime.strptime(fecha_ingreso, '%m/%d/%Y %I:%M:%S %p')

                        # Validar si la fecha de ingreso es anterior o igual a la fecha tope
                        if fecha_ingreso_dt <= fecha_tope:
                            print('ocupacional')
                            return render_template('depmedico/form_ocupacional_colab.html')
                        else:
                            flash(f'Su fecha de ingreso no le permite acceder. Fecha de ingreso: {fecha_ingreso}')
                            return render_template('depmedico/depmedico_colaborador.html')
                else:
                    flash('Error al obtener los datos de la API.')
                    return render_template('depmedico/depmedico_colaborador.html')

            except Exception as e:
                flash(f'Ocurrió un error: {e}.')
                return render_template('depmedico/depmedico_colaborador.html')
    else:
        return render_template('depmedico/depmedico_colaborador.html')

@depmedico.route('/RegistroPreocupacional', methods=['GET', 'POST'])
def registro_preocupacional():    
    form_data={}
    errores={}
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
        return render_template('depmedico/form_preocupacional.html', form_data=form_data, errores=errores)
        
    else:
        return render_template('depmedico/depmedico_colaborador.html')

@depmedico.route('/RegistroSeguimientoDrogas', methods=['GET', 'POST'])
def registro_seguimiento_drogas_drogas():    
    form_data={}
    errores={}
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
        return render_template('depmedico/form_segdrogas.html', form_data=form_data, errores=errores)
        
    else:
        return render_template('depmedico/depmedico_colaborador.html')

@depmedico.route('/RegistroConsumoDrogas', methods=['GET', 'POST'])
def registro_consumo_drogas():    
    form_data={}
    errores={}
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
        return render_template('depmedico/form_drogas.html', form_data=form_data, errores=errores)
    else:
        return render_template('depmedico/depmedico_colaborador.html')

@depmedico.route('/RegistroConsentimiento', methods=['GET', 'POST'])
def registro_consentimiento():    
    form_data={}
    errores={}
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
        return render_template('depmedico/form_consentimiento.html', form_data=form_data, errores=errores)
    else:
        return render_template('depmedico/depmedico_colaborador.html')

@depmedico.route('/RegistroCertificado', methods=['GET', 'POST'])
def registro_certificado():    
    form_data={}
    errores={}
    if request.method == 'GET':  # Mantén el método GET, pero haz la solicitud POST a la API
        return render_template('depmedico/form_certificado.html', form_data=form_data, errores=errores)
    else:
        return render_template('depmedico/depmedico_colaborador.html')

#Rutas colaborador
@depmedico.route('/colaborador')
def page_colaborador():
    # return render_template('depmedico/depmedico_colaborador.html')
    return render_template('login_externo.html')

#Otras rutas
@depmedico.route('/formulario_error')
def formulario_error():
    return render_template('formulario_error.html')

@depmedico.route('/<campaign>/formulario_success')
def formulario_success(campaign):
    return render_template('depmedico/depmedico_success_colab.html', campaign=campaign)

@depmedico.route('/<campaign>/logout')
def logout(campaign):
    # Recuperar el nombre de la campaña desde la sesión
    session.clear()  # Limpia la sesión completamente
    return redirect(url_for('login', campaign=campaign))


@depmedico.route('/')
def menu_principal():
    if 'usuario_autenticado' in session:
        if session.get('rol') == 'doctora2':
            return render_template('depmedico/dash_preocupacional.html')  # Redirigir a dash_preocupacional
        elif session.get('rol') == 'doctora':
            return render_template('depmedico/dash_ocupacional.html')
        else:
            return render_template('depmedico/depmedico_colaborador.html')
    else:
        return render_template('depmedico/depmedico_colaborador.html') # Redirigir al login si no está autenticado

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN OCUPACIONAL
#Recuperar información con la cedula y mostrarla en el formulario del doctor
@depmedico.route('/FichasPreocupacionesMedico', methods=['POST'])
def registro_preocupacional_doc():

    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaOcupacional',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict
                
                # Extrae datos de la respuesta
                ci_colaborador = response_data.get('Ci_colaborador', '')
                nombre_colaborador = response_data.get('Nombre_colaborador', '')
                edad = response_data.get('Edad', '')
                sexo = response_data.get('Sexo', '')
                cargo = response_data.get('Cargo', '')
                tiempo_cargo = response_data.get('Tiempo_cargo', '')
                antecep_clinicos = response_data.get('antecep_clinicos', '')
                antecep_quirurgicos = response_data.get('antecep_quirurgicos', '')
                act_fisica = response_data.get('act_fisica', '')
                act_fisica_obser = response_data.get('act_fisica_obser', '')
                medi_actual = response_data.get('medi_actual', '')
                medi_actual_obser = response_data.get('medi_actual_obser', '')
                alcohol = response_data.get('alcohol', '')
                alcohol_obser = response_data.get('alcohol_obser', '')
                tabaco = response_data.get('tabaco', '')
                tabaco_obser = response_data.get('tabaco_obser', '')
                otros = response_data.get('otros', '')
                otros_obser = response_data.get('otros_obser', '')
                incidente_trabajo = response_data.get('incidente_trabajo', '')
                accidente_trabajo = response_data.get('accidente_trabajo', '')
                accidente_trabajo_calif = response_data.get('accidente_trabajo_calif', '')
                accidente_trabajo_fecha = response_data.get('accidente_trabajo_fecha', '')
                enfermedad_prof = response_data.get('enfermedad_prof', '')
                enfermedad_prof_calif = response_data.get('enfermedad_prof_calif', '')
                enfermedad_prof_fecha = response_data.get('enfermedad_prof_fecha', '')
                antecf_cardio_vas = response_data.get('antecf_cardio_vas', '')
                antecf_metabotica = response_data.get('antecf_metabotica', '')
                antecf_neurologica = response_data.get('antecf_neurologica', '')
                antecf_oncologica = response_data.get('antecf_oncologica', '')
                antecf_infecciosa = response_data.get('antecf_infecciosa', '')
                antecf_hereditario = response_data.get('antecf_hereditario', '')
                antecf_observacion = response_data.get('antecf_observacion', '')
                inmuni_influenza = response_data.get('inmuni_influenza', '')
                inmuni_tetano = response_data.get('inmuni_tetano', '')
                inmuni_hepatitisB = response_data.get('inmuni_hepatitisB', '')
                inmuni_coviddosis = response_data.get('inmuni_coviddosis', '')
                fact_risg_trabajo_ruido = response_data.get('fact_risg_trabajo_ruido', '')
                fact_risg_trabajo_iluminacion = response_data.get('fact_risg_trabajo_iluminacion', '')
                fact_risg_trabajo_ventilacion = response_data.get('fact_risg_trabajo_ventilacion', '')
                fact_risg_trabajo_caidas_mismonivel = response_data.get('fact_risg_trabajo_caidas_mismonivel', '')
                fact_risg_trabajo_atropellamiento_vehi = response_data.get('fact_risg_trabajo_atropellamiento_vehi', '')
                fact_risg_trabajo_caidas_desnivel = response_data.get('fact_risg_trabajo_caidas_desnivel', '')
                fact_risg_trabajo_polvos = response_data.get('fact_risg_trabajo_polvos', '')
                fact_risg_trabajo_liquidos = response_data.get('fact_risg_trabajo_liquidos', '')
                fact_risg_trabajo_virus = response_data.get('fact_risg_trabajo_virus', '')
                fact_risg_trabajo_posturas = response_data.get('fact_risg_trabajo_posturas', '')
                fact_risg_trabajo_mov_repetitivo = response_data.get('fact_risg_trabajo_mov_repetitivo', '')
                fact_risg_trabajo_monotomia = response_data.get('fact_risg_trabajo_monotomia', '')
                fact_risg_trabajo_alta_respo = response_data.get('fact_risg_trabajo_alta_respo', '')
                fact_risg_trabajo_conflic_rol = response_data.get('fact_risg_trabajo_conflic_rol', '')
                fact_risg_trabajo_sobrecarga_lab = response_data.get('fact_risg_trabajo_sobrecarga_lab', '')
                fact_risg_trabajo_inestabilidad_lab = response_data.get('fact_risg_trabajo_inestabilidad_lab', '')
                fact_risg_trabajo_rela_interp = response_data.get('fact_risg_trabajo_rela_interp', '')

                sso_salud_mental = response_data.get('sso_salud_mental', '')
                sso_riesgo_lab = response_data.get('sso_riesgo_lab', '')
                sso_pausas_activas = response_data.get('sso_pausas_activas', '')
                organosysis_piel_anexo = response_data.get('organosysis_piel_anexo', '')
                organosysis_genito_urinario = response_data.get('organosysis_genito_urinario', '')
                organosysis_respiratorio = response_data.get('organosysis_respiratorio', '')
                organosysis_endocrino = response_data.get('organosysis_endocrino', '')
                organosysis_digestivo = response_data.get('organosysis_digestivo', '')
                organosysis_nervioso = response_data.get('organosysis_nervioso', '')
                organosysis_musculo_esqueletico = response_data.get('organosysis_musculo_esqueletico', '')
                organosysis_cardiovascular = response_data.get('organosysis_cardiovascular', '')
                organosysis_hemolinf = response_data.get('organosysis_hemolinf', '')
                organosysis_orgsentidos = response_data.get('organosysis_orgsentidos', '')
                organosysis_descripcion = response_data.get('organosysis_descripcion', '')
                examn_fis_cabeza = response_data.get('examn_fis_cabeza', '')
                examn_fis_extremidades = response_data.get('examn_fis_extremidades', '')
                examn_fis_garganta = response_data.get('examn_fis_garganta', '')
                examn_fis_ojos = response_data.get('examn_fis_ojos', '')
                examn_fis_oidos = response_data.get('examn_fis_oidos', '')
                examn_fis_umbilical = response_data.get('examn_fis_umbilical', '')
                examn_fis_ingual_dere = response_data.get('examn_fis_ingual_dere', '')
                examn_fis_clural_dere = response_data.get('examn_fis_clural_dere', '')
                examn_fis_sup_izquierda = response_data.get('examn_fis_sup_izquierda', '')
                examn_fis_infer_dere = response_data.get('examn_fis_infer_dere', '')
                examn_fis_infer_izquierda = response_data.get('examn_fis_infer_izquierda', '')
                examn_fis_nariz = response_data.get('examn_fis_nariz', '')
                examn_fis_boca = response_data.get('examn_fis_boca', '')
                examn_fis_dentudura = response_data.get('examn_fis_dentudura', '')
                examn_fis_inguinal_izquierdo = response_data.get('examn_fis_inguinal_izquierdo', '')
                examn_fis_clural_izq = response_data.get('examn_fis_clural_izq', '')
                examn_fis_reflejos_tndinosos = response_data.get('examn_fis_reflejos_tndinosos', '')
                examn_fis_corazon = response_data.get('examn_fis_corazon', '')
                examn_fis_pulmones = response_data.get('examn_fis_pulmones', '')
                examn_fis_masas_musculares = response_data.get('examn_fis_masas_musculares', '')
                examn_fis_sencibilidad_sup = response_data.get('examn_fis_sencibilidad_sup', '')
                examn_fis_reflejos_pupilares = response_data.get('examn_fis_reflejos_pupilares', '')
                examn_fis_ojo_derecho = response_data.get('examn_fis_ojo_derecho', '')
                examn_fis_ojo_izquierdo = response_data.get('examn_fis_ojo_izquierdo', '')
                examn_fis_inspeccion = response_data.get('examn_fis_inspeccion', '')
                examn_fis_palpacion = response_data.get('examn_fis_palpacion', '')
                examn_fis_percsusion = response_data.get('examn_fis_percsusion', '')
                examn_fis_tracto_urinario = response_data.get('examn_fis_tracto_urinario', '')
                examn_fis_tracto_genital = response_data.get('examn_fis_tracto_genital', '')
                examn_fis_regio_anoperineal = response_data.get('examn_fis_regio_anoperineal', '')
                examn_fis_oido_derecho = response_data.get('examn_fis_oido_derecho', '')
                examn_fis_oido_izquierdo = response_data.get('examn_fis_oido_izquierdo', '')
                examn_fis_descripcion = response_data.get('examn_fis_descripcion', '')
                examn_fis_movilidad = response_data.get('examn_fis_movilidad', '')
                examn_fis_deformaciones = response_data.get('examn_fis_deformaciones', '')
                diagnostico_1 = response_data.get('diagnostico_1', '')
                diagnostico_2 = response_data.get('diagnostico_2', '')
                diagnostico_3 = response_data.get('diagnostico_3', '')
                diagnostico_4 = response_data.get('diagnostico_4', '')
                cie10_1 = response_data.get('cie10_1', '')
                cie10_2 = response_data.get('cie10_2', '')
                cie10_3 = response_data.get('cie10_3', '')
                cie10_4 = response_data.get('cie10_4', '')
                laboratorio = response_data.get('laboratorio', '')
                rx = response_data.get('rx', '')
                audiometria = response_data.get('audiometria', '')
                optometria = response_data.get('optometria', '')
                ekg = response_data.get('ekg', '')

                aptitud = response_data.get('aptitud', '')
                aptitud_observ = response_data.get('aptitud_observ', '')
                aptitud_limitacion = response_data.get('aptitud_limitacion', '')
                recomendaciones_tto = response_data.get('recomendaciones_tto', '')

                data = {
                    'ci_colaborador': ci_colaborador,
                    'nombre_colaborador': nombre_colaborador,
                    'edad': edad,
                    'sexo': sexo,
                    'cargo': cargo,
                    'tiempo_cargo': tiempo_cargo,
                    'motivo_consulta': 'FMO',
                    'antecep_clinicos': antecep_clinicos,
                    'antecep_quirurgicos': antecep_quirurgicos,
                    'act_fisica': act_fisica,
                    'act_fisica_obser': act_fisica_obser,
                    'medi_actual': medi_actual,
                    'medi_actual_obser': medi_actual_obser,
                    'alcohol': alcohol,
                    'alcohol_obser': alcohol_obser,
                    'tabaco': tabaco,
                    'tabaco_obser': tabaco_obser,
                    'otros': otros,
                    'otros_obser': otros_obser,
                    'incidente_trabajo': incidente_trabajo,
                    'accidente_trabajo': accidente_trabajo,
                    'accidente_trabajo_calif': accidente_trabajo_calif,
                    'accidente_trabajo_fecha': accidente_trabajo_fecha,
                    'enfermedad_prof': enfermedad_prof,
                    'enfermedad_prof_calif': enfermedad_prof_calif,
                    'enfermedad_prof_fecha': enfermedad_prof_fecha,
                    'antecf_cardio_vas': antecf_cardio_vas,
                    'antecf_metabotica': antecf_metabotica,
                    'antecf_neurologica': antecf_neurologica,
                    'antecf_oncologica': antecf_oncologica,
                    'antecf_infecciosa': antecf_infecciosa,
                    'antecf_hereditario': antecf_hereditario,
                    'antecf_observacion': antecf_observacion,
                    'inmuni_influenza': inmuni_influenza,
                    'inmuni_tetano': inmuni_tetano,
                    'inmuni_hepatitisB': inmuni_hepatitisB,
                    'inmuni_coviddosis': inmuni_coviddosis,
                    'fact_risg_trabajo_ruido': fact_risg_trabajo_ruido,
                    'fact_risg_trabajo_iluminacion': fact_risg_trabajo_iluminacion,
                    'fact_risg_trabajo_ventilacion': fact_risg_trabajo_ventilacion,
                    'fact_risg_trabajo_caidas_mismonivel': fact_risg_trabajo_caidas_mismonivel,
                    'fact_risg_trabajo_atropellamiento_vehi': fact_risg_trabajo_atropellamiento_vehi,
                    'fact_risg_trabajo_caidas_desnivel': fact_risg_trabajo_caidas_desnivel,
                    'fact_risg_trabajo_polvos': fact_risg_trabajo_polvos,
                    'fact_risg_trabajo_liquidos': fact_risg_trabajo_liquidos,
                    'fact_risg_trabajo_virus': fact_risg_trabajo_virus,
                    'fact_risg_trabajo_posturas': fact_risg_trabajo_posturas,
                    'fact_risg_trabajo_mov_repetitivo': fact_risg_trabajo_mov_repetitivo,
                    'fact_risg_trabajo_monotomia': fact_risg_trabajo_monotomia,
                    'fact_risg_trabajo_alta_respo': fact_risg_trabajo_alta_respo,
                    'fact_risg_trabajo_conflic_rol': fact_risg_trabajo_conflic_rol,
                    'fact_risg_trabajo_sobrecarga_lab': fact_risg_trabajo_sobrecarga_lab,
                    'fact_risg_trabajo_inestabilidad_lab': fact_risg_trabajo_inestabilidad_lab,
                    'fact_risg_trabajo_rela_interp': fact_risg_trabajo_rela_interp,
                    'sso_salud_mental': sso_salud_mental,
                    'sso_riesgo_lab': sso_riesgo_lab,
                    'sso_pausas_activas': sso_pausas_activas,
                    'organosysis_piel_anexo': organosysis_piel_anexo,
                    'organosysis_genito_urinario': organosysis_genito_urinario,
                    'organosysis_respiratorio': organosysis_respiratorio,
                    'organosysis_endocrino': organosysis_endocrino,
                    'organosysis_digestivo': organosysis_digestivo,
                    'organosysis_nervioso': organosysis_nervioso,
                    'organosysis_musculo_esqueletico': organosysis_musculo_esqueletico,
                    'organosysis_cardiovascular': organosysis_cardiovascular,
                    'organosysis_hemolinf': organosysis_hemolinf,
                    'organosysis_orgsentidos': organosysis_orgsentidos,
                    'organosysis_descripcion': organosysis_descripcion,
                    'examn_fis_cabeza': examn_fis_cabeza,
                    'examn_fis_extremidades': examn_fis_extremidades,
                    'examn_fis_garganta': examn_fis_garganta,
                    'examn_fis_ojos': examn_fis_ojos,
                    'examn_fis_oidos': examn_fis_oidos,
                    'examn_fis_umbilical': examn_fis_umbilical,
                    'examn_fis_ingual_dere': examn_fis_ingual_dere,
                    'examn_fis_clural_dere': examn_fis_clural_dere,
                    'examn_fis_sup_izquierda': examn_fis_sup_izquierda,
                    'examn_fis_infer_dere': examn_fis_infer_dere,
                    'examn_fis_infer_izquierda': examn_fis_infer_izquierda,
                    'examn_fis_nariz': examn_fis_nariz,
                    'examn_fis_boca': examn_fis_boca,
                    'examn_fis_dentudura': examn_fis_dentudura,
                    'examn_fis_inguinal_izquierdo': examn_fis_inguinal_izquierdo,
                    'examn_fis_clural_izq': examn_fis_clural_izq,
                    'examn_fis_reflejos_tndinosos': examn_fis_reflejos_tndinosos,
                    'examn_fis_corazon': examn_fis_corazon,
                    'examn_fis_pulmones': examn_fis_pulmones,
                    'examn_fis_masas_musculares': examn_fis_masas_musculares,
                    'examn_fis_sencibilidad_sup': examn_fis_sencibilidad_sup,
                    'examn_fis_reflejos_pupilares': examn_fis_reflejos_pupilares,
                    'examn_fis_ojo_derecho': examn_fis_ojo_derecho,
                    'examn_fis_ojo_izquierdo': examn_fis_ojo_izquierdo,
                    'examn_fis_inspeccion': examn_fis_inspeccion,
                    'examn_fis_palpacion': examn_fis_palpacion,
                    'examn_fis_percsusion': examn_fis_percsusion,
                    'examn_fis_tracto_urinario': examn_fis_tracto_urinario,
                    'examn_fis_tracto_genital': examn_fis_tracto_genital,
                    'examn_fis_regio_anoperineal': examn_fis_regio_anoperineal,
                    'examn_fis_oido_derecho': examn_fis_oido_derecho,
                    'examn_fis_oido_izquierdo': examn_fis_oido_izquierdo,
                    'examn_fis_descripcion': examn_fis_descripcion,
                    'examn_fis_movilidad': examn_fis_movilidad,
                    'examn_fis_deformaciones': examn_fis_deformaciones,
                    'diagnostico_1': diagnostico_1,
                    'diagnostico_2': diagnostico_2,
                    'diagnostico_3': diagnostico_3,
                    'diagnostico_4': diagnostico_4,
                    'cie10_1': cie10_1,
                    'cie10_2': cie10_2,
                    'cie10_3': cie10_3,
                    'cie10_4': cie10_4,
                    'laboratorio': laboratorio,
                    'rx': rx,
                    'audiometria': audiometria,
                    'optometria': optometria,
                    'ekg': ekg,

                    'aptitud': aptitud,
                    'aptitud_observ': aptitud_observ,
                    'aptitud_limitacion': aptitud_limitacion,
                    'recomendaciones_tto': recomendaciones_tto
                }


                print('Datos obtenidos para enviar al formulario', data)
                print('fecha:', data.get('fecha'))
                # Redirige a la página para mostrar los datos
                return render_template('depmedico/depmedico_formocupacional_doc.html', errores={}, form_data=data)

            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/depmedico_formocupacional_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/depmedico_formocupacional_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/depmedico_formocupacional_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_preocupacional.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_preocupacional.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_preocupacional.html')

#Guardar la información del formulario del colaborador
@depmedico.route('/procesar_formulario_colaborador', methods=['GET', 'POST'])
def procesar_formulario_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)
            form_data_converted = form_data.copy()  # Copiar para modificar las fechas
  
            upgrade_form = Form(**form_data_converted)
            print("Formulario validado con Pydantic.")  # Diagnóstico

            payload = {
                "usuario_registro": '',
                "estatus": 'Pendiente',
                "ci_colaborador": form_data.get('ci_colaborador', None),
                "nombre_colaborador": form_data.get('nombre_colaborador').strip().upper(),
                "edad": form_data.get('edad', None),
                "sexo": form_data.get('sexo', None),
                "cargo": form_data.get('cargo', None),
                "tiempo_cargo": form_data.get('tiempo_cargo', None),
                #"motivo_consulta": form_data.get('motivo_consulta', None),  # Descomentado si es necesario
                "antecep_clinicos": form_data.get('antecep_clinicos', None),
                "antecep_quirurgicos": form_data.get('antecep_quirurgicos', None),
                "act_fisica": form_data.get('act_fisica', None),
                "act_fisica_obser": form_data.get('act_fisica_obser', None),
                "medi_actual": form_data.get('medi_actual', None),
                "medi_actual_obser": form_data.get('medi_actual_obser', None),
                "alcohol": form_data.get('alcohol', None),
                "alcohol_obser": form_data.get('alcohol_obser', None),
                "tabaco": form_data.get('tabaco', None),
                "tabaco_obser": form_data.get('tabaco_obser', None),
                "otros": form_data.get('otros', None),
                "otros_obser": form_data.get('otros_obser', None),
                "incidente_trabajo": form_data.get('incidente_trabajo', None),
                "accidente_trabajo": form_data.get('accidente_trabajo', None),
                "accidente_trabajo_calif": form_data.get('accidente_trabajo_calif', None),
                "accidente_trabajo_fecha": form_data.get('accidente_trabajo_fecha', 0000-00-00),
                "enfermedad_prof": form_data.get('enfermedad_prof', None),
                "enfermedad_prof_calif": form_data.get('enfermedad_prof_calif', None),
                "enfermedad_prof_fecha": form_data.get('enfermedad_prof_fecha', 0000-00-00),
                "antecf_cardio_vas": form_data.get('antecf_cardio_vas', None),
                "antecf_metabotica": form_data.get('antecf_metabotica', None),
                "antecf_neurologica": form_data.get('antecf_neurologica', None),
                "antecf_oncologica": form_data.get('antecf_oncologica', None),
                "antecf_infecciosa": form_data.get('antecf_infecciosa', None),
                "antecf_hereditario": form_data.get('antecf_hereditario', None),
                "antecf_observacion": form_data.get('antecf_observacion', None),
                "inmuni_influenza": form_data.get('inmuni_influenza', None),
                "inmuni_tetano": form_data.get('inmuni_tetano', None),
                "inmuni_hepatitisB": form_data.get('inmuni_hepatitisB', None),
                "inmuni_coviddosis": form_data.get('inmuni_coviddosis', None),
                "firma_colaborador": form_data.get('firma_colaborador', None),
                "fecha": form_data.get('fecha', None)
                 
            }


            print("Payload:", payload)  # Diagnóstico
            print("PRUEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
            print(payload)
            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaOcupacional', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/depmedico_formocupacional_colab.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/depmedico_formocupacional_colab.html', errores={}, form_data=form_data)

#Guardar la informacion del formulario del medico y actualizar la información
@depmedico.route('/procesar_formulario_medico', methods=['GET', 'POST'])
def procesar_formulario_medico():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}
       
        
        try:
            print("Datos recibidos del formulario:", form_data)

            if request.method == 'POST':
                

                payload = {
                            
                    "usuario_actualizacion": 'ADMIN',
                    "ci_colaborador": form_data.get('ci_colaborador',''),
                    "nombre_colaborador": form_data.get('nombre_colaborador'),
                    "edad":  form_data.get('edad',''),
                    "sexo": form_data.get('sexo',''),
                    "cargo": form_data.get('cargo',''),
                    "tiempo_cargo": form_data.get('tiempo_cargo',''),
                    "motivo_consulta": 'FMO',
                    "antecep_clinicos": form_data.get('antecep_clinicos',''),
                    "antecep_quirurgicos": form_data.get('antecep_quirurgicos',''),
                    "act_fisica": form_data.get('act_fisica',''),
                    "act_fisica_obser": form_data.get('act_fisica_obser',''),
                    "medi_actual": form_data.get('medi_actual',''),
                    "medi_actual_obser": form_data.get('medi_actual_obser',''),
                    "alcohol": form_data.get('alcohol',''),
                    "alcohol_obser": form_data.get('alcohol_obser',''),
                    "tabaco": form_data.get('tabaco',''),
                    "tabaco_obser": form_data.get('tabaco_obser',''),
                    "otros": form_data.get('otros',''),
                    "otros_obser": form_data.get('otros_obser',''),
                    "incidente_trabajo": form_data.get('incidente_trabajo',''),
                    "accidente_trabajo": form_data.get('accidente_trabajo',''),
                    "accidente_trabajo_calif": form_data.get('accidente_trabajo_calif',''),
                    "accidente_trabajo_fecha": form_data.get('accidente_trabajo_fecha'),
                    "enfermedad_prof": form_data.get('enfermedad_prof',''),
                    "enfermedad_prof_calif": form_data.get('enfermedad_prof_calif',''),
                    "enfermedad_prof_fecha": form_data.get('enfermedad_prof_fecha'),

                    "antecf_cardio_vas": form_data.get('antecf_cardio_vas',''),
                    "antecf_metabotica": form_data.get('antecf_metabotica',''),
                    "antecf_neurologica": form_data.get('antecf_neurologica',''),
                    "antecf_oncologica": form_data.get('antecf_oncologica',''),
                    "antecf_infecciosa": form_data.get('antecf_infecciosa',''),
                    "antecf_hereditario": form_data.get('antecf_hereditario',''),
                    "antecf_observacion": form_data.get('antecf_observacion',''),
                    
                    "fact_risg_trabajo_ruido": form_data.get('fact_risg_trabajo_ruido',''),
                    "fact_risg_trabajo_iluminacion": form_data.get('fact_risg_trabajo_iluminacion',''),
                    "fact_risg_trabajo_ventilacion": form_data.get('fact_risg_trabajo_ventilacion',''),
                    "fact_risg_trabajo_caidas_mismonivel": form_data.get('fact_risg_trabajo_caidas_mismonivel',''),
                    "fact_risg_trabajo_atropellamiento_vehi": form_data.get('fact_risg_trabajo_atropellamiento_vehi',''),
                    "fact_risg_trabajo_caidas_desnivel": form_data.get('fact_risg_trabajo_caidas_desnivel',''),
                    "fact_risg_trabajo_polvos": form_data.get('fact_risg_trabajo_polvos',''),
                    "fact_risg_trabajo_liquidos": form_data.get('fact_risg_trabajo_liquidos',''),
                    "fact_risg_trabajo_virus": form_data.get('fact_risg_trabajo_virus',''),
                    "fact_risg_trabajo_posturas": form_data.get('fact_risg_trabajo_posturas',''),
                    "fact_risg_trabajo_mov_repetitivo": form_data.get('fact_risg_trabajo_mov_repetitivo',''),
                    "fact_risg_trabajo_monotomia": form_data.get('fact_risg_trabajo_monotomia',''),
                    "fact_risg_trabajo_alta_respo": form_data.get('fact_risg_trabajo_alta_respo',''),
                    "fact_risg_trabajo_conflic_rol": form_data.get('fact_risg_trabajo_conflic_rol',''),
                    "fact_risg_trabajo_sobrecarga_lab": form_data.get('fact_risg_trabajo_sobrecarga_lab',''),
                    "fact_risg_trabajo_inestabilidad_lab": form_data.get('fact_risg_trabajo_inestabilidad_lab',''),
                    "fact_risg_trabajo_rela_interp": form_data.get('fact_risg_trabajo_rela_interp',''),
                    "sso_salud_mental": form_data.get('sso_salud_mental',''),
                    "sso_riesgo_lab": form_data.get('sso_riesgo_lab',''),
                    "sso_pausas_activas": form_data.get('sso_pausas_activas',''),
                    
                    "inmuni_influenza": form_data.get('inmuni_influenza',''),
                    "inmuni_tetano": form_data.get('inmuni_tetano',''),
                    "inmuni_hepatitisB": form_data.get('inmuni_hepatitisB',''),
                    "inmuni_coviddosis": form_data.get('inmuni_coviddosis',''),
                    
                    "organosysis_piel_anexo": form_data.get('organosysis_piel_anexo',''),
                    "organosysis_genito_urinario": form_data.get('organosysis_genito_urinario',''),
                    "organosysis_respiratorio": form_data.get('organosysis_respiratorio',''),
                    "organosysis_endocrino": form_data.get('organosysis_endocrino',''),
                    "organosysis_digestivo": form_data.get('organosysis_digestivo',''),
                    "organosysis_nervioso": form_data.get('organosysis_nervioso',''),
                    "organosysis_musculo_esqueletico": form_data.get('organosysis_musculo_esqueletico',''),
                    "organosysis_cardiovascular": form_data.get('organosysis_cardiovascular',''),
                    "organosysis_hemolinf": form_data.get('organosysis_hemolinf',''),
                    "organosysis_orgsentidos": form_data.get('organosysis_orgsentidos',''),
                    "organosysis_tipo_descripcion": form_data.get('organosysis_tipo_descripcion',''),
                    "organosysis_descripcion": form_data.get('organosysis_descripcion',''),
                    "examn_fis_cabeza": form_data.get('examn_fis_cabeza',''),
                    "examn_fis_extremidades": form_data.get('examn_fis_extremidades',''),
                    "examn_fis_garganta": form_data.get('examn_fis_garganta',''),
                    "examn_fis_ojos": form_data.get('examn_fis_ojos',''),
                    "examn_fis_oidos": form_data.get('examn_fis_oidos',''),
                    "examn_fis_umbilical": form_data.get('examn_fis_umbilical',''),
                    "examn_fis_ingual_dere": form_data.get('examn_fis_ingual_dere',''),
                    "examn_fis_clural_dere": form_data.get('examn_fis_clural_dere',''),
                    "examn_fis_sup_izquierda": form_data.get('examn_fis_sup_izquierda',''),
                    "examn_fis_infer_dere": form_data.get('examn_fis_infer_dere',''),
                    "examn_fis_infer_izquierda": form_data.get('examn_fis_infer_izquierda',''),
                    "examn_fis_nariz": form_data.get('examn_fis_nariz',''),
                    "examn_fis_movilidad": form_data.get('examn_fis_movilidad',''),
                    "examn_fis_deformaciones": form_data.get('examn_fis_deformaciones',''),

                    "examn_fis_boca": form_data.get('examn_fis_boca',''),
                    "examn_fis_dentudura": form_data.get('examn_fis_dentudura',''),
                    "examn_fis_inguinal_izquierdo": form_data.get('examn_fis_inguinal_izquierdo',''),
                    "examn_fis_clural_izq": form_data.get('examn_fis_clural_izq',''),
                    "examn_fis_reflejos_tndinosos": form_data.get('examn_fis_reflejos_tndinosos',''),
                    "examn_fis_corazon": form_data.get('examn_fis_corazon',''),
                    "examn_fis_pulmones": form_data.get('examn_fis_pulmones',''),
                    "examn_fis_masas_musculares": form_data.get('examn_fis_masas_musculares',''),
                    "examn_fis_sencibilidad_sup": form_data.get('examn_fis_sencibilidad_sup',''),
                    "examn_fis_reflejos_pupilares": form_data.get('examn_fis_reflejos_pupilares',''),
                    "examn_fis_ojo_derecho": form_data.get('examn_fis_ojo_derecho',''),
                    "examn_fis_ojo_izquierdo": form_data.get('examn_fis_ojo_izquierdo',''),
                    "examn_fis_inspeccion": form_data.get('examn_fis_inspeccion',''),
                    "examn_fis_palpacion": form_data.get('examn_fis_palpacion',''),
                    "examn_fis_percsusion": form_data.get('examn_fis_percsusion',''),
                    "examn_fis_tracto_urinario": form_data.get('examn_fis_tracto_urinario',''),
                    "examn_fis_tracto_genital": form_data.get('examn_fis_tracto_genital',''),
                    "examn_fis_regio_anoperineal": form_data.get('examn_fis_regio_anoperineal',''),
                    "examn_fis_oido_derecho": form_data.get('examn_fis_oido_derecho',''),
                    "examn_fis_oido_izquierdo": form_data.get('examn_fis_oido_izquierdo',''),
                    "examn_fis_descripcion": form_data.get('examn_fis_descripcion',''),
                    "diagnostico_1": form_data.get('diagnostico_1',''),
                    "diagnostico_2": form_data.get('diagnostico_2',''),
                    "diagnostico_3": form_data.get('diagnostico_3',''),
                    "diagnostico_4": form_data.get('diagnostico_4',''),
                    "cie10_1": form_data.get('cie10_1',''),
                    "cie10_2": form_data.get('cie10_2',''),
                    "cie10_3": form_data.get('cie10_3',''),
                    "cie10_4": form_data.get('cie10_4',''),
                    "def_1": form_data.get('def_1',''),
                    "def_2": form_data.get('def_2',''),
                    "def_3": form_data.get('def_3',''),
                    "def_4": form_data.get('def_4',''),
                    "prest_1": form_data.get('prest_1',''),
                    "prest_2": form_data.get('prest_2',''),
                    "prest_3": form_data.get('prest_3',''),
                    "prest_4": form_data.get('prest_4',''),
                    "laboratorio": form_data.get('laboratorio',''),
                    "rx": form_data.get('rx',''),
                    "audiometria": form_data.get('audiometria',''),
                    "optometria": form_data.get('optometria',''),
                    "ekg": form_data.get('ekg',''),
                    "aptitud": form_data.get('aptitud',''),
                    "aptitud_observ": form_data.get('aptitud_observ',''),
                    "aptitud_limitacion": form_data.get('aptitud_limitacion',''),
                    "recomendaciones_tto": form_data.get('recomendaciones_tto',''),
                    
                    "firma_colaborador": form_data.get('firma_colaborador',''),
                    "fecha": form_data.get('fecha',''),

                    "firmaysello_doc": base_firma_doc,
                    "estatus": 'Completada'
                }
            
            print("Payload:", payload)  # Diagnóstico

            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Actualizar/fichaOcupacional', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)

                # Realiza la petición POST
                if response.status_code == 200:
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}.'

                    # Intenta obtener el mensaje de error del cuerpo de la respuesta
                    try:
                        error_details = response.json()  # Asume que la respuesta es en formato JSON
                        error_message += f" Detalles: {error_details.get('message', 'No hay detalles disponibles')}"
                    except ValueError:
                        # Si no se puede convertir a JSON, puedes añadir un mensaje genérico
                        error_message += " No se pudieron obtener detalles adicionales del error."

                    flash(error_message, 'error')
                    return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)


            except requests.exceptions.RequestException as e:
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

        except ValidationError as e:
            print("Error de validación:", e.json())
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True
            return render_template('depmedico/dash_ocupacional.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))

        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

    # Si el método no es POST o no se cumple ninguna de las condiciones anteriores, redirige o renderiza algo
    return render_template('depmedico/dash_ocupacional.html')

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN PRE OCUPACIONAL
#Agregar aqui la ficha Preocupacional
@depmedico.route('/enviar_preocupacional_colaborador', methods=['GET', 'POST'])
def enviar_preocupacional_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)

            payload = {
                "Tipo_Ficha" : 'Preocupacional',
                "usuario_registro": '',
                "Sector": 'Privado',
                "status": 'Pendiente',
                "Nombre": form_data.get('Nombre', ''),
                "Edad": form_data.get('Edad', ''),
                "Cedula": form_data.get('Cedula', ''),
                "Grupo_sanguineo": form_data.get('Grupo_sanguineo', None),
                "Discapacidad": form_data.get('Discapacidad', None),
                "Porc_Discapacidad": form_data.get('Porc_Discapacidad', None),
                "Religion": form_data.get('Religion', None),
                "Puesto_Trabajo": form_data.get('Puesto_Trabajo', None),
                "Ori_Lesbiana": form_data.get('Ori_Lesbiana', None),
                "Ori_Gay": form_data.get('Ori_Gay', None),
                "Ori_Bisexual": form_data.get('Ori_Bisexual', None),
                "Ori_Hetero": form_data.get('Ori_Hetero', None),
                "Ori_Omitir": form_data.get('Ori_Omitir', None),
                "Iden_Masc": form_data.get('Iden_Masc', None),
                "Iden_Fem": form_data.get('Iden_Fem', None),
                "Iden_Transg": form_data.get('Iden_Transg', None),
                "Iden_Omitir": form_data.get('Iden_Omitir', None),
                "Antced_Clin_Quir": form_data.get('Antced_Clin_Quir', None),
                "Gin_Menarquia": form_data.get('Gin_Menarquia', None),
                "Gin_Ciclos_R": form_data.get('Gin_Ciclos_R', None),
                "Gin_Ciclos_I": form_data.get('Gin_Ciclos_I', None),
                "Gin_Fum": form_data.get('Gin_Fum', None),
                "Gin_Gestas": form_data.get('Gin_Gestas', None),
                "Gin_Partos": form_data.get('Gin_Partos', None),
                "Gin_Cesarea": form_data.get('Gin_Cesarea', None),
                "Gin_Aborto": form_data.get('Gin_Aborto', None),
                "Gin_Hijos_V": form_data.get('Gin_Hijos_V', None),
                "Gin_Hjos_M": form_data.get('Gin_Hjos_M', None),
                "Gin_Vsa": form_data.get('Gin_Vsa', None),
                "Gin_Mpf": form_data.get('Gin_Mpf', None),
                "Gin_Pap": form_data.get('Gin_Pap', None),
                "Gin_Colpos": form_data.get('Gin_Colpos', None),
                "Gin_Eco_Mama": form_data.get('Gin_Eco_Mama', None),
                "Gin_Mamografia": form_data.get('Gin_Mamografia', None),
                "Ap_Ag_Prost": form_data.get('Ap_Ag_Prost', None),
                "Ap_Eco_Prost": form_data.get('Ap_Eco_Prost', None),
                "Ap_Obsv": form_data.get('Ap_Obsv', None),
                "Act_Fisica": form_data.get('Act_Fisica', None),
                "Act_Fisica_Obsv": form_data.get('Act_Fisica_Obsv', None),
                "Medi_Actual": form_data.get('Medi_Actual', None),
                "Medi_Actual_Obsv": form_data.get('Medi_Actual_Obsv', None),
                "Alcohol": form_data.get('Alcohol', None),
                "Alcohol_Obsv": form_data.get('Alcohol_Obsv', None),
                "Tabaco": form_data.get('Tabaco', None),
                "Tabaco_Obsv": form_data.get('Tabaco_Obsv', None),
                "Otros": form_data.get('Otros', None),
                "Otros_Obsv": form_data.get('Otros_Obsv', None),
                "Empresa_1": form_data.get('Empresa_1', None),
                "Puesto_1": form_data.get('Puesto_1', None),
                "Actividad_1": form_data.get('Actividad_1', None),
                "Tiempo_1": form_data.get('Tiempo_1', None),
                "Riego_1": form_data.get('Riego_1', None),
                "Antc_Observ_1": form_data.get('Antc_Observ_1', None),
                "Empresa_2": form_data.get('Empresa_2', None),
                "Puesto_2": form_data.get('Puesto_2', None),
                "Actividad_2": form_data.get('Actividad_2', None),
                "Tiempo_2": form_data.get('Tiempo_2', None),
                "Riego_2": form_data.get('Riego_2', None),
                "Antc_Observ_2": form_data.get('Antc_Observ_2', None),
                "Empresa_3": form_data.get('Empresa_3', None),
                "Puesto_3": form_data.get('Puesto_3', None),
                "Actividad_3": form_data.get('Actividad_3', None),
                "Tiempo_3": form_data.get('Tiempo_3', None),
                "Riego_3": form_data.get('Riego_3', None),
                "Antc_Observ_3": form_data.get('Antc_Observ_3', None),
                "Empresa_4": form_data.get('Empresa_4', None),
                "Puesto_4": form_data.get('Puesto_4', None),
                "Actividad_4": form_data.get('Actividad_4', None),
                "Tiempo_4": form_data.get('Tiempo_4', None),
                "Riego_4": form_data.get('Riego_4', None),
                "Antc_Observ_4": form_data.get('Antc_Observ_4', None),
                "Accidente_Trabajo": form_data.get('Accidente_Trabajo', None),
                "Accidente_Trabajo_Calf_1": form_data.get('Accidente_Trabajo_Calf_1', None),
                "Accidente_Trabajo_Fecha": form_data.get('Accidente_Trabajo_Fecha', None),
                "Enfermedad_Prof": form_data.get('Enfermedad_Prof', None),
                "Enfermedad_Prof_Calf_1": form_data.get('Enfermedad_Prof_Calf_1', None),
                "Enfermedad_Prof_Fecha": form_data.get('Enfermedad_Prof_Fecha', None),
                "Car_Vasc": form_data.get('Car_Vasc', None),
                "Metabolica": form_data.get('Metabolica', None),
                "Neurologica": form_data.get('Neurologica', None),
                "Onco": form_data.get('Onco', None),
                "Infec": form_data.get('Infec', None),
                "Hereditaria": form_data.get('Hereditaria', None),
                "Antc_Descrip": form_data.get('Antc_Descrip', None),
                "Act_Extralaborales": form_data.get('Act_Extralaborales', None),
                "Activ_Relevante": form_data.get('Activ_Relevante', None),
                "Firma_Colaborador": form_data.get('Firma_Colaborador', None),
                "fecha": form_data.get('fecha', None)
            }


            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaPreocupacional', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/form_preocupacional.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/form_preocupacional.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/form_preocupacional.html', errores={}, form_data=form_data)

@depmedico.route('/Preocupacional', methods=['POST'])
def cargar_preocupacional_doc():
    print('Ficha preocupacional doctor')
    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)
        print('cargar_preocupacional_doc')

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaPreocupacional',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict
                print("Respuesta de la API:", response_data)

                # Lista de claves que deseas extraer de la respuesta JSON, ajustada a los nombres reales de la respuesta
                campos_a_extraer = [
                    "Usuario_registro", "Fecha_actualizacion", "Usuario_actualizacion", "Tipo_ficha",
                    "Cedula", "Nombre", "Edad", "Grupo_sanguineo", "Sector", "Discapacidad",
                    "Porc_Discapacidad", "Religion", "Puesto_Trabajo", "Activ_Relevante", 
                    "Ori_Lesbiana", "Ori_Gay", "Ori_Bisexual", "Ori_Hetero", "Ori_Omitir",
                    "Iden_Fem", "Iden_Masc", "Iden_Transg", "Iden_Omitir", "Motivo_Consulta",
                    "Antced_Clin_Quir", "Gin_Menarquia", "Gin_Ciclos_R", "Gin_Ciclos_I",
                    "Gin_Fum", "Gin_Gestas", "Gin_Partos", "Gin_Cesarea", "Gin_Aborto",
                    "Gin_Hijos_V", "Gin_Hjos_M", "Gin_Vsa", "Gin_Mpf", "Gin_Pap",
                    "Gin_Colpos", "Gin_Eco_Mama", "Gin_Mamografia", "Ap_Ag_Prost",
                    "Ap_Eco_Prost", "Ap_Obsv", "Act_Fisica", "Act_Fisica_Obsv",
                    "Medi_Actual", "Medi_Actual_Obsv", "Alcohol", "Alcohol_Obsv",
                    "Tabaco", "Tabaco_Obsv", "Otros", "Otros_Obsv", "Empresa_1",
                    "Empresa_2", "Empresa_3", "Empresa_4", "Puesto_1", "Puesto_2",
                    "Puesto_3", "Puesto_4", "Actividad_1", "Actividad_2", "Actividad_3",
                    "Actividad_4", "Tiempo_1", "Tiempo_2", "Tiempo_3", "Tiempo_4",
                    "Riego_1", "Riego_2", "Riego_3", "Riego_4", "Riego_5", "Riego_6",
                    "Riego_7", "Riego_8", "Antc_Observ_1", "Antc_Observ_2", "Antc_Observ_3",
                    "Antc_Observ_4", "Accidente_Trabajo", "Accidente_Trabajo_Calf_1",
                    "Accidente_Trabajo_Calf_2", "Accidente_Trabajo_Fecha", "Enfermedad_Prof",
                    "Enfermedad_Prof_Calf_1", "Enfermedad_Prof_Calf_2", "Enfermedad_Prof_Fecha",
                    "Car_Vasc", "Metabolica", "Neurologica", "Onco", "Infec", "Hereditaria",
                    "Antc_Descrip", "Fact_Ruido", "Fact_Ruido2", "Fact_Iluminacion",
                    "Fact_Iluminacion2", "Fact_Ventilacion", "Fact_Ventilacion2", 
                    "Fact_Caidas", "Fact_Caidas2", "Fact_Atrope", "Fact_Atrope2",
                    "Fact_Caida_Desniv", "Fact_Caida_Desniv2", "Fact_Polvo", "Fact_Polvo2",
                    "Fact_Liquidos", "Fact_Liquidos2", "Fact_Virus", "Fact_Virus2",
                    "Fact_Post_Forz", "Fact_Post_Forz2", "Fact_Mov_Rep", "Fact_Mov_Rep2",
                    "Fact_Monotomia", "Fact_Monotomia2", "Fact_Alta_Respo", "Fact_Alta_Respo2",
                    "Fact_Conflict", "Fact_Conflict2", "Fact_Sobrecarga", "Fact_Sobrecarga2",
                    "Fact_Inestabilidad", "Fact_Inestabilidad2", "Fact_Relac_Interp",
                    "Fact_Relac_Interp2", "Act_Extralaborales", "Org_Piel", "Org_Respiratorio",
                    "Org_Digestivo", "Org_Mus_Esq", "Org_Hemolinf", "Org_Sent", "Org_Gen_Uri",
                    "Org_Endocrino", "Org_Nervioso", "Org_Card_Vacular", "Org_Descripcion",
                    "Sig_Pres_Art", "Sig_Peso", "Sig_Talla", "Sig_Temp", "Sig_Fc",
                    "Sig_Biotico", "Sig_Sat_Ox", "Sig_Atleti", "Sig_Fr", "Sig_Picn",
                    "Sig_Atletico", "Examn_Fis_Cabeza", "Examn_Fis_Extremidades",
                    "Examn_Fis_Garganta", "Examn_Fis_Ojos", "Examn_Fis_Oidos", 
                    "Examn_Fis_Umbilical", "Examn_Fis_Ingual_Dere", "Examn_Fis_Clural_Dere",
                    "Examn_Fis_Sup_Izquierda", "Examn_Fis_Infer_Dere", "Examn_Fis_Infer_Izquierda",
                    "Examn_Fis_Nariz", "Examn_Fis_Boca", "Examn_Fis_Dentudura", 
                    "Examn_Fis_Inguinal_Izquierdo", "Examn_Fis_Clural_Izq", 
                    "Examn_Fis_Reflejos_Tndinosos", "Examn_Fis_Corazon", "Examn_Fis_Pulmones",
                    "Examn_Fis_Masas_Musculares", "Examn_Fis_Sencibilidad_Sup", 
                    "Examn_Fis_Reflejos_Pupilares", "Examn_Fis_Ojo_Derecho", 
                    "Examn_Fis_Ojo_Izquierdo", "Examn_Fis_Inspeccion", "Examn_Fis_Palpacion", 
                    "Examn_Fis_Percsusion", "Examn_Fis_Tracto_Urinario", "Examn_Fis_Tracto_Genital",
                    "Examn_Fis_Regio_Anoperineal", "Examn_Fis_Oido_Derecho", 
                    "Examn_Fis_Movilidad", "Examn_Fis_Deformaciones", 
                    "Examn_Fis_Oido_Izquierdo", "Examn_Fis_Descripcion", "Laboratorio", 
                    "Rx", "Audiometria", "Optometria", "Ekg", "Diagnostico_1", 
                    "Diagnostico_2", "Diagnostico_3", "Diagnostico_4", "Diagnostico_5", 
                    "Cie10_1", "Cie10_2", "Cie10_3", "Cie10_4", "Cie10_5", 
                    "Def_1", "Def_2", "Def_3", "Def_4", "Def_5", "Prest_1", 
                    "Prest_2", "Prest_3", "Prest_4", "Prest_5", "Apto", 
                    "Apto_Obsv", "Apto_Limit", "No_Apto", "Apt_Med_Obsv", 
                    "Apt_Med_Limit", "Recom_Tto", "Inf_Med_Gen", "Firma_Colaborador"
                ]

                # Lista de experiencias
                experiencias = [
                    {
                        "empresa": response_data.get("Empresa_1", ""),
                        "puesto": response_data.get("Puesto_1", ""),
                        "actividad": response_data.get("Actividad_1", ""),
                        "tiempo": response_data.get("Tiempo_1", ""),
                        "riesgo": response_data.get("Riego_1", ""),
                        "observacion": response_data.get("Antc_Observ_1", "")
                    },
                    {
                        "empresa": response_data.get("Empresa_2", ""),
                        "puesto": response_data.get("Puesto_2", ""),
                        "actividad": response_data.get("Actividad_2", ""),
                        "tiempo": response_data.get("Tiempo_2", ""),
                        "riesgo": response_data.get("Riego_2", ""),
                        "observacion": response_data.get("Antc_Observ_2", "")
                    },
                    {
                        "empresa": response_data.get("Empresa_3", ""),
                        "puesto": response_data.get("Puesto_3", ""),
                        "actividad": response_data.get("Actividad_3", ""),
                        "tiempo": response_data.get("Tiempo_3", ""),
                        "riesgo": response_data.get("Riego_3", ""),
                        "observacion": response_data.get("Antc_Observ_3", "")
                    },
                    {
                        "empresa": response_data.get("Empresa_4", ""),
                        "puesto": response_data.get("Puesto_4", ""),
                        "actividad": response_data.get("Actividad_4", ""),
                        "tiempo": response_data.get("Tiempo_4", ""),
                        "riesgo": response_data.get("Riego_4", ""),
                        "observacion": response_data.get("Antc_Observ_4", "")
                    }
                ]


                # Función para formatear la fecha
                def formatear_fecha(fecha_str):
                    # Aquí debes implementar tu lógica para formatear la fecha
                    return fecha_str  # De momento solo devolverá el mismo valor
                
                # Diccionario para almacenar los datos extraídos
                data = {}

                # Extrae los valores de las claves indicadas
                for campo in campos_a_extraer:
                    # Si el campo es 'Fecha_actualizacion', aplicamos el formateo de fecha
                    if campo == 'Fecha_actualizacion':
                        data['fecha'] = formatear_fecha(response_data.get(campo, ''))
                    else:
                        # Extrae el valor del campo si existe, sino devuelve un string vacío
                        data[campo.lower()] = response_data.get(campo, '')

                print('Datos obtenidos para enviar al formulario:', data)

                # Redirige a la página para mostrar los datos
                return render_template('depmedico/form_preocupacional_doc.html', errores={}, form_data=data, experiencias=experiencias)


            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/form_preocupacional_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/form_preocupacional_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/form_preocupacional_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_preocupacional.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_preocupacional.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_preocupacional.html')

@depmedico.route('/actualizar_preocupacional_medico', methods=['GET', 'POST'])
def actualizar_preocupacional_medico():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        form_data = {key.lower(): value for key, value in form_data.items()}

        errores = {}
       
        try:
            print("Datos recibidos del formulario:", form_data)

            if request.method == 'POST':
                
                
                # Crear el payload con los campos requeridos por la API
                payload = {
                    "usuario_actualizacion": '',
                    "tipo_ficha": 'Preocupacional',
                    "cedula": form_data.get('cedula', ''),
                    "nombre": form_data.get('nombre', ''),
                    "edad": form_data.get('edad', ''),
                    "grupo_sanguineo": form_data.get('grupo_sanguineo', ''),
                    "sector": 'Privado',
                    "discapacidad": form_data.get('discapacidad', ''),
                    "porc_Discapacidad": form_data.get('porc_discapacidad', ''),
                    "religion": form_data.get('religion', ''),
                    "puesto_Trabajo": form_data.get('puesto_trabajo', ''),
                    "activ_Relevante": form_data.get('activ_relevante', ''),
                    "ori_Lesbiana": form_data.get('ori_lesbiana', ''),
                    "ori_Gay": form_data.get('ori_gay', ''),
                    "ori_Bisexual": form_data.get('ori_bisexual', ''),
                    "ori_Hetero": form_data.get('ori_hetero', ''),
                    "ori_Omitir": form_data.get('ori_omitir', ''),
                    "iden_Fem": form_data.get('iden_fFem', ''),
                    "iden_Masc": form_data.get('iden_masc', ''),
                    "iden_Transg": form_data.get('iden_transg', ''),
                    "iden_Omitir": form_data.get('iden_omitir', ''),
                    "motivo_Consulta": 'FMO',
                    "antced_Clin_Quir": form_data.get('antced_clin_quir', ''),
                    "gin_Menarquia": form_data.get('gin_menarquia', ''),
                    "gin_Ciclos_R": form_data.get('gin_ciclos_r', ''),
                    "gin_Ciclos_I": form_data.get('gin_ciclos_i', ''),
                    "gin_Fum": form_data.get('gin_fum', ''),
                    "gin_Gestas": form_data.get('gin_gestas', ''),
                    "gin_Partos": form_data.get('gin_partos', ''),
                    "gin_Cesarea": form_data.get('gin_cesarea', ''),
                    "gin_Aborto": form_data.get('gin_aborto', ''),
                    "gin_Hijos_V": form_data.get('gin_hijos_v', ''),
                    "gin_Hjos_M": form_data.get('gin_hjos_m', ''),
                    "gin_Vsa": form_data.get('gin_vsa', ''),
                    "gin_Mpf": form_data.get('gin_mpf', ''),
                    "gin_Pap": form_data.get('gin_pap', ''),
                    "gin_Colpos": form_data.get('gin_colpos', ''),
                    "gin_Eco_Mama": form_data.get('gin_eco_mama', ''),
                    "gin_Mamografia": form_data.get('gin_mamografia', ''),
                    "ap_Ag_Prost": form_data.get('ap_ag_prost', ''),
                    "ap_Eco_Prost": form_data.get('ap_eco_prost', ''),
                    "ap_Obsv": form_data.get('ap_obsv', ''),
                    "act_Fisica": form_data.get('act_fisica', ''),
                    "act_Fisica_Obsv": form_data.get('act_fisica_obsv', ''),
                    "medi_Actual": form_data.get('medi_actual', ''),
                    "medi_Actual_Obsv": form_data.get('medi_actual_obsv', ''),
                    "alcohol": form_data.get('alcohol', ''),
                    "alcohol_Obsv": form_data.get('alcohol_obsv', ''),
                    "tabaco": form_data.get('tabaco', ''),
                    "tabaco_Obsv": form_data.get('tabaco_obsv', ''),
                    "otros": form_data.get('otros', ''),
                    "otros_Obsv": form_data.get('otros_obsv', ''),
                    "empresa_1": form_data.get('empresa_1', ''),
                    "empresa_2": form_data.get('empresa_2', ''),
                    "empresa_3": form_data.get('empresa_3', ''),
                    "empresa_4": form_data.get('empresa_4', ''),
                    "puesto_1": form_data.get('puesto_1', ''),
                    "puesto_2": form_data.get('puesto_2', ''),
                    "puesto_3": form_data.get('puesto_3', ''),
                    "puesto_4": form_data.get('puesto_4', ''),
                    "actividad_1": form_data.get('actividad_1', ''),
                    "actividad_2": form_data.get('actividad_2', ''),
                    "actividad_3": form_data.get('actividad_3', ''),
                    "actividad_4": form_data.get('actividad_4', ''),
                    "tiempo_1": form_data.get('tiempo_1', ''),
                    "tiempo_2": form_data.get('tiempo_2', ''),
                    "tiempo_3": form_data.get('tiempo_3', ''),
                    "tiempo_4": form_data.get('tiempo_4', ''),
                    "riego_1": form_data.get('riego_1', ''),
                    "riego_2": form_data.get('riego_2', ''),
                    "riego_3": form_data.get('riego_3', ''),
                    "riego_4": form_data.get('riego_4', ''),
                    "riego_5": 'N/A',
                    "riego_6": 'N/A',
                    "riego_7": 'N/A',
                    "riego_8": form_data.get('riego_8', ''), 
                    "antc_Observ_1": form_data.get('antc_observ_1', ''),
                    "antc_Observ_2": form_data.get('antc_observ_2', ''),
                    "antc_Observ_3": form_data.get('antc_observ_3', ''),
                    "antc_Observ_4": form_data.get('antc_Oobserv_4', ''),
                    "accidente_Trabajo": form_data.get('accidente_trabajo', ''),
                    "accidente_Trabajo_Calf_1": form_data.get('accidente_trabajo_calf_1', ''),
                    "accidente_Trabajo_Calf_2": form_data.get('accidente_trabajo_calf_2', ''),
                    "accidente_Trabajo_Fecha": form_data.get('accidente_trabajo_fecha', ''),
                    "enfermedad_Prof": form_data.get('enfermedad_prof', ''),
                    "enfermedad_Prof_Calf_1": form_data.get('enfermedad_prof_calf_1', ''),
                    "enfermedad_Prof_Calf_2": form_data.get('enfermedad_prof_calf_2', ''),
                    "enfermedad_Prof_Fecha": form_data.get('enfermedad_prof_fecha', ''),
                    "car_Vasc": form_data.get('car_vasc', ''),
                    "metabolica": form_data.get('metabolica', ''),
                    "neurologica": form_data.get('neurologica', ''),
                    "onco": form_data.get('onco', ''),
                    "infec": form_data.get('infec', ''),
                    "hereditaria": form_data.get('hereditaria', ''),
                    "antc_Descrip": form_data.get('antc_descrip', ''),
                    "fact_Ruido": form_data.get('fact_ruido', ''),
                    "fact_Ruido2": form_data.get('fact_ruido2', ''),
                    "fact_Iluminacion": form_data.get('fact_iluminacion', ''),
                    "fact_Iluminacion2": form_data.get('fact_iluminacion2', ''),
                    "fact_Ventilacion": form_data.get('fact_ventilacion', ''),
                    "fact_Ventilacion2": form_data.get('fact_ventilacion2', ''),
                    "fact_Caidas": form_data.get('fact_caidas', ''),
                    "fact_Caidas2": form_data.get('fact_caidas2', ''),
                    "fact_Atrope": form_data.get('fact_atrope', ''),
                    "fact_Atrope2": form_data.get('fact_atrope2', ''),
                    "fact_Caida_Desniv": form_data.get('fact_caida_desniv', ''),
                    "fact_Caida_Desniv2": form_data.get('fact_caida_desniv2', ''),
                    "fact_Polvo": form_data.get('fact_polvo', ''),
                    "fact_Polvo2": form_data.get('fact_polvo2', ''),
                    "fact_Liquidos": form_data.get('fact_liquidos', ''),
                    "fact_Liquidos2": form_data.get('fact_liquidos2', ''),
                    "fact_Virus": form_data.get('fact_virus', ''),
                    "fact_Virus2": form_data.get('fact_virus2', ''),
                    "fact_Post_Forz": form_data.get('fact_post_forz', ''),
                    "fact_Post_Forz2": form_data.get('fact_post_forz2', ''),
                    "fact_Mov_Rep": form_data.get('fact_mov_rep', ''),
                    "fact_Mov_Rep2": form_data.get('fact_mov_Rep2', ''),
                    "fact_Monotomia": form_data.get('fact_monotomia', ''),
                    "fact_Monotomia2": form_data.get('fact_monotomia2', ''),
                    "fact_Alta_Respo": form_data.get('fact_alta_respo', ''),
                    "fact_Alta_Respo2": form_data.get('fact_alta_respo2', ''),
                    "fact_Conflict": form_data.get('fact_conflict', ''),
                    "fact_Conflict2": form_data.get('fact_Conflict2', ''),
                    "fact_Sobrecarga": form_data.get('fact_sobrecarga', ''),
                    "fact_Sobrecarga2": form_data.get('fact_Sobrecarga2', ''),
                    "fact_Inestabilidad": form_data.get('fact_inestabilidad', ''),
                    "fact_Inestabilidad2": form_data.get('fact_inestabilidad2', ''),
                    "fact_Relac_Interp": form_data.get('fact_relac_interp', ''),
                    "fact_Relac_Interp2": form_data.get('fact_relac_Interp2', ''),
                    "act_Extralaborales": form_data.get('act_extralaborales', ''),
                    "org_Piel": form_data.get('org_piel', ''),
                    "org_Respiratorio": form_data.get('org_respiratorio', ''),
                    "org_Digestivo": form_data.get('org_digestivo', ''),
                    "org_Mus_Esq": form_data.get('org_mus_esq', ''),
                    "org_Hemolinf": form_data.get('org_hemolinf', ''),
                    "org_Sent": form_data.get('org_sent', ''),
                    "org_Gen_Uri": form_data.get('org_gen_uri', ''),
                    "org_Endocrino": form_data.get('org_endocrino', ''),
                    "org_Nervioso": form_data.get('org_nervioso', ''),
                    "org_Card_Vacular": form_data.get('org_card_vacular', ''),
                    "org_Descripcion": form_data.get('org_descripcion', ''),
                    "sig_Pres_Art": form_data.get('sig_pres_art', ''),
                    "sig_Peso": form_data.get('sig_peso', ''),
                    "sig_Talla": form_data.get('sig_talla', ''),
                    "sig_Temp": form_data.get('sig_temp', ''),
                    "sig_Fc": form_data.get('sig_fc', ''),
                    "sig_Biotico": form_data.get('sig_biotico', ''),
                    "sig_Sat_Ox": form_data.get('sig_sat_ox', ''),
                    "sig_Atleti": form_data.get('sig_atleti', ''),
                    "sig_Fr": form_data.get('sig_fr', ''),
                    "sig_Picn": form_data.get('sig_picn', ''),
                    "sig_Atletico": form_data.get('sig_atletico', ''),
                    "examn_Fis_Cabeza": form_data.get('examn_fis_cabeza', ''),
                    "examn_Fis_Extremidades": form_data.get('examn_fis_extremidades', ''),
                    "examn_Fis_Garganta": form_data.get('examn_fis_garganta', ''),
                    "examn_Fis_Ojos": form_data.get('examn_fis_ojos', ''),
                    "examn_Fis_Oidos": form_data.get('examn_fis_oidos', ''),
                    "examn_Fis_Umbilical": form_data.get('examn_fis_umbilical', ''),
                    "examn_Fis_Ingual_Dere": form_data.get('examn_fis_ingual_dere', ''),
                    "examn_Fis_Clural_Dere": form_data.get('examn_fis_clural_dere', ''),
                    "examn_Fis_Sup_Izquierda": form_data.get('examn_fis_sup_izquierda', ''),
                    "examn_Fis_Infer_Dere": form_data.get('examn_fis_infer_dere', ''),
                    "examn_Fis_Infer_Izquierda": form_data.get('examn_fis_infer_izquierda', ''),
                    "examn_Fis_Nariz": form_data.get('examn_fis_nariz', ''),
                    "examn_Fis_Boca": form_data.get('examn_fis_boca', ''),
                    "examn_Fis_Dentudura": form_data.get('examn_fis_dentudura', ''),
                    "examn_Fis_Inguinal_Izquierdo": form_data.get('examn_fis_inguinal_izquierdo', ''),
                    "examn_Fis_Clural_Izq": form_data.get('examn_fis_clural_izq', ''),
                    "examn_Fis_Reflejos_Tndinosos": form_data.get('examn_fis_reflejos_tndinosos', ''),
                    "examn_Fis_Corazon": form_data.get('examn_fis_corazon', ''),
                    "examn_Fis_Pulmones": form_data.get('examn_fis_pulmones', ''),
                    "examn_Fis_Masas_Musculares": form_data.get('examn_fis_masas_musculares', ''),
                    "examn_Fis_Sencibilidad_Sup": form_data.get('examn_fis_sencibilidad_sup', ''),
                    "examn_Fis_Reflejos_Pupilares": form_data.get('examn_fis_reflejos_pupilares', ''),
                    "examn_Fis_Ojo_Derecho": form_data.get('examn_fis_ojo_derecho', ''),
                    "examn_Fis_Ojo_Izquierdo": form_data.get('examn_fis_ojo_izquierdo', ''),
                    "examn_Fis_Inspeccion": form_data.get('examn_fis_inspeccion', ''),
                    "examn_Fis_Palpacion": form_data.get('examn_fis_palpacion', ''),
                    "examn_Fis_Percsusion": form_data.get('examn_fis_percsusion', ''),
                    "examn_Fis_Tracto_Urinario": form_data.get('examn_fis_tracto_urinario', ''),
                    "examn_Fis_Tracto_Genital": form_data.get('examn_fis_tracto_genital', ''),
                    "examn_Fis_Regio_Anoperineal": form_data.get('examn_fis_regio_anoperineal', ''),
                    "examn_Fis_Oido_Derecho": form_data.get('examn_fis_oido_derecho', ''),
                    "examn_Fis_Movilidad": form_data.get('examn_fis_movilidad', ''),
                    "examn_Fis_Deformaciones": form_data.get('examn_fis_deformaciones', ''),
                    "examn_Fis_Oido_Izquierdo": form_data.get('examn_fis_oido_izquierdo', ''),
                    "examn_Fis_Descripcion": form_data.get('examn_fis_descripcion', ''),
                    "laboratorio": form_data.get('laboratorio', ''),
                    "rx": form_data.get('rx', ''),
                    "audiometria": form_data.get('audiometria', ''),
                    "optometria": form_data.get('optometria', ''),
                    "ekg": form_data.get('ekg', ''),
                    "diagnostico_1": form_data.get('diagnostico_1', ''),
                    "diagnostico_2": form_data.get('diagnostico_2', ''),
                    "diagnostico_3": form_data.get('diagnostico_3', ''),
                    "diagnostico_4": form_data.get('diagnostico_4', ''),
                    "diagnostico_5": form_data.get('diagnostico_5', ''),
                    "cie10_1": form_data.get('cie10_1', ''),
                    "cie10_2": form_data.get('cie10_2', ''),
                    "cie10_3": form_data.get('cie10_3', ''),
                    "cie10_4": form_data.get('cie10_4', ''),
                    "cie10_5": form_data.get('cie10_5', ''),
                    "def_1": form_data.get('def_1', ''),
                    "def_2": form_data.get('def_2', ''),
                    "def_3": form_data.get('def_3', ''),
                    "def_4": form_data.get('def_4', ''),
                    "def_5": form_data.get('def_5', ''),
                    "prest_1": form_data.get('prest_1', ''),
                    "prest_2": form_data.get('prest_2', ''),
                    "prest_3": form_data.get('prest_3', ''),
                    "prest_4": form_data.get('prest_4', ''),
                    "prest_5": form_data.get('prest_5', ''),
                    "apto": form_data.get('apto', ''),
                    "apto_Obsv": form_data.get('apto_obsv', ''),
                    "apto_Limit": form_data.get('apto_limit', ''),
                    "no_Apto": form_data.get('no_apto', ''),
                    "apt_Med_Obsv": form_data.get('apt_med_obsv', ''),
                    "apt_Med_Limit": form_data.get('apt_med_limit', ''),
                    "recom_Tto": form_data.get('recom_tto', ''),
                    "inf_Med_Gen": form_data.get('inf_med_gen', ''),
                    "firma_Colaborador": form_data.get('firma_colaborador', ''),
                    "fecha_Firma": form_data.get('fecha_firma', ''),
                    "firma_Doctor": base_firma_doc,
                    "medico": form_data.get('medico', ''),
                    "codigo": form_data.get('codigo', ''),
                    "status": 'Completada'


                }


                print("Payload:", payload)  # Diagnóstico del payload

            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Actualizar/fichaPreocupacional', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('error.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('error.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('error.html', errores={}, form_data=form_data)

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN SEG DROGAS
@depmedico.route('/enviar_segdroga_colaborador', methods=['GET', 'POST'])
def enviar_segdroga_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)

            payload = {
                "Usuario_registro": '',
                "Tipo_ficha": 'SeguimientoDroga',
                "Cedula": form_data.get('Cedula', ''),
                "Nombre": form_data.get('Nombre', ''),
                "Cargo": form_data.get('Cargo', ''),
                "Tiempo_cargo": form_data.get('Tiempo_cargo', ''),
                "Edad": form_data.get('Edad', ''),
                "Enfer_catastrofica": form_data.get('Enfer_catastrofica', ''),
                "Enfer_cron_transmi": form_data.get('Enfer_cron_transmi', ''),
                "Enfer_cron_notransmi": form_data.get('Enfer_cron_notransmi', ''),
                "Enfer_nodiagnosticada": form_data.get('Enfer_nodiagnosticada', ''),
                "Droga": form_data.get('Droga', ''),
                "Frecuencia_consumo": form_data.get('Frecuencia_consumo', ''),
                "Fact_psico_sociales": form_data.get('Fact_psico_sociales', ''),
                "Fact_psico_sociales_detalle": form_data.get('Fact_psico_sociales_detalle', ''),
                "Socializacion_personal": form_data.get('Socializacion_personal', ''),
                "Firma_colaborador": form_data.get('firma_colaborador', ''),
                "Status": 'Pendiente'
            }

            print("PAYLOAD:", payload)
            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaSegDrogas', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:
                    
                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
                    
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/form_segdrogas.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)

@depmedico.route('/SeguimientoDrogas', methods=['POST'])
def cargar_seguimiento_doc():
    print('Ficha preocupacional doctor')
    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaSegDrogas',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict
                

                # Extrae datos de la respuesta
                nombre = response_data.get('Nombre', '')
                cedula = response_data.get('Cedula', '')
                fecha = formatear_fecha(response_data.get('Fecha_actualizacion', '')),
                cargo = response_data.get('Cargo', '')
                tiempo_cargo = response_data.get('Tiempo_cargo', '')
                edad = response_data.get('Edad', '')
                enfer_catastrofica = response_data.get('Enfer_catastrofica', '')
                enfer_cron_transmi = response_data.get('Enfer_cron_transmi', '')
                enfer_cron_notransmi = response_data.get('Enfer_cron_notransmi', '')
                enfer_nodiagnosticada = response_data.get('Enfer_nodiagnosticada', '')
                droga = response_data.get('Droga', '')
                frecuencia_consumo = response_data.get('Frecuencia_consumo', '')
                fact_psico_sociales = response_data.get('Fact_psico_sociales', '')
                fact_psico_sociales_detalle = response_data.get('Fact_psico_sociales_detalle', '')
                socializacion_personal = response_data.get('Socializacion_personal', '')
                firma = response_data.get('Firma_colaborador', '')

                data = {
                    'nombre': nombre,
                    'cedula': cedula,
                    'fecha': fecha,
                    'cargo': cargo,
                    'tiempo_cargo': tiempo_cargo,
                    'edad': edad,
                    'enfer_catastrofica': enfer_catastrofica,
                    'enfer_cron_transmi': enfer_cron_transmi,
                    'enfer_cron_notransmi': enfer_cron_notransmi,
                    'enfer_nodiagnosticada': enfer_nodiagnosticada,
                    'frecuencia_consumo': frecuencia_consumo,
                    'fact_psico_sociales': fact_psico_sociales,
                    'fact_psico_sociales_detalle': fact_psico_sociales_detalle,
                    'socializacion_personal': socializacion_personal,
                    'droga': droga,
                    'firma': firma
                }


                print('Datos obtenidos para enviar al formulario', data)
                print('fecha:', fecha)
                # Redirige a la página para mostrar los datos
                return render_template('depmedico/form_segdrogas_doc.html', errores={}, form_data=data)

            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/form_segdrogas_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/form_segdrogas_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/form_segdrogas_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_seg_drogas.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_seg_drogas.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_seg_drogas.html')

@depmedico.route('/actualizar_seguimiento_medico', methods=['GET', 'POST'])
def actualizar_seguimiento_medico():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}
       
        try:
            print("Datos recibidos del formulario:", form_data)

            if request.method == 'POST':
                
                print('Firma:', form_data.get('firma_colaborador')  )

                payload = {
                            
                    "Usuario_actualizacion": '',
                    "nombre" : form_data.get('Nombre', ''),
                    "cedula" : form_data.get('Cedula', ''),
                    "cargo" : form_data.get('Cargo', ''),
                    "tipo_ficha" : 'Seguimiento Droga',
                    "tiempo_cargo" : form_data.get('Tiempo_cargo', ''),
                    "edad" : form_data.get('Edad', ''),
                    "fecha" : form_data.get('Fecha'),
                    "enfer_catastrofica" : form_data.get('Enfer_catastrofica', ''),
                    "enfer_cron_transmi" : form_data.get('Enfer_cron_transmi', ''),
                    "enfer_cron_notransmi" : form_data.get('Enfer_cron_notransmi', ''),
                    "enfer_nodiagnosticada" : form_data.get('Enfer_nodiagnosticada', ''),
                    "droga" : form_data.get('Droga', ''),
                    "frecuencia_consumo" : form_data.get('Frecuencia_consumo', ''),
                    "fact_psico_sociales" : form_data.get('Fact_psico_sociales', ''),
                    "fact_psico_sociales_detalle" : form_data.get('Fact_psico_sociales_detalle', ''),
                    "socializacion_personal" : form_data.get('Socializacion_personal', ''),
                    "firma_colaborador" : form_data.get('firma_colaborador'),

                    "status": 'Completada'
                }

            print("Payload:", payload)  # Diagnóstico

            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Actualizar/fichaSegDrogas', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('error.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('error.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('error.html', errores={}, form_data=form_data)

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN CONSUMO DROGAS

@depmedico.route('/enviar_consumo_colaborador', methods=['GET', 'POST'])
def enviar_consumo_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)

            payload = {
                "usuario_registro": '',
                "tipo_ficha": 'ConsumoDroga',
                "tipo_sangre": form_data.get('tipo_sangre', ''),
                "fecha_apertura_F_RPD": form_data.get('fecha_apertura_F_RPD', ''),
                "cedula": form_data.get('cedula', ''),
                "nombre": form_data.get('nombre', ''),
                "edad": form_data.get('edad', ''),
                "dimicilio": form_data.get('dimicilio', ''),
                "telefono": form_data.get('telefono', ''),
                "profesion": form_data.get('profesion', ''),
                "religion": form_data.get('religion', ''),
                "estado_civil": form_data.get('estado_civil', ''),
                "cargo": form_data.get('cargo', ''),
                "email": form_data.get('email', ''),
                "nivel_instrucción": form_data.get('nivel_instrucción', ''),
                "etnia": form_data.get('etnia', ''),
                "disca_auditiva": form_data.get('disca_auditiva', ''),
                "disca_fisica": form_data.get('disca_fisica', ''),
                "disca_intelectual": form_data.get('disca_intelectual', ''),
                "lenguaje": form_data.get('lenguaje', ''),
                "psico_social": form_data.get('psico_social', ''),
                "visual": form_data.get('visual', ''),
                "droga": form_data.get('droga', ''),
                "droga_detalles": form_data.get('droga_detalles', ''),
                "tratamiento": form_data.get('tratamiento', ''),
                "factores_psicosociales_otros": form_data.get('factores_psicosociales_otros', ''),
                "factores_psicosociales": form_data.get('factores_psicosociales', ''),
                "frecuencia_consumo": form_data.get('frecuencia_consumo', ''),
                "porcentaje_disca": form_data.get('porcentaje_disca', ''),
                "enfer_catastrofica": form_data.get('enfer_catastrofica', ''),
                "enfer_cron_transmi": form_data.get('enfer_cron_transmi', ''),
                "enfer_cron_notransmi": form_data.get('enfer_cron_notransmi', ''),
                "diag_presuntivo": form_data.get('diag_presuntivo', ''),
                "trabajador_sustituto": form_data.get('trabajador_sustituto', ''),
                "exam_preocupacionales": form_data.get('exam_preocupacionales', ''),
                "firma_colaborador" : form_data.get('firma_colaborador', ''),
                "status": 'Pendiente'
            }

            print("PAYLOAD:", payload)
            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaDrogas', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:
                    
                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
                    
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/form_segdrogas.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)

@depmedico.route('/ConsumoDrogas', methods=['POST'])
def cargar_consumo_doc():
    print('Ficha preocupacional doctor')
    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaDrogas',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict

                # Lista de claves que deseas extraer de la respuesta JSON
                campos_a_extraer = [
                        'Fecha_registro', 'Usuario_registro', 'Fecha_actualizacion', 'Usuario_actualizacion', 
                        'Tipo_ficha', 'Tipo_sangre', 'Fecha_apertura_F_RPD', 'Cedula', 'Nombre', 'Edad', 
                        'Dimicilio', 'Telefono', 'Profesion', 'Religion', 'Estado_civil', 'Cargo', 'Cargo_2', 
                        'Email', 'Nivel_instrucción', 'Etnia', 'Disca_auditiva', 'Disca_fisica', 
                        'Disca_intelectual', 'Lenguaje', 'Psico_social', 'Visual', 'Porcentaje_disca', 
                        'Enfer_catastrofica', 'Enfer_cron_transmi', 'Enfer_cron_notransmi', 'Diag_presuntivo', 
                        'Trabajador_sustituto', 'Status', 'Droga', 'Frecuencia_consumo', 'Tratamiento', 
                        'Droga_detalles', 'Factores_psicosociales', 'Factores_psicosociales_otros', 
                        'Exam_preocupacionales', 'Firma_colaborador', 'Firma_doc'
                    ]

                # Función para formatear la fecha
                def formatear_fecha(fecha_str):
                    # Aquí debes implementar tu lógica para formatear la fecha
                    return fecha_str  # De momento solo devolverá el mismo valor
                
                # Diccionario para almacenar los datos extraídos
                data = {}

                # Extrae los valores de las claves indicadas
                for campo in campos_a_extraer:
                    # Si el campo es 'Fecha_actualizacion', aplicamos el formateo de fecha
                    if campo == 'Fecha_actualizacion':
                        data['fecha'] = formatear_fecha(response_data.get(campo, ''))
                    else:
                        # Extrae el valor del campo si existe, sino devuelve un string vacío
                        data[campo.lower()] = response_data.get(campo, '')

                print('Datos obtenidos para enviar al formulario:', data)

                # Redirige a la página para mostrar los datos
                return render_template('depmedico/form_drogas_doc.html', errores={}, form_data=data)

            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/form_drogas_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/form_drogas_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/form_drogas_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_cons_drogas.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_cons_drogas.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_cons_drogas.html')

@depmedico.route('/actualizar_consumo_medico', methods=['GET', 'POST'])
def actualizar_consumo_medico():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}
       
        try:
            print("Datos recibidos del formulario:", form_data)

            if request.method == 'POST':

                print('Firma:', form_data.get('firma_colaborador'))

                # Crear el payload con los campos requeridos por la API
                payload = {
                    "usuario_actualizacion": '',  # Nombre del usuario que actualiza
                    "tipo_ficha": 'ConsumoDroga',
                    "tipo_sangre": form_data.get('tipo_sangre', ''),
                    "fecha_apertura_F_RPD": form_data.get('fecha_apertura_F_RPD', ''),
                    "cedula": form_data.get('cedula', ''),
                    "nombre": form_data.get('nombre', ''),
                    "edad": form_data.get('edad', ''),
                    "dimicilio": form_data.get('domicilio', ''),
                    "telefono": form_data.get('telefono', ''),
                    "profesion": form_data.get('profesion', ''),
                    "religion": form_data.get('religion', ''),
                    "estado_civil": form_data.get('estado_civil', ''),
                    "cargo": form_data.get('cargo', ''),
                    "cargo_2": form_data.get('cargo_2', ''),
                    "email": form_data.get('email', ''),
                    "nivel_instrucción": form_data.get('nivel_instrucción', ''),
                    "etnia": form_data.get('etnia', ''),
                    "disca_auditiva": form_data.get('disca_auditiva', ''),
                    "disca_fisica": form_data.get('disca_fisica', ''),
                    "disca_intelectual": form_data.get('disca_intelectual', ''),
                    "lenguaje": form_data.get('lenguaje', ''),
                    "psico_social": form_data.get('psico_social', ''),
                    "visual": form_data.get('visual', ''),
                    "porcentaje_disca": form_data.get('porcentaje_disca', ''),
                    "enfer_catastrofica": form_data.get('enfer_catastrofica', ''),
                    "enfer_cron_transmi": form_data.get('enfer_cron_transmi', ''),
                    "enfer_cron_notransmi": form_data.get('enfer_cron_notransmi', ''),
                    "diag_presuntivo": form_data.get('diag_presuntivo', ''),
                    "trabajador_sustituto": form_data.get('trabajador_sustituto', ''),
                    "status": 'Completada',
                    "droga": form_data.get('droga', ''),
                    "frecuencia_consumo": form_data.get('frecuencia_consumo', ''),
                    "tratamiento": form_data.get('tratamiento', ''),
                    "droga_detalles": form_data.get('droga_detalles', ''),
                    "factores_psicosociales": form_data.get('factores_psicosociales', ''),
                    "factores_psicosociales_otros": form_data.get('factores_psicosociales_otros', ''),
                    "exam_preocupacionales": form_data.get('exam_preocupacionales', ''),
                    "firma_colaborador": form_data.get('firma_colaborador'),
                    "firma_doc": form_data.get('firma_doc', '')
                }


                print("Payload:", payload)  # Diagnóstico del payload

            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Actualizar/fichaDrogas', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('error.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('error.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('error.html', errores={}, form_data=form_data)

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN CONSENTIMIENTO INFORMADO
@depmedico.route('/enviar_consentimiento_colaborador', methods=['GET', 'POST'])
def guardar_consentimiento_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)

            payload =   {
            "usuario_registro": "",
            "nombre": form_data.get('nombre'),
            "cedula": form_data.get('cedula'),
            "fecha": form_data.get('fecha'),
            "firma": form_data.get('firma'),
            "status": "Pendiente"
            }
            
            print("PAYLOAD:", payload)
            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaConsInformado', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:
                    
                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
                    
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/form_segdrogas.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)

@depmedico.route('/ConsentimientoInformado', methods=['POST'])
def cargar_consentimiento_doc():
    print('Ficha preocupacional doctor')
    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaConsInformado',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict
                
                # Extrae datos de la respuesta
                nombre = response_data.get('Nombre', '')
                cedula = response_data.get('Cedula', '')
                fecha = response_data.get('Fecha', '')
                firma = response_data.get('Firma', '')

                data = {
                    'nombre': nombre,
                    'cedula': cedula,
                    'fecha': fecha,
                    'firma': firma
                }

                print('Datos obtenidos para enviar al formulario', data)
                print('fecha:', data.get('fecha'))
                # Redirige a la página para mostrar los datos
                return render_template('depmedico/form_consentimiento_doc.html', errores={}, form_data=data)

            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/form_consentimiento_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/form_consentimiento_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/form_consentimiento_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_consentimiento.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_consentimiento.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_consentimiento.html')

@depmedico.route('/actualizar_consentimiento_medico', methods=['GET', 'POST'])
def actualizar_consentimiento_medico():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}
       
        nombre = form_data.get('nombre').strip().upper() 
        
        try:
            print("Datos recibidos del formulario:", form_data)

            if request.method == 'POST':
                
                print(form_data.get('edad',None))

                payload = {
                            
                    "Usuario_actualizacion": '',
                    "nombre" : nombre,
                    "fecha" : form_data.get('fecha', ''),
                    "cedula" : form_data.get('cedula', ''),
                    "firma" : form_data.get('firma', ''),
                    "status": 'Completada'
                }
            
            print("Payload:", payload)  # Diagnóstico

            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Actualizar/fichaConsInformado', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:

                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('error.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('error.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('error.html', errores={}, form_data=form_data)

#===================================== GUARDAR Y RECUPERAR INFORMACIÓN CERTIFICADO
@depmedico.route('/enviar_certificado_colaborador', methods=['GET', 'POST'])
def guardar_certificado_colaborador():
    print("Método de solicitud:", request.method)  # Diagnóstico
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        usuario = session.get('usuario', 'No disponible')

        try:
            print("Datos recibidos del formulario:", form_data)

            payload =   {
            "usuario_registro": "",
            "nombre": form_data.get('nombre'),
            "cedula": form_data.get('cedula'),
            "nhc": form_data.get('nhc'),
            "edad": form_data.get('edad'),
            "sexo": form_data.get('sexo'),
            "cargo": form_data.get('cargo'),
            "tiempo_cargo": form_data.get('tiempo_cargo'),
            "fecha_emision": form_data.get('fecha_emision'),
            "ingreso": form_data.get('ingreso'),
            "periodico": form_data.get('periodico'),
            "reintegro": form_data.get('reintegro'),
            "apto": form_data.get('apto'),
            "apto_observacion": form_data.get('apto_observacion'),
            "apto_limitaciones": form_data.get('apto_limitaciones'),
            "no_apto": form_data.get('no_apto'),
            "apto_detalles": form_data.get('apto_detalles'),
            "recomendaciones": form_data.get('recomendaciones'),
            "firma_colaborador": form_data.get('firma_colaborador'),
            "firma_doc": form_data.get('firma_doc',''),
            "status": "Pendiente"
            }

            
            
            print("PAYLOAD:", payload)
            try:
                response = requests.post('https://localhost:7220/FormDepMedico/Guardar/fichaCertOcup', json=payload, headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}, verify=False)

                #response = requests.post(url, json=payload, headers=headers)
                # Aquí imprimes el código de estado y la respuesta
                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)
                # Realiza la petición POST
                if response.status_code == 200:
                    
                        # Los datos son válidos si no se lanza ninguna excepción, procesarlos aquí
                        # Por ejemplo, guardar en la base de datos o realizar otras acciones
                    flash(f'El formulario ha sido enviado con éxito.', 'success')
                    
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                        # Si el código de estado no es 200, manejar como error
                        # Aquí puedes tratar de decodificar la respuesta de la API para mostrar un mensaje más específico
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
                    
            except requests.exceptions.RequestException as e:
                # Manejo de excepciones al realizar la petición
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)
                    
        except ValidationError as e:
            print("Error de validación:", e.json())
            # Manejo de errores de validación
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            session['show_full_form'] = True  # Asegúrate de no avanzar si hay errores
            return render_template('depmedico/form_segdrogas.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
            #return render_template('formulario_UpgradeV2.html', errores=errores, form_data=form_data)
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/form_segdrogas.html', errores={}, form_data=form_data)

@depmedico.route('/CertificadoInformado', methods=['POST'])
def cargar_certificado_doc():
    print('Ficha preocupacional doctor')
    print("Método de solicitud:", request.method)
    errores = {}
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        print("Datos recibidos del formulario:", form_data)
        session['cedula'] = cedula
        data={}

        # Usa la cédula del formulario
        payload = {
            "cedula": cedula  
        }
        
        print("Payload:", payload)

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaCertOcup',json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )
            print("Código de estado:", response.status_code)

            if response.status_code == 201:
                response_data = response.json()  # Usa .json() para obtener un dict
                print(response_data)
                # Extrae datos de la respuesta

                nombre = response_data.get('Nombre')
                cedula = response_data.get('Cedula')
                nhc = response_data.get('NHC')
                edad = response_data.get('Edad')
                sexo = response_data.get('Sexo')
                cargo = response_data.get('Cargo')
                tiempo_cargo = response_data.get('Tiempo_cargo')
                ingreso = response_data.get('Ingreso')
                periodico = response_data.get('Periodico')
                reintegro = response_data.get('Reintegro')
                apto = response_data.get('Apto')
                apto_observacion = response_data.get('Apto_observacion')
                apto_limitaciones = response_data.get('Apto_limitaciones')
                no_apto = response_data.get('No_apto')
                apto_detalles = response_data.get('Apto_detalles')
                recomendaciones = response_data.get('Recomendaciones')
                firma_colaborador = response_data.get('Firma_colaborador')
                firma_doc = response_data.get('Firma_doc','')

        
        # Obtener y formatear la fecha de emisión
                fecha_emision_raw = response_data.get('Fecha_emision')  # Supongamos que viene como 'dd/mm/yyyy'
                
                try:
                    # Intenta convertir la fecha al formato adecuado 'YYYY-MM-DD'
                    fecha_emision = datetime.strptime(fecha_emision_raw, '%d/%m/%Y').strftime('%Y-%m-%d')
                except ValueError:
                    # Si hay un error al convertir la fecha, usa una fecha por defecto o maneja el error
                    fecha_emision = ''  # O cualquier valor adecuado

                data = {

                    'nombre': nombre,
                    'cedula': cedula,
                    'nhc': nhc,
                    'edad': edad,
                    'sexo': sexo,
                    'cargo': cargo,
                    'tiempo_cargo': tiempo_cargo,
                    'fecha_emision': fecha_emision,
                    'ingreso': ingreso,
                    'periodico': periodico,
                    'reintegro': reintegro,
                    'apto': apto,
                    'apto_observacion': apto_observacion,
                    'apto_limitaciones': apto_limitaciones,
                    'no_apto': no_apto,
                    'apto_detalles': apto_detalles,
                    'recomendaciones': recomendaciones,
                    'firma_colaborador': firma_colaborador,
                    'firma_doc': firma_doc,
                    'status': "Pendiente"
                    
                }

                print('Datos obtenidos para enviar al formulario', data)
                print('fecha:', data.get('fecha'))
                # Redirige a la página para mostrar los datos
                return render_template('depmedico/form_certificado_doc.html', errores={}, form_data=data)

            elif response.status_code == 404:
                print("Error 404:", response.text)
                return render_template('depmedico/form_certificado_doc.html', errores={}, form_data=data)
            elif response.status_code == 500:
                print("Error 500:", response.text)
                return render_template('depmedico/form_certificado_doc.html', errores={}, form_data=data)
            else:
                print("Error en la respuesta de la API:", response.text)
                errores = f"Error en la respuesta de la API: {response.text}"
                return render_template('depmedico/form_certificado_doc.html', errores={}, form_data=data)

        except requests.exceptions.RequestException as e:
            print("Error general en la solicitud:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            # Asegúrate de devolver un render_template o algún tipo de respuesta
            return render_template('depmedico/dash_certificado.html', errores=errores, form_data={})
        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('depmedico/dash_certificado.html', errores=errores, form_data={})

    else:
        return render_template('depmedico/dash_certificado.html')

@depmedico.route('/procesar_certificado_medico', methods=['GET', 'POST'])
def actualizar_certificado_medico():
    print("Método de solicitud:", request.method)
    if request.method == 'POST':
        form_data = request.form.to_dict()
        errores = {}

        nombre = form_data.get('nombre', '').strip().upper()

        try:
            print("Datos recibidos del formulario:", form_data)

            payload = {
                "usuario_actualizacion": "",
                "nombre": nombre,
                "cedula": form_data.get('cedula', ''),
                "nhc": form_data.get('nhc', ''),
                "edad": form_data.get('edad', ''),
                "sexo": form_data.get('sexo', ''),
                "cargo": form_data.get('cargo', ''),
                "tiempo_cargo": form_data.get('tiempo_cargo', ''),
                "fecha_emision": form_data.get('fecha_emision', ''),
                "ingreso": form_data.get('ingreso', ''),
                "periodico": form_data.get('periodico', ''),
                "reintegro": form_data.get('reintegro', ''),
                "apto": form_data.get('apto', ''),
                "apto_observacion": form_data.get('apto_observacion', ''),
                "apto_limitaciones": form_data.get('apto_limitaciones', ''),
                "no_apto": form_data.get('no_apto', ''),
                "apto_detalles": form_data.get('apto_detalles', ''),
                "recomendaciones": form_data.get('recomendaciones', ''),
                "firma_colaborador": form_data.get('firma_colaborador'),
                "firma_doc" : base_firma_doc,
                "status": 'Completada'
            }

            print("Payload:", payload)

            try:
                response = requests.post(
                    'https://localhost:7220/FormDepMedico/Actualizar/fichaCertOcup',
                    json=payload,
                    headers={"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"},
                    verify=False
                )

                print("Código de estado:", response.status_code)
                print("Cuerpo de la respuesta:", response.text)

                if response.status_code == 200:
                    flash(f'El formulario ha sido enviado con éxito. Código de respuesta: {response.status_code}', 'success')
                    print('Envio con exito')
                    return redirect(url_for('depmedico.formulario_success', campaign='depmedico'))
                else:
                    error_message = f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'
                    flash(error_message, 'error')
                    return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

            except requests.exceptions.RequestException as e:
                flash(f'Ocurrió un error al realizar la petición al API: {e}', 'error')
                return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

        except ValidationError as e:
            print("Error de validación:", e.json())
            errores = {err['loc'][0]: err['msg'] for err in e.errors()}
            flash(f'Error de validación: {e.json()}', 'error')
            session['show_full_form'] = True
            return render_template('error.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))

        except Exception as e:
            print("Error general:", str(e))
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            return render_template('error.html', errores={}, form_data=form_data)

    # Si no es POST, entonces renderizas la página normalmente
    return render_template('depmedico/dash_certificado.html', errores={}, form_data={})

#==================================== DESCARGAR EN EXCEL Y PDF OCUPACIONAL

# Descargar la ficha en formato PDF
@depmedico.route('/downloadPDF', methods=['GET', 'POST'])
def download_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaOcupacional', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_OCUPACIONAL.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")

                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Nombre_colaborador": (195, 133),  # Ajusta las coordenadas (x, y)
                        "Ci_colaborador": (455, 106),
                        "Edad": (150, 149),
                        "Sexo": (205, 149),
                        "Cargo": (295, 149),
                        "Tiempo_cargo": (455, 149),
                        "act_fisica": (196, 277),
                        "act_fisica_obser": (242, 278),
                        "medi_actual": (196, 290),
                        "medi_actual_obser": (242, 291),
                        "alcohol": (196, 304),
                        "alcohol_obser": (242, 304),
                        "tabaco": (196, 315),
                        "tabaco_obser": (242, 316),
                        "otros": (196, 327),
                        "otros_obser": (242, 328),

                        "incidente_trabajo": (180, 358),
                        "accidente_trabajo_calif": (180, 373),
                        "accidente_trabajo": (412, 372),
                        "accidente_trabajo_fecha": (450, 372),
                        "enfermedad_prof_calif": (180, 388),
                        "enfermedad_prof": (412, 387),
                        "enfermedad_prof_fecha": (450, 387),

                        "antecf_cardio_vas": (166, 416),
                        "antecf_metabotica": (230, 416),
                        "antecf_neurologica": (300, 416),
                        "antecf_oncologica": (374, 416),
                        "antecf_infecciosa": (444, 416),
                        "antecf_hereditario": (510, 416),

                        "fact_risg_trabajo_ruido": (206, 480),
                        "fact_risg_trabajo_polvos": (325, 480),
                        "fact_risg_trabajo_alta_respo": (483, 480),
                        "fact_risg_trabajo_iluminacion": (206, 495),
                        "fact_risg_trabajo_liquidos": (325, 495),
                        "fact_risg_trabajo_conflic_rol": (483, 495),
                        "fact_risg_trabajo_ventilacion": (206, 510),
                        "fact_risg_trabajo_virus": (325, 510),
                        "fact_risg_trabajo_sobrecarga_lab": (483, 510),
                        "fact_risg_trabajo_caidas_mismonivel": (206, 525),
                        "fact_risg_trabajo_posturas": (325, 525),
                        "fact_risg_trabajo_inestabilidad_lab": (483, 525),
                        "fact_risg_trabajo_atropellamiento_vehi": (206, 539),
                        "fact_risg_trabajo_mov_repetitivo": (325, 539),
                        "fact_risg_trabajo_rela_interp": (483, 539),
                        "fact_risg_trabajo_caidas_desnivel": (206, 551),
                        "fact_risg_trabajo_monotomia": (325, 551),

                        "sso_salud_mental": (256, 571),
                        "sso_riesgo_lab": (256, 582),
                        "sso_pausas_activas": (256, 593),

                        "inmuni_influenza": (222, 613),
                        "inmuni_tetano": (276, 613),
                        "inmuni_hepatitisB": (355, 613),
                        "inmuni_coviddosis": (452, 613),

                        "organosysis_piel_anexo": (163, 640),
                        "organosysis_genito_urinario": (163, 654),
                        "organosysis_respiratorio": (225, 640),
                        "organosysis_endocrino": (225, 654),
                        "organosysis_digestivo": (276, 640),
                        "organosysis_nervioso": (276, 654),
                        "organosysis_musculo_esqueletico": (354, 640),
                        "organosysis_cardiovascular": (354, 654),
                        "organosysis_hemolinf": (424, 640),
                        "organosysis_orgsentidos": (500, 640),
                        "organosysis_descripcion": (115, 686),
                        # Agrega más campos y sus posiciones aquí
                    }
                    
                    positions_page2 = {  
                        "examn_fis_garganta": (195, 154),      
                        "examn_fis_ojos": (195, 166),      
                        "examn_fis_oidos": (195, 178),
                        "examn_fis_nariz": (195, 190),
                        "examn_fis_boca": (195, 202),
                        "examn_fis_dentudura": (195, 215),
                        "examn_fis_corazon": (195, 238),
                        "examn_fis_pulmones": (195, 250),
                        "examn_fis_inspeccion": (195, 275),
                        "examn_fis_palpacion": (195, 287),
                        "examn_fis_percsusion": (195, 300),

                        "examn_fis_umbilical": (322, 155),      
                        "examn_fis_ingual_dere": (322, 167),      
                        "examn_fis_clural_dere": (322, 179),      
                        "examn_fis_inguinal_izquierdo": (322, 191),      
                        "examn_fis_clural_izq": (322, 203),      
                        "examn_fis_deformaciones": (322, 226),      
                        "examn_fis_movilidad": (322, 238),      
                        "examn_fis_masas_musculares": (322, 250),      
                        "examn_fis_tracto_urinario": (322, 275),      
                        "examn_fis_tracto_genital": (322, 288),      
                        "examn_fis_regio_anoperineal": (322, 300),      

                        "examn_fis_sup_izquierda": (483 , 155),      
                        "examn_fis_infer_dere": (483, 167),      
                        "examn_fis_infer_izquierda": (483, 179),      
                        "examn_fis_reflejos_tndinosos": (483, 203),          
                        "examn_fis_sencibilidad_sup": (483, 215),          
                        "examn_fis_reflejos_pupilares": (483, 226),          
                        "examn_fis_ojo_derecho": (483, 251),          
                        "examn_fis_ojo_izquierdo": (483, 264),          
                        "examn_fis_oido_derecho": (483, 287),          
                        "examn_fis_oido_izquierdo": (483, 300),          

                        "laboratorio": (180, 370),  
                        "rx": (180, 381),  
                        "audiometria": (180, 392),  
                        "optometria": (180, 403),  
                        "ekg": (180, 414),  

                        "cie10_1": (320, 445),  
                        "cie10_2": (320, 464),  
                        "cie10_3": (320, 482),  
                        "cie10_4": (320, 502),

                        "aptitud": (180, 578),  
                        "aptitud_observ": (180, 595),  
                        "aptitud_limitacion": (180, 614),  
                        "Fecha_actualizacion":  (295, 688), 
                    }

                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6)

                    elif page_num == 1:  # Segunda página
                        # Imprimir datos del segundo diccionario
                        for field_name, position in positions_page2.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6)
                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('firma_colaborador', '')
                        firma_doctor = base_firma_doc

                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(370, 670, 475, 705)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')

                        # Proceso de la firma del doctor
                        if firma_doctor:
                            if firma_doctor.startswith('data:image/png;base64,'):
                                firma_doctor = firma_doctor.split(',')[1]

                            if len(firma_doctor) % 4:
                                firma_doctor += '=' * (4 - len(firma_doctor) % 4)

                            try:
                                print('Procesando firma doctor...', firma_doctor)
                                data_sign = resize_image_base64(firma_doctor, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(180, 720-60, 280, 755-25)  # Ajustado 50 unidades más abajo

                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma doctor añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')

                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')
                return send_file(pdf_path_output, as_attachment=True, download_name='FICHA_OCUPACIONAL_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_ocupacional.html')

#Descargar la ficha en formato XLSX
@depmedico.route('/downloadExcel', methods=['GET','POST'])
def download_excel():
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaOcupacional', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print(response_data)
                # Diccionario de coordenadas
                cual = "                        /Cual:"
                accidente_trabajo = f"Calificado: {response_data.get('accidente_trabajo', 'N/A')}      Fecha:"
                enfermedad_prof = f"Calificado: {response_data.get('enfermedad_prof', 'N/A')}      Fecha:"
                inmuni_influenza = f"INFLUENZA:  {response_data.get('inmuni_influenza', 'N/A')}"
                inmuni_tetano = f"TETANO:  {response_data.get('inmuni_tetano', 'N/A')}"
                inmuni_hepatitisB = f"HEPATITIS B:  {response_data.get('inmuni_hepatitisB', 'N/A')}"
                inmuni_coviddosis = f"COVID DOSIS #:  {response_data.get('inmuni_coviddosis', 'N/A')}"
                
                antecf_cardio_vas = f"Cardio-vascular:   {response_data.get('antecf_cardio_vas', 'N/A')}"
                antecf_metabotica = f"Metabolica:   {response_data.get('antecf_metabotica', 'N/A')}"
                antecf_neurologica = f"Neurologica:   {response_data.get('antecf_neurologica', 'N/A')}"
                antecf_oncologica = f"Oncologica:   {response_data.get('antecf_oncologica', 'N/A')}"
                antecf_infecciosa = f"Infecciosa:   {response_data.get('antecf_infecciosa', 'N/A')}"
                antecf_hereditario = f"Hereditaria:   {response_data.get('antecf_hereditario', 'N/A')}"

                organosysis_piel_anexo = f"Piel y anexo:              {response_data.get('organosysis_piel_anexo', 'N/A')}"
                organosysis_genito_urinario = f"Genito-urinario:       {response_data.get('organosysis_genito_urinario', 'N/A')}"
                organosysis_respiratorio = f"  Respiratorio:            {response_data.get('organosysis_respiratorio', 'N/A')}"
                organosysis_endocrino = f"  Endocrino:              {response_data.get('organosysis_endocrino', 'N/A')}"
                organosysis_digestivo = f"Digestivo:              {response_data.get('organosysis_digestivo', 'N/A')}"
                organosysis_nervioso = f"Nervioso:              {response_data.get('organosysis_nervioso', 'N/A')}"
                organosysis_musculo_esqueletico = f"Musculo-esqueletico:       {response_data.get('organosysis_musculo_esqueletico', 'N/A')}"
                organosysis_cardiovascular = f"Cardio-Vascular:          {response_data.get('organosysis_cardiovascular', 'N/A')}"
                organosysis_hemolinf = f"Hemolinf.:                   {response_data.get('organosysis_hemolinf', 'N/A')}"
                organosysis_orgsentidos = f"Org. Sentidos:       {response_data.get('organosysis_orgsentidos', 'N/A')}"

                coordinates = {
                    'G3': cedula,
                    'B9': 'Edad:  ' + response_data.get('Edad', 'N/A'),
                    'C9': 'Sexo:  ' + response_data.get('Sexo', 'N/A'),

                    'E9': response_data.get('Cargo', 'N/A'),
                    'G9': response_data.get('Tiempo_cargo', 'N/A'),
                    'C7': response_data.get('Nombre_colaborador', 'N/A'),
                    'B18': response_data.get('antecep_clinicos', 'N/A'),
                                        
                    'C24': response_data.get('act_fisica', 'N/A')+ cual,
                    'D24': response_data.get('act_fisica_obser', 'N/A'),
                    'C26': response_data.get('medi_actual', 'N/A')+ cual,
                    'D26': response_data.get('medi_actual_obser', 'N/A'),
                    'C28': response_data.get('alcohol', 'N/A')+ cual,
                    'D28': response_data.get('alcohol_obser', 'N/A'),
                    'C30': response_data.get('tabaco', 'N/A')+ cual,
                    'D30': response_data.get('tabaco_obser', 'N/A'),
                    'C32': response_data.get('otros', 'N/A')+ cual,
                    'D32': response_data.get('otros_obser', 'N/A'),

 
                    'C36': response_data.get('incidente_trabajo', 'N/A'),
                    'C38': response_data.get('accidente_trabajo_calif', 'N/A'),
                    'G38': response_data.get('accidente_trabajo_fecha', 'N/A'),
                    'C40': response_data.get('enfermedad_prof_calif', 'N/A'),
                    'F40': enfermedad_prof,
                    'F38': accidente_trabajo,
                    'G40': response_data.get('enfermedad_prof_fecha', 'N/A'),


                    'B44': antecf_cardio_vas,
                    'C44': antecf_metabotica,
                    'D44': antecf_neurologica,
                    'E44': antecf_oncologica,
                    'F44': antecf_infecciosa,
                    'G44': antecf_hereditario,
                    'B47': response_data.get('antecf_observacion', 'N/A'),

                    'C51': response_data.get('fact_risg_trabajo_ruido', 'N/A'),
                    'C52': response_data.get('fact_risg_trabajo_iluminacion', 'N/A'),
                    'C53': response_data.get('fact_risg_trabajo_ventilacion', 'N/A'),
                    'C54': response_data.get('fact_risg_trabajo_caidas_mismonivel', 'N/A'),
                    'C55': response_data.get('fact_risg_trabajo_atropellamiento_vehi', 'N/A'),
                    'C56': response_data.get('fact_risg_trabajo_caidas_desnivel', 'N/A'),
                    'E51': response_data.get('fact_risg_trabajo_polvos', 'N/A'),
                    'E52': response_data.get('fact_risg_trabajo_liquidos', 'N/A'),
                    'E53': response_data.get('fact_risg_trabajo_virus', 'N/A'),
                    'E54': response_data.get('fact_risg_trabajo_posturas', 'N/A'),
                    'E55': response_data.get('fact_risg_trabajo_mov_repetitivo', 'N/A'),
                    'E56': response_data.get('fact_risg_trabajo_monotomia', 'N/A'),
                    'G51': response_data.get('fact_risg_trabajo_alta_respo', 'N/A'),
                    'G52': response_data.get('fact_risg_trabajo_conflic_rol', 'N/A'),
                    'G53': response_data.get('fact_risg_trabajo_sobrecarga_lab', 'N/A'),
                    'G54': response_data.get('fact_risg_trabajo_inestabilidad_lab', 'N/A'),
                    'G55': response_data.get('fact_risg_trabajo_rela_interp', 'N/A'),

                    'D58': response_data.get('sso_salud_mental', 'N/A'),
                    'D59': response_data.get('sso_riesgo_lab', 'N/A'),
                    'D60': response_data.get('sso_pausas_activas', 'N/A'),

                    'C62': inmuni_influenza,
                    'D62': inmuni_tetano,
                    'E62': inmuni_hepatitisB,
                    'F62': inmuni_coviddosis,
                    
                    'B65': organosysis_piel_anexo,
                    'B66': organosysis_genito_urinario,
                    'C65': organosysis_respiratorio,
                    'C66': organosysis_endocrino,
                    'D65': organosysis_digestivo,
                    'D66': organosysis_nervioso,
                    'E65': organosysis_musculo_esqueletico,
                    'E66': organosysis_cardiovascular,
                    'F65': organosysis_hemolinf,
                    'G65': organosysis_orgsentidos,
                    

                    'B69': response_data.get('organosysis_descripcion', 'N/A'),
                    'B77': response_data.get('examn_fis_cabeza', 'N/A'),
                    'E77': response_data.get('examn_fis_extremidades', 'N/A'),
                    
                    'C82': response_data.get('examn_fis_garganta', 'N/A'),
                    'C83': response_data.get('examn_fis_ojos', 'N/A'),
                    'C84': response_data.get('examn_fis_oidos', 'N/A'),
                    'C85': response_data.get('examn_fis_nariz', 'N/A'),
                    'C86': response_data.get('examn_fis_boca', 'N/A'),
                    'C87': response_data.get('examn_fis_dentudura', 'N/A'),

                    'C89': response_data.get('examn_fis_corazon', 'N/A'),
                    'C90': response_data.get('examn_fis_pulmones', 'N/A'),

                    'C92': response_data.get('examn_fis_inspeccion', 'N/A'),
                    'C93': response_data.get('examn_fis_palpacion', 'N/A'),
                    'C94': response_data.get('examn_fis_percsusion', 'N/A'),

                    'E82': response_data.get('examn_fis_umbilical', 'N/A'),
                    'E83': response_data.get('examn_fis_ingual_dere', 'N/A'),
                    'E84': response_data.get('examn_fis_clural_dere', 'N/A'),
                    'E85': response_data.get('examn_fis_inguinal_izquierdo', 'N/A'),
                    'E86': response_data.get('examn_fis_clural_izq', 'N/A'),
                    
                    'E88': response_data.get('examn_fis_deformaciones', 'N/A'),
                    'E89': response_data.get('examn_fis_movilidad', 'N/A'),
                    'E90': response_data.get('examn_fis_masas_musculares', 'N/A'),
                    
                    'E92': response_data.get('examn_fis_tracto_urinario', 'N/A'),
                    'E93': response_data.get('examn_fis_tracto_genital', 'N/A'),
                    'E94': response_data.get('examn_fis_regio_anoperineal', 'N/A'),

                    'G82': response_data.get('examn_fis_sup_izquierda', 'N/A'),
                    'G83': response_data.get('examn_fis_infer_dere', 'N/A'),
                    'G84': response_data.get('examn_fis_infer_izquierda', 'N/A'),
                    
                    'G86': response_data.get('examn_fis_reflejos_tndinosos', 'N/A'),
                    'G87': response_data.get('examn_fis_sencibilidad_sup', 'N/A'),
                    'G88': response_data.get('examn_fis_reflejos_pupilares', 'N/A'),

                    'G90': response_data.get('examn_fis_ojo_derecho', 'N/A'),
                    'G91': response_data.get('examn_fis_ojo_izquierdo', 'N/A'),

                    'G93': response_data.get('examn_fis_oido_derecho', 'N/A'),
                    'G94': response_data.get('examn_fis_oido_izquierdo', 'N/A'),


                    'B97': response_data.get('examn_fis_descripcion', 'N/A'),
    
                    
                    'C101': response_data.get('laboratorio', 'N/A'),
                    'C102': response_data.get('rx', 'N/A'),
                    'C103': response_data.get('audiometria', 'N/A'),
                    'C104': response_data.get('optometria', 'N/A'),
                    'C105': response_data.get('ekg', 'N/A'),
                    
                    'B108': response_data.get('diagnostico_1', 'N/A'),
                    'B109': response_data.get('diagnostico_2', 'N/A'),
                    'B110': response_data.get('diagnostico_3', 'N/A'),
                    'B111': response_data.get('diagnostico_4', 'N/A'),
                    'E108': response_data.get('cie10_1', 'N/A'),
                    'E109': response_data.get('cie10_2', 'N/A'),
                    'E110': response_data.get('cie10_3', 'N/A'),
                    'E111': response_data.get('cie10_4', 'N/A'),
                    
                    'C117': response_data.get('aptitud', 'N/A'),
                    'C119': response_data.get('aptitud_observ', 'N/A'),
                    'C121': response_data.get('aptitud_limitacion', 'N/A'),
                    
                    'B124': response_data.get('recomendaciones_tto', 'N/A'),
                    
                    'F128': response_data.get('fecha', 'N/A'),
                    #'C128': response_data.get('Usuario_actualizacion', 'N/A'),

                }
                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_OCUPACIONAL.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['Sheet1']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('firma_colaborador', '')
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_OCUPACIONALTEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/FICHA_OCUPACIONALTEMP.png')
                        ws.add_image(img_colaborador, 'F130')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')

                # Procesar y redimensionar firma del doctor (similar al colaborador)
                firma_doctor = base_firma_doc
                if firma_doctor:
                    if firma_doctor.startswith('data:image/png;base64,'):
                        firma_doctor = firma_doctor.split(',')[1]
                    if len(firma_doctor) % 4:
                        firma_doctor += '=' * (4 - len(firma_doctor) % 4)

                    try:
                        print('Procesando firma del doctor...')
                        data_sign = resize_image_base64(firma_doctor, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        # Guardar la firma redimensionada temporalmente
                        tempxlsx2 = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_OCUPACIONALTEMP2.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx2, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_doctor = ExcelImage('files/FICHA_OCUPACIONALTEMP2.png')
                        ws.add_image(img_doctor, 'C130')  # Ajusta la posición según sea necesario
                        print('Firma del doctor añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del doctor: {e}')


                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'FICHA_OCUPACIONAL_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_ocupacional.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_ocupacional.html')

#----------------------------------- CONSENTIMIENTO EXCEL
@depmedico.route('/consentimiento_excel', methods=['GET','POST'])
def consentimiento_excel():
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaConsInformado', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            
            if response.status_code == 201:
                response_data = response.json()
                print(response_data)
                # Diccionario de coordenadas
                coordinates = {
                    'D8': response_data.get('Nombre','N/A'),
                    'J8': response_data.get('Cedula', 'N/A'),
                    'D20': response_data.get('Fecha', 'N/A')
                }
                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'CONSENTIMIENTO_INFORMADO.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['Hoja1']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('Firma', '')
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'CONSENTIMIENTOTEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/CONSENTIMIENTOTEMP.png')
                        ws.add_image(img_colaborador, 'F24')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')

                                # Procesar y redimensionar firma del colaborador
                firma_doc = response_data.get('Firma_doc', '')
                if firma_doc:
                    if firma_doc.startswith('data:image/png;base64,'):
                        firma_doc = firma_doc.split(',')[1]
                    if len(firma_doc) % 4:
                        firma_doc += '=' * (4 - len(firma_doc) % 4)

                    try:
                        print('Procesando firma del doctor...')
                        data_sign = resize_image_base64(firma_doc, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'CONSENTIMIENTO2_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/CONSENTIMIENTO2_TEMP.png')
                        ws.add_image(img_colaborador, 'C24')  # Ajusta la posición según sea necesario
                        print('Firma del doctor añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del doctor: {e}')

                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'CONSENTIMIENTO_INFORMADO_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_consentimiento.html')

# Descargar la ficha en formato PDF
@depmedico.route('/consentimiento_pdf', methods=['GET', 'POST'])
def consentimiento_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaConsInformado', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'CONSENTIMIENTO_INFORMADO.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")

                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Nombre": (80, 111),
                        "Cedula": (485, 111),
                        "Fecha": (104, 275)
                    }

                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                if field_value:  # Asegúrate de que el valor no sea nulo o vacío
                                    print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                    # Ajuste en el tamaño de fuente a 10 para mejor visibilidad
                                    page.insert_text(position, str(field_value), fontsize=10, color=(0, 0, 0))
                                else:
                                    print(f"El campo '{field_name}' está vacío en response_data")


                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('Firma', '')

                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(370-200, 670-375, 475-200, 705-375)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')

                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')

                return send_file(pdf_path_output, as_attachment=True, download_name='CONSENTIMIENTO_INFORMADO_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_consentimiento.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_consentimiento.html')


#-------------------------------  CERTIFICADO OCUPACIONAL

@depmedico.route('/certificado_excel', methods=['GET','POST'])
def certificado_excel():
    
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaCertOcup', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            
            if response.status_code == 201:
                response_data = response.json()

                print(response_data)
                # Diccionario de coordenadas
                edad = response_data.get('Edad')
                sexo = response_data.get('Sexo')
                periodico = response_data.get('Periodico')
                reintegro = response_data.get('Reintegro')
                apto = response_data.get('Apto')
                no_apto = response_data.get('No_apto')
                apto_limitaciones = response_data.get('Apto_limitaciones')
                fecha_emision_raw = response_data.get('Fecha_emision')
                fecha_emision = datetime.strptime(fecha_emision_raw, "%Y-%m-%d")
                dia = fecha_emision.day
                mes = fecha_emision.month
                anio = fecha_emision.year

                print(f'MESSS: {mes}')

                coordinates = {
                    'D8': response_data.get('Nombre','N/A'),
                    'G2': response_data.get('Cedula', 'N/A'),
                    'G4': response_data.get('NHC', 'N/A'),
                    'B10' : f'Edad:  {edad}',
                    'C10' : f'Sexo:  {sexo}',
                    'E10' : response_data.get('Cargo'),
                    'H10' : response_data.get('Tiempo_cargo'),
                    'D14' : str(dia),
                    'E14' : str(mes),
                    'F14' : str(anio),
                    'E17' : response_data.get('Ingreso'),
                    'F17' : f'PERIÓDICO  {periodico}',
                    'H17' : f'REINTEGRO  {reintegro}',
                    'B23' : f'APTO:      {apto}',
                    'D23' : response_data.get('Apto_observación'),
                    'E23' : f'APTO con limitaciones:  {apto_limitaciones}',
                    'H23' : f'NO APTO:  {no_apto}',
                    'B27' : response_data.get('Apto_detalles'),
                    'B33' : response_data.get('Recomendaciones'),
                    'F43' : response_data.get('Fecha_actualizacion'),
                    'C43' : session['nombreColaborador']

                }

                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'CERTIFICADO_OCUPACIONAL.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['CERTIFICADO OCUPACIONAL']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('Firma_colaborador', '')
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'CERTIFICADO_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/CERTIFICADO_TEMP.png')
                        ws.add_image(img_colaborador, 'F44')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')

                firma_doctor = base_firma_doc
                if firma_doctor:
                    if firma_doctor.startswith('data:image/png;base64,'):
                        firma_doctor = firma_doctor.split(',')[1]
                    if len(firma_doctor) % 4:
                        firma_doctor += '=' * (4 - len(firma_doctor) % 4)

                    try:
                        print('Procesando firma del doctor...')
                        data_sign = resize_image_base64(firma_doctor, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        # Guardar la firma redimensionada temporalmente
                        tempxlsx2 = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_OCUPACIONALTEMP2.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx2, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_doctor = ExcelImage('files/FICHA_OCUPACIONALTEMP2.png')
                        ws.add_image(img_doctor, 'C44')  # Ajusta la posición según sea necesario
                        print('Firma del doctor añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del doctor: {e}')


                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'CERTIFICADO_OCUPACIONAL_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_certificado.html')

@depmedico.route('/certificado_pdf', methods=['GET', 'POST'])
def certificado_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaCertOcup', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                print(response_data.get('Fecha_actualizacion'))
                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'CERTIFICADO_OCUPACIONAL.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")

                    # Obtener la fecha de emisión del response_data
                    fecha_emision_raw = response_data.get('Fecha_emision')
                    fecha_emision = datetime.strptime(fecha_emision_raw, "%Y-%m-%d")
                    dia = fecha_emision.day
                    mes = fecha_emision.month
                    anio = fecha_emision.year

                    # Definir las posiciones donde quieres que se impriman el día, mes y año en la página
                    # Estas posiciones son solo ejemplos, cámbialas según la ubicación que necesites
                    posicion_dia = (260, 298)  # Coordenada para el día
                    posicion_mes = (325, 298)  # Coordenada para el mes
                    posicion_anio = (375, 298)  # Coordenada para el año
                    # Imprimir el día, mes y año en la página
                    page.insert_text(posicion_dia, str(dia), fontsize=10, color=(0, 0, 0))
                    page.insert_text(posicion_mes, str(mes), fontsize=10, color=(0, 0, 0))
                    page.insert_text(posicion_anio, str(anio), fontsize=10, color=(0, 0, 0))

                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Nombre": (247, 230),
                        "Cedula": (420, 165),
                        "NHC": (420, 185),
                        "Edad": (137, 250),
                        "Sexo": (189, 255),
                        "Cargo": (294, 255),
                        "Tiempo_cargo": (480, 255),
                        "Ingreso":(288, 328),
                        "Periodico":(414, 328),
                        "Reintegro":(513, 328),

                        "Apto":(140, 382),
                        "Apto_observacion":(272, 382),
                        "Apto_limitaciones":(412, 382),
                        "No_apto":(495, 382),

                    }

                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                if field_value:  # Asegúrate de que el valor no sea nulo o vacío
                                    print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                    # Ajuste en el tamaño de fuente a 10 para mejor visibilidad
                                    page.insert_text(position, str(field_value), fontsize=10, color=(0, 0, 0))
                                else:
                                    print(f"El campo '{field_name}' está vacío en response_data")

                                        # Define el área donde se imprimirá el texto de "Apto_detalles" y "Recomendaciones"
                        detalles_apto = response_data.get('Apto_detalles', 'Sin detalles disponibles.')
                        recomendaciones = response_data.get('Recomendaciones', 'Sin recomendaciones.')
                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        rect_detalles_apto = fitz.Rect(110, 415, 533, 457)
                        rect_recomendaciones = fitz.Rect(110, 485, 533, 530)

                        # Dibujar un borde alrededor del área de "Apto_detalles"
                        #page.draw_rect(rect_detalles_apto, color=(0, 0, 0), width=1)

                        # Insertar el texto ajustado en el área definida para "Apto_detalles"
                        # 'clip' asegurará que solo el texto que cabe se muestre
                        page.insert_textbox(rect_detalles_apto, detalles_apto, fontsize=9, color=(0, 0, 0), align=fitz.TEXT_ALIGN_JUSTIFY)

                        # Dibujar un borde alrededor del área de "Recomendaciones"
                        #page.draw_rect(rect_recomendaciones, color=(0, 0, 0), width=1)

                        # Insertar el texto ajustado en el área definida para "Recomendaciones"
                        # El parámetro 'clip' corta el texto al área definida por el rectángulo
                        page.insert_textbox(rect_recomendaciones, recomendaciones, fontsize=9, color=(0, 0, 0), align=fitz.TEXT_ALIGN_JUSTIFY)


                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('Firma_colaborador', '')

                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(370+10, 670-75, 475+10, 705-75)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')

                                                # Imprimir la imagen de la firma en el PDF
                        firma_doc = base_firma_doc

                        # Proceso de la firma del colaborador
                        if firma_doc:
                            if firma_doc.startswith('data:image/png;base64,'):
                                firma_doc = firma_doc.split(',')[1]

                            if len(firma_doc) % 4:
                                firma_doc += '=' * (4 - len(firma_doc) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_doc)
                                data_sign = resize_image_base64(firma_doc, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(370-200, 670-75, 475-200, 705-75)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')
                        

                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')
                return send_file(pdf_path_output, as_attachment=True, download_name='CERTIFICADO_OCUPACIONAL_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_certificado.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_certificado.html')


#-------------------------------  SEGUIMIENTO DROGAS
@depmedico.route('/seguimiento_excel', methods=['GET','POST'])
def seguimiento_excel():
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaSegDrogas', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )       

            
            if response.status_code == 201:

                response_data = response.json()



                coordinates = {
                    'C5': response_data.get('Cedula', 'N/A'),
                    'C6': response_data.get('Nombre','N/A'),
                    'C7': response_data.get('Cargo', 'N/A'),
                    'H5': response_data.get('Fecha_actualizacion', 'N/A'),
                    'H6': response_data.get('Edad', 'N/A'),
                    'H7': response_data.get('Tiempo_cargo', 'N/A'),
                    
                    'D11': response_data.get('Enfer_catastrofica', 'N/A'),
                    'D13': response_data.get('Enfer_cron_transmi', 'N/A'),
                    'D15': response_data.get('Enfer_cron_notransmi', 'N/A'),
                    'D17': response_data.get('Enfer_nodiagnosticada', 'N/A'),
                    'F35': response_data.get('Fact_psico_sociales_detalle', 'N/A')
                }

                droga = response_data.get('Droga', 'N/A')
                # Definir la coordenada dependiendo del valor de 'Droga'
                if droga == 'No Consume':
                    coordinates['D23'] = 'X'
                elif droga == 'Alcohol':
                    coordinates['D25'] = 'X'
                elif droga == 'Anfetaminas':
                    coordinates['D27'] = 'X'
                elif droga == 'Cigarrillo':
                    coordinates['D29'] = 'X'
                elif droga == 'Marihuana':
                    coordinates['D31'] = 'X'
                elif droga == 'Base de cocaina':
                    coordinates['D33'] = 'X'
                elif droga == 'Heroina':
                    coordinates['D35'] = 'X'
                elif droga == 'Tabaco':
                    coordinates['D37'] = 'X'
                elif droga == 'Morfina':
                    coordinates['D39'] = 'X'
                elif droga == 'Hongos':
                    coordinates['D41'] = 'X'
                elif droga == 'Drogas de sintesis':
                    coordinates['D43'] = 'X'
                elif droga == 'Inhalantes':
                    coordinates['D45'] = 'X'
                elif droga == 'Pegamentos':
                    coordinates['D47'] = 'X'
                else:
                    coordinates['D23'] = 'X'

                frecuencia_consumo = response_data.get('Frecuencia_consumo', 'N/A')

                if frecuencia_consumo == 'No consume':
                    coordinates['I23'] = 'X'
                elif frecuencia_consumo == '5-7 dias':
                    coordinates['I11'] = 'X'
                elif frecuencia_consumo == '2-4 veces':
                    coordinates['I13'] = 'X'
                elif frecuencia_consumo == '2-7 veces':
                    coordinates['I15'] = 'X'
                elif frecuencia_consumo == '1 vez por semana':
                    coordinates['I17'] = 'X'
                elif frecuencia_consumo == '2-12 veces Año':
                    coordinates['I19'] = 'X'
                elif frecuencia_consumo == '1 vez al Año':
                    coordinates['I21'] = 'X'
                else:
                    coordinates['D23'] = ''

                socializacion_personal = response_data.get('Socializacion_personal', 'N/A')

                if socializacion_personal == 'Si':
                    coordinates['H49'] = 'X'
                elif socializacion_personal == 'No':
                    coordinates['J49'] = 'X'
                else:
                    coordinates['D23'] = ''

                factores = response_data.get('Fact_psico_sociales', 'N/A')

                if factores == 'No':
                    coordinates['I29'] = 'X'
                elif factores == 'Si':
                    coordinates['I31'] = 'X'
                else:
                    coordinates['0'] = ''

                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_SEGUIMIENTO.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['Hoja1']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('Firma_colaborador', '')
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'SEGUIMIENTO_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/SEGUIMIENTO_TEMP.png')
                        ws.add_image(img_colaborador, 'E50')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')


                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'FICHA_SEGUIMIENTO_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_seg_drogas.html')

@depmedico.route('/seguimiento_pdf', methods=['GET', 'POST'])
def seguimiento_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaSegDrogas',
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                print(response_data.get('Fecha_actualizacion'))
                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_SEGUIMIENTO.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")


                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Cedula": (135, 138),
                        "Nombre": (135, 155),
                        "Cargo": (135, 173),
                        "Fecha_actualizacion": (425, 138),
                        "Edad": (425, 155),
                        "Tiempo_cargo": (425, 173),
                        "Enfer_catastrofica": (181, 212),
                        "Enfer_cron_transmi": (181, 235),
                        "Enfer_cron_notransmi": (181, 258),
                        "Enfer_nodiagnosticada": (181, 281),

                    }

                    
                    Droga = response_data.get('Droga', 'N/A')
                    print(Droga)
                    # Definir la posición dependiendo del valor de 'Droga'
                    if Droga == 'No consume':
                        positions_page1['Droga'] = (181, 343)
                    elif Droga == 'Alcohol':
                        positions_page1['Droga'] = (181, 365)
                    elif Droga == 'Anfetaminas':
                        positions_page1['Droga'] = (181, 387)
                    elif Droga == 'Cigarrillo':
                        positions_page1['Droga'] = (181, 408)
                    elif Droga == 'Marihuana':
                        positions_page1['Droga'] = (181, 430)
                    elif Droga == 'Base de cocaina':
                        positions_page1['Droga'] = (181, 452)
                    elif Droga == 'Heroina':
                        positions_page1['Droga'] = (181, 474)
                    elif Droga == 'Tabaco':
                        positions_page1['Droga'] = (181, 492)
                    elif Droga == 'Morfina':
                        positions_page1['Droga'] = (181, 514)
                    elif Droga == 'Hongos':
                        positions_page1['Droga'] = (181, 536)
                    elif Droga == 'Drogas de sintesis':
                        positions_page1['Droga'] = (181, 558)
                    elif Droga == 'Inhalantes':
                        positions_page1['Droga'] = (181, 580)
                    elif Droga == 'Pegamentos':
                        positions_page1['Droga'] = (181, 601)
                    else:
                        print('No es un valor valido')
                    
                    Socializacion = response_data.get('Socializacion_personal', 'N/A')
                    print(Socializacion)
                    # Definir la posición dependiendo del valor de 'Droga'
                    if Socializacion == 'Si':
                        positions_page1['Socializacion'] = (447, 618)
                    elif Socializacion == 'No':
                        positions_page1['Socializacion'] = (494, 618)
                    else:
                        print('No es un valor valido')

                    Factores = response_data.get('Fact_psico_sociales', 'N/A')
                    print(Factores)
                    # Definir la posición dependiendo del valor de 'Droga'
                    if Factores == 'Si':
                        positions_page1['Factores'] = (422, 409)
                    elif Factores == 'No':
                        positions_page1['Factores'] = (422, 433)
                    else:
                        print('No es un valor valido')

                    Frecuencia = response_data.get('Frecuencia_consumo', 'N/A')
                    print(Frecuencia)
                    # Definir la posición dependiendo del valor de 'Droga'
                    if Frecuencia == 'No consume':
                        positions_page1['Frecuencia'] = (422, 344)
                    elif Frecuencia == '5-7 dias':
                        positions_page1['Frecuencia'] = (422, 212)
                    elif Frecuencia == '2-4 veces':
                        positions_page1['Frecuencia'] = (422, 234)
                    elif Frecuencia == '2-7 veces':
                        positions_page1['Frecuencia'] = (422, 258)
                    elif Frecuencia == '1 vez po semana':
                        positions_page1['Frecuencia'] = (422, 278)
                    elif Frecuencia == '2-12 veces Año':
                        positions_page1['Frecuencia'] = (422, 299)
                    elif Frecuencia == '1 vez al Año':
                        positions_page1['Frecuencia'] = (422, 322)
                    else:
                        print('No es un valor valido')

    
                    # Imprimir la "X" en la posición correspondiente a 'Droga'
                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name == 'Droga':
                                # Imprimir una "X" en la posición correspondiente
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))

                            elif field_name == 'Factores':
                                # Imprimir una "X" en la posición correspondiente
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))

                            elif field_name == 'Socializacion':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))

                            elif field_name == 'Frecuencia':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))

                            elif field_name in response_data:
                                field_value = response_data[field_name]
                                if field_value:  # Asegúrate de que el valor no sea nulo o vacío
                                    print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                    page.insert_text(position, str(field_value), fontsize=10, color=(0, 0, 0))
                                else:
                                    print(f"El campo '{field_name}' está vacío en response_data")

                                        # Define el área donde se imprimirá el texto de "Apto_detalles" y "Recomendaciones"
                        detalles_factores = response_data.get('Fact_psico_sociales_detalle', '')


                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        rect_detalles_apto = fitz.Rect(110+171, 415+48, 533+171, 457+48)

                        page.insert_textbox(rect_detalles_apto, detalles_factores, fontsize=9, color=(0, 0, 0), align=fitz.TEXT_ALIGN_JUSTIFY)

                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('Firma_colaborador', '')

                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(370-125, 670-28, 475-125, 705-28)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')


                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')
                return send_file(pdf_path_output, as_attachment=True, download_name='FICHA_SEGUIMIENTO_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_seg_drogas.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_seg_drogas.html')

#-------------------------------  CONSUMO DROGAS

@depmedico.route('/consumo_excel', methods=['GET','POST'])
def consumo_excel():
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaDrogas', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )       

            
            if response.status_code == 201:

                response_data = response.json()



                coordinates = {
                    'F6': response_data.get('Cedula', 'N/A'),
                    'F7': response_data.get('Tipo_sangre','N/A'),
                    'F8': response_data.get('Fecha_apertura_F_RPD', 'N/A'),
                    
                    'F10': response_data.get('Nombre', 'N/A'),
                    'E11': response_data.get('Edad', 'N/A'),
                    'E12': response_data.get('Dimicilio', 'N/A'),
                    'E13': response_data.get('Telefono', 'N/A'),
                    'E14': response_data.get('Profesion', 'N/A'),
                    'E15': response_data.get('Religion', 'N/A'),

                    'I11': response_data.get('Estado_civil', 'N/A'),
                    'I12': response_data.get('Cargo', 'N/A'),
                    'I14': response_data.get('Email', 'N/A'),
                    
                    'J31': response_data.get('Enfer_catastrofica', 'N/A'),
                    'J32': response_data.get('Enfer_cron_transmi', 'N/A'),
                    'J33': response_data.get('Enfer_cron_notransmi', 'N/A'),
                    'J34': response_data.get('Diag_presuntivo', 'N/A'),
                    
                    'J23': response_data.get('Disca_auditiva'),
                    'J24': response_data.get('Disca_fisica'),
                    'J25': response_data.get('Disca_intelectual'),
                    'J26': response_data.get('Lenguaje'),
                    'J27': response_data.get('Psico_social'),
                    'J28': response_data.get('Visual'),
                    
                    'H49': response_data.get('Droga_detalles'),
                    'D91': response_data.get('Factores_psicosociales_otros'),
                    
                    
  
                }

                instruccion = response_data.get('Nivel_instrucción', 'N/A')
                # Definir la coordenada dependiendo del valor de 'Droga'
                if instruccion == 'basica':
                    coordinates['F18'] = 'X'
                elif instruccion == 'bachiller':
                    coordinates['F19'] = 'X'
                elif instruccion == 'tercer_nivel':
                    coordinates['F20'] = 'X'
                elif instruccion == 'tecnico_superior':
                    coordinates['F21'] = 'X'
                elif instruccion == 'tecnologo':
                    coordinates['F22'] = 'X'
                elif instruccion == 'licenciado':
                    coordinates['F23'] = 'X'
                elif instruccion == 'ingeniero':
                    coordinates['F24'] = 'X'
                elif instruccion == 'cuarto_nivel':
                    coordinates['F25'] = 'X'
                elif instruccion == 'especializacion':
                    coordinates['F26'] = 'X'
                elif instruccion == 'maestria':
                    coordinates['F27'] = 'X'
                elif instruccion == 'postgrado':
                    coordinates['F28'] = 'X'

                else:
                    print("No hay valor") 

                factores = response_data.get('Factores_psicosociales', 'N/A')
                # Definir la coordenada dependiendo del valor de 'Nivel_instrucción'
                if factores == 'no_aplica':
                    coordinates['I68'] = 'X'
                elif factores == 'agobio_tension_trabajo':
                    coordinates['I69'] = 'X'
                elif factores == 'acoso_laboral':
                    coordinates['I70'] = 'X'
                elif factores == 'cansancio_intenso':
                    coordinates['I71'] = 'X'
                elif factores == 'companeros_consumidores':
                    coordinates['I72'] = 'X'
                elif factores == 'contratos_precarios':
                    coordinates['I73'] = 'X'
                elif factores == 'curiosidad_efectos_drogas':
                    coordinates['I74'] = 'X'
                elif factores == 'dificultad_resolucion_problemas':
                    coordinates['I75'] = 'X'
                elif factores == 'niveles_tension':
                    coordinates['I76'] = 'X'
                elif factores == 'expendo_drogas_trabajo':
                    coordinates['I77'] = 'X'
                elif factores == 'familiares_consumidores':
                    coordinates['I78'] = 'X'
                elif factores == 'insatisfaccion_trabajo':
                    coordinates['I79'] = 'X'
                elif factores == 'insatisfaccion_trato_superiores':
                    coordinates['I80'] = 'X'
                elif factores == 'inseguridad_futuro_laboral':
                    coordinates['I81'] = 'X'
                elif factores == 'ausencias_hogar_laboral':
                    coordinates['I82'] = 'X'
                elif factores == 'mala_situacion_economica_familia':
                    coordinates['I83'] = 'X'
                elif factores == 'conciliacion_tareas_domesticas':
                    coordinates['I84'] = 'X'
                elif factores == 'sentimiento_poco_capacitado':
                    coordinates['I85'] = 'X'
                elif factores == 'tareas_rutinarias':
                    coordinates['I86'] = 'X'
                elif factores == 'trabajos_nocturnos':
                    coordinates['I87'] = 'X'
                elif factores == 'turnos_cambiantes':
                    coordinates['I88'] = 'X'
                else:
                    print("No hay valor")



                etnia = response_data.get('Etnia', 'N/A')
                if etnia == 'mestizo':
                    coordinates['J18'] = 'X'
                elif etnia == 'afro_ecuatoriano':
                    coordinates['J19'] = 'X'
                elif etnia == 'blanco':
                    coordinates['J20'] = 'X'
                elif etnia == 'otro':
                    coordinates['J21'] = 'X'
                else:
                    print("No hay valor") 

                sustituto = response_data.get('Trabajador_sustituto', 'N/A')
                if sustituto == 'Si':
                    coordinates['J37'] = 'X'
                elif sustituto == 'No':
                    coordinates['J38'] = 'X'
                else:
                    print("No hay valor") 

                tratamiento = response_data.get('Tratamiento', 'N/A')
                if tratamiento == 'Si':
                    coordinates['J58'] = 'X'
                elif tratamiento == 'No':
                    coordinates['J59'] = 'X'
                elif tratamiento == 'No consume':
                    coordinates['J60'] = 'X'
                else:
                    print("No hay valor") 


                droga = response_data.get('Droga', 'N/A')
                # Definir la coordenada dependiendo del valor de 'Droga'
                if droga == 'No Consume':
                    coordinates['J44'] = 'X'
                elif droga == 'Alcohol':
                    coordinates['F44'] = 'X'
                elif droga == 'Anfetaminas':
                    coordinates['F45'] = 'X'
                elif droga == 'Cigarrillo':
                    coordinates['F46'] = 'X'
                elif droga == 'Marihuana':
                    coordinates['F47'] = 'X'
                elif droga == 'Base de cocaina':
                    coordinates['F48'] = 'X'
                elif droga == 'Heroina':
                    coordinates['F49'] = 'X'
                elif droga == 'Tabaco':
                    coordinates['F50'] = 'X'
                elif droga == 'Morfina':
                    coordinates['F51'] = 'X'
                elif droga == 'Hongos':
                    coordinates['F52'] = 'X'
                elif droga == 'Drogas de sintesis':
                    coordinates['F53'] = 'X'
                elif droga == 'Inhalantes':
                    coordinates['F54'] = 'X'
                elif droga == 'Pegamentos':
                    coordinates['F55'] = 'X'
                else:
                    print("No hay valor") 

                frecuencia_consumo = response_data.get('Frecuencia_consumo', 'N/A')

                if frecuencia_consumo == 'No consume':
                    coordinates['F64'] = 'X'
                elif frecuencia_consumo == '5-7 dias':
                    coordinates['F58'] = 'X'
                elif frecuencia_consumo == '2-4 veces':
                    coordinates['F59'] = 'X'
                elif frecuencia_consumo == '2-7 veces':
                    coordinates['F60'] = 'X'
                elif frecuencia_consumo == '1 vez por semana':
                    coordinates['F61'] = 'X'
                elif frecuencia_consumo == '2-12 veces Año':
                    coordinates['F62'] = 'X'
                elif frecuencia_consumo == '1 vez al Año':
                    coordinates['F63'] = 'X'
                else:
                    print("No hay valor")
                    
                porcentaje = response_data.get('Porcentaje_disca', 'N/A')

                if porcentaje == '30':
                    coordinates['F31'] = 'X'
                elif porcentaje == '40':
                    coordinates['F32'] = 'X'
                elif porcentaje == '50':
                    coordinates['F33'] = 'X'
                elif porcentaje == '60':
                    coordinates['F34'] = 'X'
                elif porcentaje == '70':
                    coordinates['F35'] = 'X'
                elif porcentaje == '80':
                    coordinates['F36'] = 'X'
                elif porcentaje == '90':
                    coordinates['F37'] = 'X'
                elif porcentaje == '100':
                    coordinates['F38'] = 'X'
                else:
                    print("No hay valor")

                socializacion_personal = response_data.get('Socializacion_personal', 'N/A')

                if socializacion_personal == 'Si':
                    coordinates['H49'] = 'X'
                elif socializacion_personal == 'No':
                    coordinates['J49'] = 'X'
                else:
                    print("No hay valor")       

                factores = response_data.get('Fact_psico_sociales', 'N/A')

                if factores == 'No':
                    coordinates['I29'] = 'X'
                elif factores == 'Si':
                    coordinates['I31'] = 'X'
                else:
                    print("No hay valor") 

                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_CONSUMO.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['Hoja1']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('Firma_colaborador', '')
                firma_doc = base_firma_doc
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'SEGUIMIENTO_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/SEGUIMIENTO_TEMP.png')
                        ws.add_image(img_colaborador, 'D94')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')

                if firma_doc:
                    if firma_doc.startswith('data:image/png;base64,'):
                        firma_doc = firma_doc.split(',')[1]
                    if len(firma_doc) % 4:
                        firma_doc += '=' * (4 - len(firma_doc) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_doc, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'CONSUMO_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/CONSUMO_TEMP.png')
                        ws.add_image(img_colaborador, 'H94')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del doctor: {e}')


                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'FICHA_CONSUMO_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_cons_drogas.html')

@depmedico.route('/consumo_pdf', methods=['GET', 'POST'])
def consumo_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaDrogas',
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                print(response_data.get('Fecha_actualizacion'))
                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_CONSUMO.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")


                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Cedula": (214, 85),
                        "Tipo_sangre" : (214, 102),                   
                        "Fecha_apertura_F_RPD": (214, 118),
                        
                        "Nombre" : (214, 150),
                        "Edad": (162, 165),
                        "Dimicilio" : (162, 182),
                        "Telefono" : (162, 200),
                        "Profesion" : (162, 215),
                        "Religion" : (162, 233),
                        
                        "Estado_civil" : (380, 167),
                        "Cargo" : (380, 182),
                        "Email" : (380, 215),
                        
                        "Disca_auditiva" : (435, 358),
                        "Disca_fisica" : (435, 375),
                        "Disca_intelectual" : (435, 392),
                        "Lenguaje" : (435, 408),
                        "Psico_social" : (435, 425),
                        "Visual" : (435, 441),
                        
                        "Enfer_catastrofica" : (435, 492),
                        "Enfer_cron_transmi" : (435, 508),
                        "Enfer_cron_notransmi" : (435, 524),
                        "Diag_presuntivo" : (435, 541),
                        
                        

                    }
                                    
                    intruccion = response_data.get('Nivel_instrucción', 'N/A')
                    print(intruccion)
                    
                    if intruccion == 'basica':
                        positions_page1['intruccion'] = (204, 277)
                    elif intruccion == 'bachiller':
                        positions_page1['intruccion'] = (204, 294)
                    elif intruccion == 'tercer_nivel':
                        positions_page1['intruccion'] = (204, 311)
                    elif intruccion == 'tecnico_superior':
                        positions_page1['intruccion'] = (204, 325)
                    elif intruccion == 'tecnologo':
                        positions_page1['intruccion'] = (204, 344)
                    elif intruccion == 'licenciado':
                        positions_page1['intruccion'] = (204, 358)
                    elif intruccion == 'ingeniero':
                        positions_page1['intruccion'] = (204, 378)
                    elif intruccion == 'cuarto_nivel':
                        positions_page1['intruccion'] = (204, 394)
                    elif intruccion == 'especializacion':
                        positions_page1['intruccion'] = (204, 410)
                    elif intruccion == 'maestria':
                        positions_page1['intruccion'] = (204, 427)
                    elif intruccion == 'postgrado':
                        positions_page1['intruccion'] = (204, 443)
                    else:
                        print("Valor no valido")
                        
                        
                    porcentaje = response_data.get('Porcentaje_disca', 'N/A')
                    print(porcentaje)
                    
                    if porcentaje == '30':
                        positions_page1['porcentaje'] = (204, 490)
                    elif porcentaje == '40':
                        positions_page1['porcentaje'] = (204, 507)
                    elif porcentaje == '50':
                        positions_page1['porcentaje'] = (204, 521)
                    elif porcentaje == '60':
                        positions_page1['porcentaje'] = (204, 540)
                    elif porcentaje == '70':
                        positions_page1['porcentaje'] = (204, 557)
                    elif porcentaje == '80':
                        positions_page1['porcentaje'] = (204, 574)
                    elif porcentaje == '90':
                        positions_page1['porcentaje'] = (204, 590)
                    elif porcentaje == '100':
                        positions_page1['porcentaje'] = (204, 607)
                    else:
                        print("Valor no valido")

                    etnia = response_data.get('Etnia', 'N/A')
                    print(etnia)
                    
                    if etnia == 'mestizo':
                        positions_page1['etnia'] = (435, 277)
                    elif etnia == 'afro_ecuatoriano':
                        positions_page1['etnia'] = (435, 294)
                    elif etnia == 'blanco':
                        positions_page1['etnia'] = (435, 311)
                    elif etnia == 'otro':
                        positions_page1['etnia'] = (435, 327)
                    else:
                        print("Valor no valido")


                    etnia = response_data.get('Etnia', 'N/A')
                    print(etnia)
                    
                    if etnia == 'mestizo':
                        positions_page1['etnia'] = (435, 277)
                    elif etnia == 'afro_ecuatoriano':
                        positions_page1['etnia'] = (435, 294)
                    elif etnia == 'blanco':
                        positions_page1['etnia'] = (435, 311)
                    elif etnia == 'otro':
                        positions_page1['etnia'] = (435, 327)
                    else:
                        print("Valor no valido")
                    
                    sustituto = response_data.get('Trabajador_sustituto', 'N/A')
                    print(sustituto)
                    
                    if sustituto == 'Si':
                        positions_page1['sustituto'] = (436, 590)
                    elif sustituto == 'No':
                        positions_page1['sustituto'] = (436, 607)
                    
                    else:
                        print("Valor no valido")
                        
                                           
                    positions_page2 = {  

                    }

                    factores = response_data.get('Factores_psicosociales', 'N/A')
                    print('fACTORES:'+ factores)

                    if factores == 'no_aplica':
                        positions_page2['factores'] = (435, 472)
                    elif factores == 'agobio_tension_trabajo':
                        positions_page2['factores'] = (435, 488)
                    elif factores == 'acoso_laboral':
                        positions_page2['factores'] = (435, 507)
                    elif factores == 'cansancio_intenso':
                        positions_page2['factores'] = (435, 522)
                    elif factores == 'companeros_consumidores':
                        positions_page2['factores'] = (435, 539)
                    elif factores == 'contratos_precarios':
                        positions_page2['factores'] = (435, 556)
                    elif factores == 'curiosidad_efectos_drogas':
                        positions_page2['factores'] = (435, 572)
                    elif factores == 'dificultad_resolucion_problemas':
                        positions_page2['factores'] = (435, 588)
                    elif factores == 'niveles_tension':
                        positions_page2['factores'] = (435, 605)
                    elif factores == 'expendo_drogas_trabajo':
                        positions_page2['factores'] = (435, 620)
                    elif factores == 'familiares_consumidores':
                        positions_page2['factores'] = (435, 637)
                    elif factores == 'insatisfaccion_trabajo':
                        positions_page2['factores'] = (435, 652)
                    elif factores == 'insatisfaccion_trato_superiores':
                        positions_page2['factores'] = (435, 670)
                    elif factores == 'inseguridad_futuro_laboral':
                        positions_page2['factores'] = (435, 686)
                    elif factores == 'ausencias_hogar_laboral':
                        positions_page2['factores'] = (435, 704)
                    elif factores == 'mala_situacion_economica_familia':
                        positions_page2['factores'] = (435, 716)
                    elif factores == 'conciliacion_tareas_domesticas':
                        positions_page2['factores'] = (435, 732)
                    elif factores == 'sentimiento_poco_capacitado':
                        positions_page2['factores'] = (435, 748)


                    else:
                        print("Valor no válido")



                    
                    
                    frecuencia_consumo = response_data.get('Frecuencia_consumo', 'N/A')
                    print(frecuencia_consumo)
                    
                    if frecuencia_consumo == '5-7 dias':
                        positions_page2['frecuencia_consumo'] = (246, 310)
                    elif frecuencia_consumo == '2-4 veces':
                        positions_page2['frecuencia_consumo'] = (246, 327)
                    elif frecuencia_consumo == '2-7 veces':
                        positions_page2['frecuencia_consumo'] = (246, 344)
                    elif frecuencia_consumo == '1 vez po semana':
                        positions_page2['frecuencia_consumo'] = (246, 360)
                    elif frecuencia_consumo == '2-12 veces Año':
                        positions_page2['frecuencia_consumo'] = (246, 376)
                    elif frecuencia_consumo == '1 vez al Año':
                        positions_page2['frecuencia_consumo'] = (246, 394)
                    elif frecuencia_consumo == 'No consume':
                        positions_page2['frecuencia_consumo'] = (246, 410)
                    else:
                        print("Valor no valido")

                    tratamiento = response_data.get('Tratamiento', 'N/A')
                    print(tratamiento)
                    
                    if tratamiento == 'Si':
                        positions_page2['tratamiento'] = (435, 309)
                    elif tratamiento == 'No':
                        positions_page2['tratamiento'] = (435, 325)
                    elif tratamiento == 'No consume':
                        positions_page2['tratamiento'] = (435, 342)

                    else:
                        print("Valor no valido")


                    Droga = response_data.get('Droga', 'N/A')
                    print(Droga)
                    # Definir la posición dependiendo del valor de 'Droga'
                    if Droga == 'No consume':
                        positions_page2['Droga'] = (435, 80)
                    elif Droga == 'Alcohol':
                        positions_page2['Droga'] = (246, 80)
                    elif Droga == 'Anfetaminas':
                        positions_page2['Droga'] = (246, 96)
                    elif Droga == 'Cigarrillo':
                        positions_page2['Droga'] = (246, 113)
                    elif Droga == 'Marihuana':
                        positions_page2['Droga'] = (246, 129)
                    elif Droga == 'Base de cocaina':
                        positions_page2['Droga'] = (246, 146)
                    elif Droga == 'Heroina':
                        positions_page2['Droga'] = (246, 162)
                    elif Droga == 'Tabaco':
                        positions_page2['Droga'] = (246, 179)
                    elif Droga == 'Morfina':
                        positions_page2['Droga'] = (246, 196)
                    elif Droga == 'Hongos':
                        positions_page2['Droga'] = (246, 212)
                    elif Droga == 'Drogas de sintesis':
                        positions_page2['Droga'] = (246, 228)
                    elif Droga == 'Inhalantes':
                        positions_page2['Droga'] = (246, 245)
                    elif Droga == 'Pegamentos':
                        positions_page2['Droga'] = (246, 245+17)
                    else:
                        positions_page2['Droga'] = (435, 112)

                    positions_page3 = {  

                    }

                    factores2 = response_data.get('Factores_psicosociales', 'N/A')
                    print('fACTORES:'+ factores2)
                    
                    if factores2 == 'tareas_rutinarias':
                        positions_page3['factores2'] = (435, 44)
                    elif factores2 == 'trabajos_nocturnos':
                        positions_page3['factores2'] = (435, 64)
                    elif factores2 == 'turnos_cambiantes':
                        positions_page3['factores2'] = (435, 79)
                    
                    Examen = response_data.get('Exam_preocupacionales', 'N/A')
                    print(Examen)
                    # Definir la posición dependiendo del valor de 'Examen'
                    if Examen == 'Si':
                        positions_page3['Examen'] = (381, 146)
                    elif Examen == 'No':
                        positions_page3['Examen'] = (438, 146)
                    else:
                        positions_page3['Examen'] = (300, 148)
    
                    # Imprimir la "X" en la posición correspondiente a 'Droga'
                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name == 'intruccion':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'porcentaje':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'etnia':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'sustituto':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            elif field_name in response_data:
                                field_value = response_data[field_name]
                                if field_value:  # Asegúrate de que el valor no sea nulo o vacío
                                    print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                    page.insert_text(position, str(field_value), fontsize=10, color=(0, 0, 0))
                                else:
                                    print(f"El campo '{field_name}' está vacío en response_data")

                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('Firma_colaborador', '')
                        firma_doctor = base_firma_doc
                    
                    elif page_num == 1:
                        for field_name, position in positions_page2.items():
                            if field_name == 'Droga':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'frecuencia_consumo':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'tratamiento':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'factores':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            elif field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6)


                        droga_otros = response_data.get('Droga_detalles', '')

                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        droga_rect = fitz.Rect(310, 156, 480, 225)

                        page.insert_textbox(droga_rect, droga_otros, fontsize=9, color=(0, 0, 0), align=fitz.TEXT_ALIGN_LEFT, lineheight=1.7 )
                        
                    elif page_num == 2:
                        for field_name, position in positions_page3.items():
                            if field_name == 'Examen':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            if field_name == 'factores2':
                                page.insert_text(position, 'X', fontsize=10, color=(0, 0, 0))
                            elif field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6)
                        
                              
                        
                        detalles_factores = response_data.get('Factores_psicosociales_otros', '')

                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        rect_detalles_apto = fitz.Rect(110+2, 104, 533+2, 115)

                        page.insert_textbox(rect_detalles_apto, detalles_factores, fontsize=9, color=(0, 0, 0), align=fitz.TEXT_ALIGN_JUSTIFY)
                        
                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(180-30, 670-490, 280-30, 705-490)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')
                                
                                            # Proceso de la firma del doctor
                        if firma_doctor:
                            if firma_doctor.startswith('data:image/png;base64,'):
                                firma_doctor = firma_doctor.split(',')[1]

                            if len(firma_doctor) % 4:
                                firma_doctor += '=' * (4 - len(firma_doctor) % 4)

                            try:
                                print('Procesando firma doctor...', firma_doctor)
                                data_sign = resize_image_base64(firma_doctor, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)
                                signature_position = fitz.Rect(370-20, 670-490, 475-20, 705-475)

                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma doctor añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')                           


                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')
                return send_file(pdf_path_output, as_attachment=True, download_name='FICHA_CONSUMO_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_cons_drogas.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_cons_drogas.html')

#-------------------------------  PREOCUPACIONALES

@depmedico.route('/preocupacional_excel', methods=['GET','POST'])
def preocupacional_excel():
    if request.method == 'POST':
        print('Entra al post')
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula
        print("datos recibidos del formulario", form_data)
        
        payload = {
            "cedula": cedula
        }

        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaPreocupacional', 
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )       

            
            if response.status_code == 201:

                response_data = response.json()
                
                edad = 'Edad:  ' + response_data.get('Edad')
                menarquia = 'Menarquia: ' + response_data.get('Gin_Menarquia')
                regular = 'Ciclos: R ' + response_data.get('Gin_Ciclos_R')
                iregular = f'Ciclos: R   ' + response_data.get('Gin_Ciclos_R')
                fum = 'FUM:   ' + response_data.get('Gin_Fum')
                gestas = 'GESTAS:   ' + response_data.get('Gin_Gestas')
                partos = 'PARTOS:   ' + response_data.get('Gin_Partos')
                cesarea = 'CESAREA:   ' + response_data.get('Gin_Cesarea')
                aborto = 'ABORTO:   ' + response_data.get('Gin_Aborto')
                pap = 'PAP:   ' + response_data.get('Gin_Pap')
                colpos = 'COLPOS:   ' + response_data.get('Gin_Colpos')
                eco_mama = 'Eco Mama:   ' + response_data.get('Gin_Eco_Mama')
                mamografia = 'Mamografia:   ' + response_data.get('Gin_Mamografia')
                prost = 'AG Prost:   ' + response_data.get('Ap_Ag_Prost')
                eco_prost = 'Eco Prost:   ' + response_data.get('Ap_Eco_Prost')
                ap_obs = 'Obsv.:   ' + response_data.get('Ap_Obsv')
                accid_calf = 'Calificado:  ' + response_data.get('Accidente_Trabajo')
                enf_calf = 'Calificado:  ' + response_data.get('Enfermedad_Prof')
                cardi = 'Car-vasc  ' + response_data.get('Car_Vasc')
                meta = 'Metabolica  ' + response_data.get('Metabolica')
                neur = 'Neurolog.  ' + response_data.get('Neurologica')
                onco = 'Onco.  ' + response_data.get('Onco')
                infec = 'Infec.  ' + response_data.get('Infec')
                here = 'Hereditaria  ' + response_data.get('Hereditaria')
                piel= 'Piel y anexo  ' + response_data.get('Org_Piel')
                endo= 'Endocrino  ' + response_data.get('Org_Endocrino')
                resp= 'Respiratorio  ' + response_data.get('Org_Respiratorio')
                nerv= 'Nervioso  ' + response_data.get('Org_Nervioso')
                dig= 'Digestivo  ' + response_data.get('Org_Digestivo')
                cardio= 'Cardio-Vascular ' + response_data.get('Org_Card_Vacular')
                musc= 'Mus-esq  ' + response_data.get('Org_Mus_Esq')
                hemo= 'Hemolinf  ' + response_data.get('Org_Hemolinf')
                org_sent= 'Org. Sent  ' + response_data.get('Org_Sent')
                gen_uri= 'Gen-uri  ' + response_data.get('Org_Gen_Uri')
                
                les= 'Lesbiana  ' + response_data.get('Ori_Lesbiana')
                gay= 'Gay  ' + response_data.get('Ori_Gay')
                bi= 'Bisexual  ' + response_data.get('Ori_Bisexual')
                hete= 'Hetero  ' + response_data.get('Ori_Hetero')
                ori_om= 'Omitir Informacion  ' + response_data.get('Ori_Omitir')
                
                fem= 'Femenino  ' + response_data.get('Iden_Fem')
                masc= 'Masculino  ' + response_data.get('Iden_Masc')
                trans= 'Transgenero  ' + response_data.get('Iden_Transg')
                ide_om= 'Omitir Informacion  ' + response_data.get('Iden_Omitir')
                
                apto= 'APTO  ' + response_data.get('Apto')
                apto_ob= 'APTO en Observacion  ' + response_data.get('Apto_Obsv')
                apto_lim= 'APTO con limitaciones  ' + response_data.get('Apto_Limit')
                no_apto= 'NO APTO  ' + response_data.get('No_Apto')
                
                presion= 'Presion Arterial  ' + response_data.get('Sig_Pres_Art')
                temp= 'Temp  ' + response_data.get('Sig_Temp')
                fc= 'FC  ' + response_data.get('Sig_Fc')
                sat= 'sat. Ox.  ' + response_data.get('Sig_Sat_Ox')
                fr= 'FR  ' + response_data.get('Sig_Fr')
                peso= 'Peso  ' + response_data.get('Sig_Peso')
                talla= 'Talla  ' + response_data.get('Sig_Talla')
                imc= 'IMC  ' + response_data.get('Riego_8')
                biotipo= 'Biotipo  ' + response_data.get('Sig_Biotico')
                atleti = 'Atleti.  ' + response_data.get('Sig_Atleti')
                atletico= 'Picn.  ' + response_data.get('Sig_Atletico')
                picn= 'Aletico  ' + response_data.get('Sig_Picn')
                
                
                
                
                coordinates = {
                    'H3': response_data.get('Cedula', 'N/A'),
                    'C8': response_data.get('Nombre', 'N/A'),
                    'H6': response_data.get('Grupo_sanguineo','N/A'),
                    'H10': response_data.get('Religion','N/A'),
                    'B10': edad,
                    'D10': response_data.get('Discapacidad','N/A'),
                    'C12': response_data.get('Puesto_Trabajo','N/A'),
                    'G12': response_data.get('Activ_Relevante','N/A'),
                    'F10': response_data.get('Porc_Discapacidad','N/A'),
                    'B25': response_data.get('Antced_Clin_Quir','N/A'),
                    'B29': menarquia,
                    'D29': fum,
                    'E29': gestas,
                    'F29': partos,
                    'G29': cesarea,
                    'H29': aborto,
                    'E30': pap,
                    'F30': colpos,
                    'G30': eco_mama,
                    'H30': mamografia,
                    'B33': prost,
                    'C33': eco_prost,
                    'D33': ap_obs,
                    
                    'C14': les,
                    'D14': gay,
                    'E14': bi,
                    'F14': hete,
                    'G14': ori_om,
                    
                    'C16': fem,
                    'D16': masc,
                    'E16': trans,
                    'G16': ide_om,

                    'B130': apto,
                    'C130': apto_ob,
                    'E130': apto_lim,
                    'H130': no_apto,

                    
                    'C35': response_data.get('Act_Fisica','N/A'),
                    'D35': response_data.get('Act_Fisica_Obsv','N/A'),
                    'C36': response_data.get('Medi_Actual','N/A'),
                    'D36': response_data.get('Medi_Actual_Obsv','N/A'),
                    'C37': response_data.get('Alcohol','N/A'),
                    'D37': response_data.get('Alcohol_Obsv','N/A'),
                    'C38': response_data.get('Tabaco','N/A'),
                    'D38': response_data.get('Tabaco_Obsv','N/A'),
                    'C39': response_data.get('Otros','N/A'),
                    'D39': response_data.get('Otros_Obsv','N/A'),
                    
                    'B45': response_data.get('Empresa_1','N/A'),
                    'C45': response_data.get('Puesto_1','N/A'),
                    'D45': response_data.get('Actividad_1','N/A'),
                    'E45': response_data.get('Tiempo_1','N/A'),
                    'F45': response_data.get('Riego_1','N/A'),
                    'H45': response_data.get('Antc_Observ_1','N/A'),
                    'B46': response_data.get('Empresa_2','N/A'),
                    'C46': response_data.get('Puesto_2','N/A'),
                    'D46': response_data.get('Actividad_2','N/A'),
                    'E46': response_data.get('Tiempo_2','N/A'),
                    'F46': response_data.get('Riego_2','N/A'),
                    'H46': response_data.get('Antc_Observ_2','N/A'),
                    'B47': response_data.get('Empresa_3','N/A'),
                    'C47': response_data.get('Puesto_3','N/A'),
                    'D47': response_data.get('Actividad_3','N/A'),
                    'E47': response_data.get('Tiempo_3','N/A'),
                    'F47': response_data.get('Riego_3','N/A'),
                    'H47': response_data.get('Antc_Observ_3','N/A'),
                    'B48': response_data.get('Empresa_4','N/A'),
                    'C48': response_data.get('Puesto_4','N/A'),
                    'D48': response_data.get('Actividad_4','N/A'),
                    'E48': response_data.get('Tiempo_4','N/A'),
                    'F49': response_data.get('Riego_4','N/A'),
                    'H49': response_data.get('Antc_Observ_4','N/A'),
                    
                    'C52': response_data.get('Accidente_Trabajo_Calf_1','N/A'),
                    'F52': accid_calf,
                    'H52': response_data.get('Accidente_Trabajo_Fecha','N/A'),
                    'C54': response_data.get('Enfermedad_Prof_Calf_1','N/A'),
                    'F54': enf_calf,
                    'H54': response_data.get('Enfermedad_Prof_Fecha','N/A'),
                            
                    'B58': cardi,
                    'C58': meta,
                    'D58': neur,
                    'E58': onco,
                    'F58': infec,
                    'G58': here,
                    
                    'C65': response_data.get('Fact_Ruido','N/A'),  
                    'C66': response_data.get('Fact_Iluminacion','N/A'),  
                    'C67': response_data.get('Fact_Ventilacion','N/A'),  
                    'C68': response_data.get('Fact_Caidas','N/A'),  
                    'C69': response_data.get('Fact_Atrope','N/A'),  
                    'C70': response_data.get('Fact_Caida_Desniv','N/A'),  
                    'C106': response_data.get('Examn_Fis_Inspeccion','N/A'),  
                    'C107': response_data.get('Examn_Fis_Palpacion','N/A'),  
                    'C108': response_data.get('Examn_Fis_Percsusion','N/A'),  

                    'E65': response_data.get('Fact_Polvo','N/A'),  
                    'E66': response_data.get('Fact_Liquidos','N/A'),  
                    'E67': response_data.get('Fact_Virus','N/A'),  
                    'E68': response_data.get('Fact_Post_Forz','N/A'),  
                    'E69': response_data.get('Fact_Mov_Rep','N/A'),  
                    'E70': response_data.get('Fact_Monotomia','N/A'),  
 
                    'H65': response_data.get('Fact_Alta_Respo','N/A'),  
                    'H66': response_data.get('Fact_Conflict','N/A'),  
                    'H67': response_data.get('Fact_Sobrecarga','N/A'),  
                    'H68': response_data.get('Fact_Inestabilidad','N/A'),  
                    'H69': response_data.get('Fact_Relac_Interp','N/A'),   
                    
                    'B76': response_data.get('Act_Extralaborales','N/A'),                   
                      
                    'B82': piel, 
                    'B83': endo, 
                    'C82': resp, 
                    'C83': nerv, 
                    'D82': dig, 
                    'D83': cardio, 
                    'E82': musc, 
                    'F82': hemo, 
                    'G82': org_sent, 
                    'H82': gen_uri, 
                    
                    'B90': presion, 
                    'D90': temp, 
                    'E90': fc, 
                    'F90': sat, 
                    'H90': fr, 
                    'B91': peso, 
                    'C91': talla, 
                    'D91': imc, 
                    'E91': biotipo, 
                    'F91': atleti, 
                    'G91': picn, 
                    'H91': atletico, 
                                        
                    'B86': response_data.get('Org_Descripcion','N/A'), 
                    
                    'C95': response_data.get('Examn_Fis_Cabeza','N/A'), 
                    'C96': response_data.get('Examn_Fis_Garganta','N/A'), 
                    'C97': response_data.get('Examn_Fis_Ojos','N/A'), 
                    'C98': response_data.get('Examn_Fis_Oidos','N/A'), 
                    'C99': response_data.get('Examn_Fis_Nariz','N/A'), 
                    'C100': response_data.get('Examn_Fis_Boca','N/A'), 
                    'C101': response_data.get('Examn_Fis_Dentudura','N/A'), 
                    'C103': response_data.get('Examn_Fis_Corazon','N/A'), 
                    'C104': response_data.get('Examn_Fis_Pulmones','N/A'), 
                    'C106': response_data.get('Examn_Fis_Inspeccion','N/A'), 
                    'C107': response_data.get('Examn_Fis_Palpacion','N/A'), 
                    'C108': response_data.get('Examn_Fis_Percsusion','N/A'), 
                    
                    'E94': response_data.get('Examn_Fis_Extremidades','N/A'), 
                    'E96': response_data.get('Examn_Fis_Umbilical','N/A'), 
                    'E97': response_data.get('Examn_Fis_Ingual_Dere','N/A'),
                    'E98': response_data.get('Examn_Fis_Clural_Dere','N/A'),
                    'E99': response_data.get('Examn_Fis_Inguinal_Izquierdo','N/A'),
                    'E100': response_data.get('Examn_Fis_Clural_Izq','N/A'),
                    'E102': response_data.get('Examn_Fis_Deformaciones','N/A'),
                    'E103': response_data.get('Examn_Fis_Movilidad','N/A'),
                    'E104': response_data.get('Examn_Fis_Masas_Musculares','N/A'),
                    'E106': response_data.get('Examn_Fis_Tracto_Urinario','N/A'),  
                    'E107': response_data.get('Examn_Fis_Tracto_Genital','N/A'),  
                    'E108': response_data.get('Examn_Fis_Regio_Anoperineal','N/A'), 
                     
                    'H96': response_data.get('Examn_Fis_Sup_Izquierda','N/A'), 
                    'H97': response_data.get('Examn_Fis_Infer_Dere','N/A'), 
                    'H98': response_data.get('Examn_Fis_Infer_Izquierda','N/A'), 
                    'H100': response_data.get('Examn_Fis_Reflejos_Tndinosos','N/A'), 
                    'H101': response_data.get('Examn_Fis_Sencibilidad_Sup','N/A'), 
                    'H102': response_data.get('Examn_Fis_Reflejos_Pupilares','N/A'), 
                    'H104': response_data.get('Examn_Fis_Ojo_Derecho','N/A'), 
                    'H105': response_data.get('Examn_Fis_Ojo_Izquierdo','N/A'), 
                    'H107': response_data.get('Examn_Fis_Oido_Derecho','N/A'), 
                    'H108': response_data.get('Examn_Fis_Oido_Izquierdo','N/A'), 
                    
                    'B111': response_data.get('Examn_Fis_Descripcion','N/A'), 
                    
                    'C114': response_data.get('Laboratorio','N/A'), 
                    'C115': response_data.get('Rx','N/A'), 
                    'C116': response_data.get('Audiometria','N/A'), 
                    'C117': response_data.get('Optometria','N/A'), 
                    'C118': response_data.get('Ekg','N/A'), 
                    
                    
                    'B122': response_data.get('Diagnostico_1','N/A'), 
                    'B123': response_data.get('Diagnostico_2','N/A'), 
                    'B124': response_data.get('Diagnostico_3','N/A'), 
                    'B125': response_data.get('Diagnostico_4','N/A'), 
                    'F122': response_data.get('Cie10_1','N/A'), 
                    'F123': response_data.get('Cie10_2','N/A'), 
                    'F124': response_data.get('Cie10_3','N/A'), 
                    'F125': response_data.get('Cie10_4','N/A'), 
                    
                    'C132': response_data.get('Apt_Med_Obsv','N/A'), 
                    'C133': response_data.get('Apt_Med_Limit','N/A'), 
                    
                    'B140': response_data.get('Recom_Tto','N/A'), 
                    'B145': response_data.get('Inf_Med_Gen','N/A'),                   
  
                }



                socializacion_personal = response_data.get('Socializacion_personal', 'N/A')

                if socializacion_personal == 'Si':
                    coordinates['H49'] = 'X'
                elif socializacion_personal == 'No':
                    coordinates['J49'] = 'X'
                else:
                    print("No hay valor")       

                factores = response_data.get('Fact_psico_sociales', 'N/A')

                if factores == 'No':
                    coordinates['I29'] = 'X'
                elif factores == 'Si':
                    coordinates['I31'] = 'X'
                else:
                    print("No hay valor") 

                # Cargar el archivo Excel existente
                file_path = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_PREOCUPACIONAL.xlsx')

                wb = openpyxl.load_workbook(file_path)
                ws = wb['pagina 1']  

                # Escribir datos en las celdas según el diccionario de coordenadas
                for cell, value in coordinates.items():
                    ws[cell] = value

                # Procesar y redimensionar firma del colaborador
                firma_colaborador = response_data.get('Firma_Colaborador', '')
                firma_doc = base_firma_doc
                if firma_colaborador:
                    if firma_colaborador.startswith('data:image/png;base64,'):
                        firma_colaborador = firma_colaborador.split(',')[1]
                    if len(firma_colaborador) % 4:
                        firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_colaborador, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'PRE_TEMP.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/PRE_TEMP.png')
                        ws.add_image(img_colaborador, 'D148')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del colaborador: {e}')

                if firma_doc:
                    if firma_doc.startswith('data:image/png;base64,'):
                        firma_doc = firma_doc.split(',')[1]
                    if len(firma_doc) % 4:
                        firma_doc += '=' * (4 - len(firma_doc) % 4)

                    try:
                        print('Procesando firma del colaborador...')
                        data_sign = resize_image_base64(firma_doc, 250, 150)  # Redimensionar a 200x100
                        REDUCED_SIGN = base64.b64decode(data_sign)

                        tempxlsx1 = os.path.join(os.path.dirname(__file__), '..', 'files', 'PRE_TEMP2.png')

                        # Guardar la firma redimensionada temporalmente
                        with open(tempxlsx1, 'wb') as f:
                            f.write(REDUCED_SIGN)

                        # Insertar la firma en el archivo Excel
                        img_colaborador = ExcelImage('files/PRE_TEMP2.png')
                        ws.add_image(img_colaborador, 'G148')  # Ajusta la posición según sea necesario
                        print('Firma del colaborador añadida.')

                    except (base64.binascii.Error, ValueError) as e:
                        print(f'Error al procesar la firma del doctor: {e}')


                # Guardar el archivo Excel modificado en un buffer temporal
                output = BytesIO()
                wb.save(output)
                output.seek(0)
                    
                # Enviar el archivo Excel como respuesta para descarga
                return send_file(output, as_attachment=True, download_name=f'FICHA_PREOCUPACIONAL_{cedula}.xlsx', mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            
            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                print("Error en la respuesta de la API: " + response.text)
                return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: EXCEL,  {e}')
            return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_preocupacional.html')

@depmedico.route('/preocupacional_pdf', methods=['GET', 'POST'])
def preocupacional_pdf():
    if request.method == 'POST':
        form_data = request.form.to_dict()
        cedula = form_data.get('cedula')
        session['cedula'] = cedula

        payload = {
            "cedula": cedula
        }
        print('CEDULA: ', cedula)
        try:
            # Realiza una solicitud POST a la API con la cédula
            response = requests.post(
                'https://localhost:7220/FormDepMedico/Cargar/fichaPreocupacional',
                json=payload,
                headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                verify=False
            )

            if response.status_code == 201:
                response_data = response.json()
                print('Respuesta de la API:\n', response_data)

                print(response_data.get('Fecha_actualizacion'))
                pdf_path_input = os.path.join(os.path.dirname(__file__), '..', 'files', 'FICHA_PREOCUPACIONAL.pdf')
                doc = fitz.open(pdf_path_input)  # Abre el documento PDF existente

                # Procesa cada página del PDF
                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    widgets = page.widgets()  # Obtener los campos de formulario

                    if widgets:
                        print(f"Páginas con campos de formulario: {page_num + 1}")
                        for widget in widgets:
                            field_name = widget.field_name
                            field_value = widget.field_value  # Usar field_value para obtener el valor del campo
                            
                            print(f"Campo: {field_name}, Valor actual: {field_value}")

                            
                           # Actualiza el campo si está presente en response_data
                            if field_name in response_data:
                                if widget.field_type == fitz.PDF_WIDGET_TYPE_CHECKBOX:
                                    # Marca el checkbox si el valor es True en response_data
                                    widget.field_value = True if response_data[field_name] else False

                                    widget.update()
                                    print(f"Checkbox '{field_name}' actualizado con valor: {widget.field_value}")
                        
                                else:
                                    # Para otros campos (como texto), actualiza el valor
                                    widget.field_value = response_data[field_name]
                                    widget.update()
                                    print(f"Campo '{field_name}' actualizado con valor: {response_data[field_name]}")


                    # Establece las posiciones para cada campo a actualizar
                    positions_page1 = {
                        "Cedula": (448, 27),
                        "Nombre" : (125, 66),
                        "Edad": (90, 87),
                        "Discapacidad": (195, 87),
                        "Porc_Discapacidad": (330, 87),
                        "Religion": (450, 87),
                        
                        "Grupo_sanguineo" : (460, 51),                   
                        "Puesto_Trabajo" : (125, 105),                   
                        "Activ_Relevante" : (400, 105), 
                        
                        "Ori_Lesbiana" : (163, 121),
                        "Ori_Gay" : (230, 121),
                        "Ori_Bisexual" : (298, 121),
                        "Ori_Hetero" : (356, 121),
                        "Ori_Omitir" : (463, 121),
                        
                        "Iden_Fem" : (164, 137),
                        "Iden_Masc" : (230, 137),
                        "Iden_Transg" : (310, 137),
                        "Iden_Omitir" : (464, 136),
                        
                        "Antced_Clin_Quir" : (60, 218),
                       
                        "Gin_Menarquia" : (99, 257),                                        
                        "Gin_Ciclos_R" : (156, 257),                                        
                        "Gin_Ciclos_I" : (178, 257),                                        
                        "Gin_Fum" : (225, 257),                                        
                        "Gin_Gestas" : (298, 257),                                        
                        "Gin_Partos" : (360, 257),      
                        "Gin_Cesarea" : (424, 257),      
                        "Gin_Aborto" : (475, 257),      
                        
                        "Gin_Hijos_V" : (84, 271),      
                        "Gin_Hjos_M" : (110, 271),      
                        "Gin_Vsa" : (160, 271),      
                        "Gin_Mpf" : (225, 271),      
                        "Gin_Pap" : (298, 271),      
                        "Gin_Colpos" : (360, 271),      
                        "Gin_Eco_Mama" : (424, 271),      
                        "Gin_Mamografia" : (490, 271),      
                                                          
                        
                                    
                        "Ap_Ag_Prost" : (90, 302),            
                        "Ap_Eco_Prost" : (162, 302),            
                        "Ap_Obsv" : (227, 302),            
                        
                        "Act_Fisica_Obsv" : (190, 323),            
                        "Medi_Actual_Obsv" : (190, 336),            
                        "Alcohol_Obsv" : (190, 348),            
                        "Tabaco_Obsv" : (190, 359),            
                        "Otros_Obsv" : (190, 370),            
                        
                        "Empresa_1" : (60, 429),            
                        "Empresa_2" : (60, 441),            
                        "Empresa_3" : (60, 455),            
                        "Empresa_4" : (60, 468),   
                                 
                        "Puesto_1" : (125, 429),            
                        "Puesto_2" : (125, 441),            
                        "Puesto_3" : (125, 455),            
                        "Puesto_4" : (125, 468),            
                        
                        "Actividad_1" : (195, 429),            
                        "Actividad_2" : (195, 441),            
                        "Actividad_3" : (195, 455),            
                        "Actividad_4" : (195, 468),            
                        
                        "Tiempo_1" : (266, 429),            
                        "Tiempo_2" : (266, 441),            
                        "Tiempo_3" : (266, 455),            
                        "Tiempo_4" : (266, 468),            
                        
                        "Riego_1" : (332, 429),            
                        "Riego_2" : (332, 441),            
                        "Riego_3" : (332, 455),            
                        "Riego_4" : (332, 468),            
                        
                        "Antc_Observ_1" : (445, 429),            
                        "Antc_Observ_2" : (445, 441),            
                        "Antc_Observ_3" : (445, 455),            
                        "Antc_Observ_4" : (445, 468),            
                        
                        "Accidente_Trabajo_Calf_1" : (127, 500),            
                        "Accidente_Trabajo_Fecha" : (446, 500),            
                        "Enfermedad_Prof_Calf_1" : (127, 519),            
                        "Enfermedad_Prof_Fecha" : (446, 519),            
                        
                        "Car_Vasc" : (97, 554),            
                        "Metabolica" : (168, 554),            
                        "Neurologica" : (231, 554),            
                        "Onco" : (315, 554),            
                        "Infec" : (371, 554),            
                        "Hereditaria" : (476, 554),            
                        
                        "Antc_Descrip" : (62, 587),            
                        
                        "Fact_Ruido" : (155, 627),
                        "Fact_Iluminacion" : (155, 642),
                        "Fact_Ventilacion" : (155, 657),
                        "Fact_Caidas" : (155, 672),
                        "Fact_Atrope" : (155, 686),
                        "Fact_Caida_Desniv" : (155, 702),

                        "Fact_Polvo" : (291, 627),
                        "Fact_Liquidos" : (291, 642),
                        "Fact_Virus" : (291, 657),
                        "Fact_Post_Forz" : (291, 672),
                        "Fact_Mov_Rep" : (291, 686),
                        "Fact_Monotomia" : (291, 702),

                        "Fact_Alta_Respo" : (472, 627),
                        "Fact_Conflict" : (472, 642),
                        "Fact_Sobrecarga" : (472, 657),
                        "Fact_Inestabilidad" : (472, 672),
                        "Fact_Relac_Interp" : (472, 686),


                    }

                                          
                    positions_page2 = {  
                        
                        "Org_Piel": (106, 96),
                        "Org_Respiratorio": (172, 96),
                        "Org_Digestivo": (233, 96),
                        "Org_Mus_Esq": (302, 96),
                        "Org_Hemolinf": (370, 96),
                        "Org_Sent": (428, 96),
                        "Org_Gen_Uri": (481, 96),
                        
                        "Org_Endocrino": (106, 113),
                        "Org_Nervioso": (172, 113),
                        "Org_Card_Vacular": (249, 113),
                        
                        "Org_Descripcion": (61, 148),
                        
                        "Sig_Pres_Art": (135, 187),
                        "Sig_Temp": (230, 187),
                        "Sig_Fc": (300, 187),
                        "Sig_Sat_Ox": (365, 187),
                        "Sig_Fr": (475, 187),
                        "Sig_Peso": (88, 201),
                        "Sig_Talla": (157, 201),
                        "Riego_8": (230, 201),
                        "Sig_Biotico": (300, 201),
                        "Sig_Atleti": (365, 201),
                        "Sig_Picn": (420, 201),
                        "Sig_Atletico": (476, 201),
                        
                        "Examn_Fis_Garganta": (138, 261),
                        "Examn_Fis_Ojos": (138, 274),
                        "Examn_Fis_Oidos": (138, 287),
                        "Examn_Fis_Nariz": (138, 302),
                        "Examn_Fis_Boca": (138, 315),
                        "Examn_Fis_Dentudura": (138, 329),
                        "Examn_Fis_Corazon": (138, 356),
                        "Examn_Fis_Pulmones": (138, 369),
                        "Examn_Fis_Inspeccion": (138, 396),
                        "Examn_Fis_Palpacion": (138, 410),
                        "Examn_Fis_Percsusion": (138, 423),
                        
                        "Examn_Fis_Umbilical": (291, 260),
                        "Examn_Fis_Ingual_Dere": (291, 274),
                        "Examn_Fis_Clural_Dere": (291, 287),
                        "Examn_Fis_Inguinal_Izquierdo": (291, 301),
                        "Examn_Fis_Clural_Izq": (291, 315),
                        "Examn_Fis_Deformaciones": (291, 343),
                        "Examn_Fis_Movilidad": (291, 358),
                        "Examn_Fis_Masas_Musculares": (291, 373),
                        "Examn_Fis_Tracto_Urinario": (291, 396),
                        "Examn_Fis_Tracto_Genital": (291, 410),
                        "Examn_Fis_Regio_Anoperineal": (291, 424),
                        
                        "Examn_Fis_Sup_Izquierda": (475, 262),
                        "Examn_Fis_Infer_Dere": (475, 276),
                        "Examn_Fis_Infer_Izquierda": (475, 289),
                        
                        "Examn_Fis_Reflejos_Tndinosos": (475, 315),
                        "Examn_Fis_Sencibilidad_Sup": (475, 330),
                        "Examn_Fis_Reflejos_Pupilares": (475, 344),
                        "Examn_Fis_Ojo_Derecho": (475, 369),
                        "Examn_Fis_Ojo_Izquierdo": (475, 384),
                        "Examn_Fis_Oido_Derecho": (475, 410),
                        "Examn_Fis_Oido_Izquierdo": (475, 424),
                        
                        "Examn_Fis_Descripcion": (62, 464),
                        
                        "Laboratorio": (127, 496),
                        "Rx": (127, 510),
                        "Audiometria": (127, 523),
                        "Optometria": (127, 536),
                        "Ekg": (127, 550),
                        
                        "Diagnostico_1": (64, 597),
                        "Diagnostico_2": (64, 608),
                        "Diagnostico_3": (64, 620),
                        "Diagnostico_4": (64, 634),
                        "Cie10_1": (350, 597),
                        "Cie10_2": (350, 608),
                        "Cie10_3": (350, 620),
                        "Cie10_4": (350, 634),
                        
                        "Apto": (92, 685),
                        "Apto_Obsv": (226, 685),
                        "Apto_Limit": (375, 685),
                        "No_Apto": (487, 685),
                        
                        "Apt_Med_Obsv": (127, 707),
                        "Apt_Med_Limit": (127, 720),
                    }
                    
                    positions_page3 = {  
                        
                    }

                        
                    
                    # Imprimir la "X" en la posición correspondiente a 'Droga'
                    if page_num == 0:  # Primera página
                        for field_name, position in positions_page1.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                if field_value:  # Asegúrate de que el valor no sea nulo o vacío
                                    print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                    page.insert_text(position, str(field_value), fontsize=8, color=(0, 0, 0))
                                else:
                                    print(f"El campo '{field_name}' está vacío en response_data")

                        # Imprimir la imagen de la firma en el PDF
                        firma_colaborador = response_data.get('Firma_Colaborador', '')
                        firma_doctor = base_firma_doc
                    
                    elif page_num == 1:
                        for field_name, position in positions_page2.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6, color=(0,0,0))


                        act_ext = response_data.get('Act_Extralaborales', '')

                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        droga_rect = fitz.Rect(60, 36, 506, 65)


                        page.insert_textbox(droga_rect, act_ext, fontsize=6, color=(0, 0, 0), align=fitz.TEXT_ALIGN_LEFT, lineheight=1.6 )
                        
                        
                        
                    elif page_num == 2:
                        for field_name, position in positions_page3.items():
                            if field_name in response_data:
                                field_value = response_data[field_name]
                                print(f"Campo '{field_name}' actualizado con valor: {field_value}")
                                page.insert_text(position, str(field_value), fontsize=6, color=(0,0,0))
                        
                        
                        recom = response_data.get('Recom_Tto', '')

                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        droga_rect = fitz.Rect(60, 31, 506, 65)

                        page.insert_textbox(droga_rect, recom, fontsize=6, color=(0, 0, 0), align=fitz.TEXT_ALIGN_LEFT, lineheight=1.6 )
                       
                        inf_gen = response_data.get('Inf_Med_Gen', '')

                        # Ajusta el área (rectángulo) para los detalles de apto y recomendaciones
                        inf_rec = fitz.Rect(60, 75, 506, 110)
                        
                        page.insert_textbox(inf_rec, inf_gen, fontsize=6, color=(0, 0, 0), align=fitz.TEXT_ALIGN_LEFT, lineheight=1.6 )
                        
                        
                        # Proceso de la firma del colaborador
                        if firma_colaborador:
                            if firma_colaborador.startswith('data:image/png;base64,'):
                                firma_colaborador = firma_colaborador.split(',')[1]

                            if len(firma_colaborador) % 4:
                                firma_colaborador += '=' * (4 - len(firma_colaborador) % 4)

                            try:
                                print('Procesando firma colaborador...', firma_colaborador)
                                data_sign = resize_image_base64(firma_colaborador, 600, 600)
                                REDUCED_SIGN = base64.b64decode(data_sign)

                                signature_position = fitz.Rect(180+200, 670-555, 280+200, 705-550)
                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma colaborador añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')
                                
                                            # Proceso de la firma del doctor
                        if firma_doctor:
                            if firma_doctor.startswith('data:image/png;base64,'):
                                firma_doctor = firma_doctor.split(',')[1]

                            if len(firma_doctor) % 4:
                                firma_doctor += '=' * (4 - len(firma_doctor) % 4)

                            try:
                                print('Procesando firma doctor...', firma_doctor)
                                data_sign = resize_image_base64(firma_doctor, 450, 450)
                                REDUCED_SIGN = base64.b64decode(data_sign)
                                signature_position = fitz.Rect(370-250, 670-569, 475-250, 705-500)

                                page.insert_image(signature_position, stream=REDUCED_SIGN)
                                print('Firma doctor añadida.')
                            except (base64.binascii.Error, ValueError) as e:
                                flash(f'Error al decodificar la firma: {e}', 'error')
                                print(f'Error al decodificar la firma: {e}')                           


                # Aplanar todas las páginas
                new_doc = fitz.open()  # Crear un nuevo documento PDF

                for page_num in range(len(doc)):
                    page = doc.load_page(page_num)
                    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3))  # Usa una matriz para mayor calidad
                    
                    # Crea una nueva página en el nuevo documento con el mismo tamaño
                    new_page = new_doc.new_page(width=pix.width, height=pix.height)
                    
                    # Inserta la imagen de la página original en la nueva página
                    new_page.insert_image(fitz.Rect(0, 0, pix.width, pix.height), stream=pix.tobytes())

                doc.close()  # Cierra el documento original

                # Guarda el nuevo documento PDF aplanado en un archivo temporal
                with NamedTemporaryFile(delete=False, suffix='.pdf') as temp_file:
                    pdf_path_output = temp_file.name
                    new_doc.save(pdf_path_output)
                    new_doc.close()

                # Envía el archivo PDF temporal como una descarga
                print('PDF Completado')
                return send_file(pdf_path_output, as_attachment=True, download_name='FICHA_PREOCUPACIONAL_' + cedula + '.pdf', mimetype='application/pdf')


            else:
                print(response.status_code)
                flash("Error en la respuesta de la API: " + response.text, 'error')
                return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

        except requests.exceptions.RequestException as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: Request, {e}')
            return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

        except Exception as e:
            flash(f'Ocurrió un error al procesar el formulario: {e}', 'error')
            print(f'Error: PDF,  {e}')
            return render_template('depmedico/dash_preocupacional.html', errores={}, form_data=form_data)

    return render_template('depmedico/dash_preocupacional.html')


#=======================================LISTAR FICHAS
#Endpoint para listar las fichas ocupacionales 
@depmedico.route('/cargar_fichas', methods=['GET', 'POST'])
def cargar_fichas():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaOcupacional'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}

    try:
        # Realiza la petición POST incluyendo los datos del formulario
        response = requests.get(url, headers=headers, verify=False)
        
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())
            #response_data_converted = response.copy()  # Copiar para modificar las fechas
            #response_data_converted['FechaRegistro'] = datetime.strptime(response['FechaRegistro'], '%Y-%m-%d').strftime('%d/%m/%Y')
            # Devuelve el JSON de la respuesta al navegador
            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

#Endpoint para listar las fichas ocupacionales 
@depmedico.route('/cargar_fichas_preocupacionales', methods=['GET', 'POST'])
def cargar_fichas_preocupacionales():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaPreocupacional'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}

    data = {
        "fechaDesde": "2023-01-01",
        "fechaHasta": "2080-12-31"
    }

    try:
        # Realiza la petición POST enviando el cuerpo con las fechas
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())
            #response_data_converted = response.copy()  # Copiar para modificar las fechas
            #response_data_converted['FechaRegistro'] = datetime.strptime(response['FechaRegistro'], '%Y-%m-%d').strftime('%d/%m/%Y')
            # Devuelve el JSON de la respuesta al navegador
            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

#Endpoint para listar las fichas ocupacionales 
@depmedico.route('/cargar_fichas_consumo', methods=['GET', 'POST'])
def cargar_fichas_consumo():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaDrogas'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}
    data = {
        "fechaDesde": "2023-01-01",
        "fechaHasta": "2080-12-31"
    }

    try:
        # Realiza la petición POST enviando el cuerpo con las fechas
        response = requests.post(url, headers=headers, json=data, verify=False)
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())

            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

#Endpoint para listar las fichas ocupacionales 
@depmedico.route('/cargar_fichas_seguimiento', methods=['GET', 'POST'])
def cargar_fichas_seguimiento():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaSegDrogas'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}
    data = {
        "fechaDesde": "2023-01-01",
        "fechaHasta": "2080-12-31"
    }

    try:
        # Realiza la petición POST enviando el cuerpo con las fechas
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())
            #response_data_converted = response.copy()  # Copiar para modificar las fechas
            #response_data_converted['FechaRegistro'] = datetime.strptime(response['FechaRegistro'], '%Y-%m-%d').strftime('%d/%m/%Y')
            # Devuelve el JSON de la respuesta al navegador
            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

#Endpoint para listar las fichas ocupacionales 
@depmedico.route('/cargar_fichas_consentimiento', methods=['GET', 'POST'])
def cargar_fichas_consentimiento():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaConsInformado'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}

    data = {
        "fechaDesde": "2023-01-01",
        "fechaHasta": "2080-12-31"
    }

    try:
        # Realiza la petición POST enviando el cuerpo con las fechas
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())
            #response_data_converted = response.copy()  # Copiar para modificar las fechas
            #response_data_converted['FechaRegistro'] = datetime.strptime(response['FechaRegistro'], '%Y-%m-%d').strftime('%d/%m/%Y')
            # Devuelve el JSON de la respuesta al navegador
            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

@depmedico.route('/cargar_fichas_certificado', methods=['GET', 'POST'])
def cargar_fichas_certificado():

    url = 'https://localhost:7220/FormDepMedico/Listar/fichaCertOcup'
    headers = {"AuthKey": "jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s"}

    data = {
        "fechaDesde": "2023-01-01",
        "fechaHasta": "2080-12-31"
    }

    try:
        # Realiza la petición POST enviando el cuerpo con las fechas
        response = requests.post(url, headers=headers, json=data, verify=False)
        
        # Verifica si la respuesta es exitosa
        if response.status_code == 201:
            print(response.json())
            #response_data_converted = response.copy()  # Copiar para modificar las fechas
            #response_data_converted['FechaRegistro'] = datetime.strptime(response['FechaRegistro'], '%Y-%m-%d').strftime('%d/%m/%Y')
            # Devuelve el JSON de la respuesta al navegador
            return jsonify(response.json())
        else:
            # Maneja el caso en que la respuesta no es exitosa
            return jsonify({"error": f'Error al enviar datos a la API. Código de respuesta: {response.status_code}'}), response.status_code

    except requests.exceptions.RequestException as e:
        # Manejo de excepciones al realizar la petición
        return jsonify({"error": f'Ocurrió un error al realizar la petición al API: {e}'}), 500

#===================================

@depmedico.errorhandler(404)
def page_not_found(e = None, value: str = None):
    # note that we set the 404 status explicitly
    value = value or 'Error 404'
    web: dict = {
        'title': 'Error - Departamento Médico',
        'error': value
    }
    return render_template('error.html', web = web), 404


base_firma_doc = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKwAAAClCAYAAADBPhYQAAAAAXNSR0IArs4c6QAAIABJREFUeF7svQd4VkX2Pz7t9rem0EFFFLuLIFUgEAiE3kI1dFEU1LXrWnDdXV1dG7qgSA+EEnoSAqFFLNjXirJioUOSt7+3tz8TF/+soIQQkP3+uM+TB5I7c+bMmc+cOffMmTMQXHguSOB/SALwf4jXC6xekAC4ANgLIPifksAFwP5PDdcFZi8A9gIG/qckcAGw/1PDdYHZC4C9gIH/KQlcAOz/1HBdYPa8AezgAUMHa6a5q7h49ZcXhuWCBH5NAr87YHv3HhlETqK56PGOwwxelZ+ft/HCcF2QwPkKWNi396DJBLrvYIbraQN99urVq0MXhuuCBM5LwPbLHvAiYdjVmBP/jYHzkg3U0VdffbU1bdo05xjD2Vl9B5SUFq65MISnL4GRI0cG8/PzI6df8/ytcS5NApid1aePxPOtw5Vh3RfwD5Fl5RJOFOf5vMHBSUXmMAIlwUCgoWXbSUVW9ybk6BVyUu6eEgg8iFnusMCxR4Btf58wEgcKCwuVcy3WzMzeTUWBW8QLOLOgoEA91+2fTntjxtwyNBaNz+J4rvWyZQv/fTp1z+ey5wSwWZ2yLsEcMxNBGOFZ4T1dVy/RdWN03bQ6V7Oi1xeORWbUqV/v5srKSuBnfSRpx7zAQvUMU9tiGsZzgaDvE9OyLgYOSOcEtq5lGIrpOAgjeMg27CMYwfKIrL29adO6QwAA90wEPmjQoEY8L7XGmPEBAD/Ky5vz80fg6JtveU7TtTuXF+RxgwcPb8Xz+N+LFy+On0l7Z6Pu5FvvHAcgesYw9cScOTObnY02fi+a5wSwwwYNe902XWVF4fI/0o4O7DnkI8vSny3cXLh85JBxC0RRWj974avLjhfCkIE3P2gaWv+1xSva/1I4t+fc7tEYrY7qOpebqn4ZQ9hGjmP5ZTkhB4PBFNMyvzEcawfG7oenowkHDBg0lmW5cYSQ2T6f/3stqaH5i2a/RdsfPnxc47SUtLdURd3FImZyKBYu4yW3xcKFC88rm3vKlPuHEYx7eiSvfvjQobdnz3t10e8FrrPR7jkBbP/sAas5Vnxj+dr89X27DbgbIdR9bemq3iMHj3lV9Hk9hqa9ADDqtHDRrFdpJ4cNGnVjUtG2BtNSeixa9Ma71e14Tk6OB1noYkhwK05gWuuG6cGQHJBVdZfj4NJ165Ye/DVaffr0+4coCn7XdR4pKCio+GW5MaNuzWRF/hWRF8tU3WinKsq+vEUz+1WXt3NRLnfELZ1T09NeNU3jFd0wus2e88rQc9HuuWzjnAC2b8+BdzKEGS7YTM8KNVaUlp52p2UYEyEhyJ/K3xWPqXMIw+UtWjR7UxVgh968EwD0w7LlC3ufiTDGjh3LW5Z1FcZcZ9dxWimqJnv8/q1yPFRSUFAQO0a7X59BDwAAm6wrWjnlZO1NmzYN7dq1P0OQPE8jgG3C4lahinDzgoLZP5wJf7VZNycjx0Pq+N4PpgRX6rp6E7bw2Fl50/fWZhvnA61zAlja0e6dsjcjjG6wLfCVz+fZhRjy7xVrFj87cnhurmnbnoKC/Jk/Lb1j7kvEY895vFwzhFCMcGI7n9fXVlEUCzjGsnnz5u38heBoH6pjt8IJE25rr6pGL47jr0gk4h9A6PunqUV6IIIHrlq96OZfG5BevXLqIcQOqFOvzksY44OKohYtzvvnnb/nANJJ9NVXX8H9e8LZ6fUuejMRq/hngwYNuuuGtpnlxDvz82f+n/IOHJP12QQsnDx+cl/btD+NhCJGNKmM2vn1zn/Uq1cPNGrc+J6165e/OHzA8IsRw2TmF+TNoQyNHT724spE4geO5V5cuTr/nvHjx3tdk1xFeNLRNK2DjoPeXLjwtQPHA2XCrRM6aUktsnjx4i+qC6Dx4x/wmmZ4dCKhdNVVYxAneC5Zs2b+j7R+jx45KYKAfWvWLK36/T8P7NF98O0A4ldT66SvxBh+kLfg1Wer215Ny/Xt2/cSy4JdfD5vBkb4EsMw0wkhJkKIjUbjtmVZKYcOVtRVFPWwruv1LrvsMpCenv6KoslzjKRhc14iFxYWnDerQE3lcHy9swlYcMctd/SRk3qmCxx/NJoYnkwkZ7AcdwhjNI5j2b0czy3OX7Fg8TGGRo0Yt8kwTRRMEXvOmjXLrE4Hx40bl+44jG/BglnfVaf88WXGjr1tLAbc346UH5nP8uQVjPWoojiFAIDniotXbszIGMuXlc3XaJ3e2SPW+v2BOhYCbwd8vu//XU94o2zaNOt02/yt8n379hU1zewf8AcHGaZ5DQLAS1huD3CdI4IoHnBt9ytZVfaJou+QKAqMmlQLAICH9u7bf6kkSrcihkgYOs2//nrXIwghEAwGgSTy76enp78qa6G169atS9D2x42bms7zXOu0NN/hp556/OPa7MPZpnVWAUuZp0vX3m/21ovE5Xnpjfx9KBAnTZrEyFH7lR9/+P7W+o0afQOgs8J1wV7ogqcYQbpmyZJZlZMmTRItCzeeO3fmrrMlhDG5k+4FiNlgmiBpW9oDmqoOBtB5a+26pTnZ2UNG6brabevW4nFt2mRet3fPgc96ZPW4AyFwH0QQAQjumDPnpWLK2/jxtw1MJEIbfumRyM6eyqWkqOmLF8/ef6wP2dnZHM97Oq1eXVBlr9Mno2PWAH8w8KCiyNcEAv4Drgs2KqpaREjwvXXr5laB7JfPmDG3dhJ4zzAE0eXRUOSh/ILZVcCbMOGOi0LlkU0cx8/QDe1iwzBv2bNnj9i8efNZq9bk3TpgwJiWCFjvN2jQ6JvU1ODHokd6+MEHpx6k43T8hs3ZkvmZ0j3rgKUMjs6ZMAUCaC8omD1z1KipPtdINBUFsa+uWTovcXxlqHLYZ599dtU111wDWJaZDjBckZ6Sfreuam/NzZv5EqUxYsS4WzmOeVdV9fqiKH09b96Mfbm5t9WBtn3dwvw3NtMyubkTrgEA2nl5s7+ujmDG5E68EyK+nW2Bf0XCFR0rQ5V9mjRp9JdoJP4+J7LTbdscqyjhD2JRZ1daWh2h2WWXDH77rXe239i61Su27b5MCGzPcWTS/gN7Llq3duVFkybddU8oVHnJypWLpwwZMrq/1+u9m+eFqxVFudnjEXbFYsnBjmPc5ThwkWEk18uyPikcCvWLxWKBNm3b5AcC/k8ikUjbZs2aDKsOeCbfev9TrmuFX5v14ou0v1Mm3neJjZyXCIfvkWVVTcSSOQxnLDR1tkQUxcsRQk/JipIZjUR6X3vttR8EAr503VBlUeS1cCT8cTKpPvPaay8dbwpVR4zntMxZBezUqVN9ThI3wyzZqsrKUo5jdzsAXxIKV/ROSU3NdQ3wvQMtnmCmKy8K/QhBWxKJ5O3bt2+/7OKmTcFFF120XTOURY7lphimPs3nD3wQjYRbEYJWCB5xXTwazzx0qOK2JvXrXwlYZoKhKzovSq8xDBytqvqy/Py53/+WNCePnBw0OOZZTTHCiIA6sXhCRBB+/dVXnz/RqGHDMbwElhkG++q+ffsmXnfNdU8pqjKR54V0TJi2LAsuQQgSliMzIIQ7CObXxePRiQzD3aDr+mJZlnPr16+3jeelKzRNm4kx2mEYRh+PR7o9FArtC4XCflEUiKomPwcuLIfA/twfCFyJEHJDYeO2kpLf3pC4ZdyUHjwv9nxl5rNVvm363Dbprimu6wzUDOdJgSWCrKlf5+XN2ps7cvKjtmv3d2y7RYMG9afqutEMAHiRJAnbeY7EAIaHETK3TKtlE+dsIPmsAPb+O++8TDNQa5YlmdDFkqYaXTiRyxaxaMTV+ExB8IwFmhYqT8TLUoLBOYQwE55+4Yk/PPnkk5AFvkfLy8unSl7P0+UVR6ZGo9FGuq6TSCQC2rRp85mmaVdDiCoEjzggGo724zihezKZjAs8t5Sx2aKwFnoeI3SxZmgjli6dR5fi6ngQwPChE3cC4Cw3LD1hW+ZdLMNHFE2ZjBBpr+vGkx6PZzxC6B6Gwd/runb/qlWLq5b5kaPH9UcA1QMO2LJo0ZzdI0eOb6pp5kCWZTI4jt3JMNwLsdjBynr1Lm5fXl6+sLy8srHf79mpKMrjGOMvSkrWVNne/fr183IcxxQUFIRPNdATJkxIEbjgy0ml8pb583+yselDPyYxTvYjhPli5syXPz+eTk7ONDbgDY2UPN76L03/29OnauN8fX92AHv7/fWYAANZlq0wEk4XURICj/754YJpf/rL0xDAGy3dfkyx9HmiKH4W9AQ3uMDpFvB7Z8qK3K4yFL7D7/d/YJjG0w8/fu+/Hr532lXhWGg6yzAf6YYx+MCBA02CwaCell7n8N69+y5r2LDxFx6Pt2E8mRwTDVXm2o4zlCF4KCSk0jRVZ8mSeW+eSvijR02+WTdMr2sb3yxftXBbTk4Otm3ckxDiM3U7xzLNjYXrV7w+fOi4v7nQylu2LK9aJgdtNydnkh9CLV/X9RsAsJ4tL0ev7dhxZnEIU6b8cYKu6x+/8caMT0/Vt+PfT516/6UBX3D6U3995Iz826fTZm2XPSuAPZ5JClLgwsXT/vanL1945oWrGUbIkU19B3IchfeQz/SE24Rl2TWyLGt16qa/YiNhqaKEgrHYkb3UjnNdF0IIf9aSf/zjHwXksDdChtwZjyaurayM1A2Hw/6GDRuaqanBHRgRcvDgwYWCx79s/vyXoqcS2MiRE1tCx71+8dI5c39ZdmC/nHtiieTfr+abeQ57DluiGFyiKGR8QcGM5Kno0vcDBg19wLHAfbzArnUd/b7jNyuqU/9kZSZOnNgIQuaKN96YWWW3n87zpz/9pT0A1pi//nXaradT73wqe1YB++CDD/r9YvA5w9Vu/y37aMaMxcHbbx9VI0c39ThA6LkKOHZfwpJsOaHUFyXeZ5pmBEL4paZrm3wsV/Lq7FdP8EfSusmkcX8k4n2+pOQV/ZcDM3TIqGWO4zCSID4PGe47U9ceW7xk7h2nGsB+/QZfZzv2UoZhdEM3blu/fu37p6pT3ffjxo1rPG/evH3VLX98uUceevwJgPAHf/vbEyU1qX8+1DmrgH3qqacuQTbn/9O0B05r6TpTwUyZ8sdreVboo2paJ13XL1cUxX/UHZW0Hft76IJtpm2tB8DcZWjuaMnrL87Pn7Pnl22OGJF7k22Bu5cX5A0ZNmx0f5ET6wEMjXnzZs77Lf66ZWWPl0TxMU3VXt64sbjKw3E+PNOmTvNFYHxmMMU3btq0acb5wFNNeDirgK0JQ2ejzgPjH/AmiJHpOE4/XdcbWJbW8siR8jSv32cBiPNE0bObAPhhOB776liAzLChuQtYDtyfl5dXTnkaMXTiIss1phcULPzg13js33fIy4ZlXqdp2t3btm387Gz0paY07777vscYhvnXc889XVRTGudDvf+zgL333oeveP75p7/5pZCnTZvGH9hX8XAsFnNYnvvMMqzWhuU0Cfp9rSLRsN913d0cxzW3LAuxhLvHNuAnDvF9x7iJF+Jy/JOikuVv/JJmVlaWJIr+hcl4snzz1pLJ58PAHuNh2rRpYjicfERRlE9nz56x4nzirSa8/J8F7KMPPZHluiDbMpzZgh8fsFXUmDBMr8PlFc2A6y6b+caL//XRQnd6vvvsu7S4o9+FER5pmc5yCMnVDCYtLNOUK0ORyziOSQoS+3eOZb5zDOfj1euXfduy5SRSJ608j+GYt9etK6gKjzxfnjvuuLc7BPBW3dCWvPHGqyvPF77OhI//s4ClQnn44cfHMIiMUBQ56RH9n8YS8a9k7ZKiWbNu/dU4hZycm5slk6F9JSUlVR9hfftOEnneamyq2hTbtlsxLPOjbWnphGGwY1tIUZXWvCjxuqE9InJSGBK4z1W0zx3Ol6xTh5WrGxNxJoN4fF0aJ4Ac5zpWZHqaph1hHLRy5tyXz9r2dm3xXV06/6cBe9yyyJ7ph8bwnNwJALgtlxYsup3SrYqR/eq7hx1gtzANcxVGpDmE4FJR9DZGGIFEPJYSCKZ4Hdc9jCBEAJDdCLkKcB3Htq2Q7To/QIBCwEVh4LgHLeQmLQsqPK9bjuOYsiybV199NXXn0T3+qiCbqVOncoQQBIBfsG3VY6l6CmH5SxKKXE8U+UtN02xECKqQZflDScLbZsyYUSNvQnXB83uU+38CsLUh2EmTplyrqjE3Ly+v6owXDQ43VevPi5cteuBk9CdPfiioKOEUkfGkA+Q2RRg3RgDUcSCsC12bdV2XuK4bsyw33XWdoGVZOi/wBEHkGrrhcDxnmaZJDNPkeY77FkOG50RGUJK6zvHYhYBxIAEJVTEqGY77MRaLVBDCfDZnzot056xau3u1IZdzTeMCYGso8Ufvm9bNdnT26ReeXl9DEj9Xo9o6FAoxlmWJsiwjlg0SyzIhz3MYIWJLEidplbG4xUsWIbydmgqU/4V9/zOVy8nqXwBsDaX61KNP97SJ/va0adOqtetVw2YuVPuFBC4AtoaQmP736Y3ufPDOn+Nca0jmQrXTlMAFwJ6mwI4V/2WMQw3JXKh2mhK4ANjTFNj/S8W7tezmdwMuEW0bQp8Pcxzn2LbN8QBgLGFEHFZwGceRGBZDjkMcJjzLiEjycK6DEDRN09B1R1EUxUhLS9tTnaD0U8n3AmBPJaH/h99nZmaukSRvOscxDMvyJsuSmOu6dSF0OYSQhRHwYAhtjiWEYTlICAGiKFmiIFWYjvO+rCiJSCS2xDCM72rLH/1fgKXnjYLBYMPGDRpcWz+9nuK6gGCMzXg0ZiAOuYbhMJhgQDBxBEHgZDlGMMdZEEI68xTbsAWMXB0jZNo/zTCe+hGx69I8VAQQYggMAxBiRUKAQ+tB6oB3HJZlWYFG27uuq+m6rhuGEcEYu7ZtQ4wxjeSif7vCtm2s63rUtm3XMAyHFsUCdoEBEMWWSAiMqSr0cBxrW5aJMYYAQgRZSGjklSAISYZheJcQIjKsR+SkoOTz6Y5h6LCKZ4cADOxoNKmxLNI0TVPLy8sNhmGoL9RQVdURRdGnaVobQshhVVVDCLmXyrKWYVlWHV03OYZh/IZpAgig7gJHwJh4bduhPljNQUjWNNnDsqxjWmYd7BLHtAxsW3bCMi0NYxR1HOddhOBFiDBXQOjUMU1TZBhCXAcAQrBqmpYnnojbLMuaCBJb0zRGkrxA11ST5QToODYGACQdx9FsxyXAdUXXdYjjuppt2TZ9jzEG1KdrAl0UBJElhDgAINeyLGw7jqurht2wUf26lulATCCwTAfQfykoHceq+pchCNiqCliCgW6agGVZgDEBHCcASfQqBw4ccC3Hfm3ZsmX31da8P0HDjhw06CJ/atqiixpf9M+mFzd+v6IydFc4GhsIEbQwxpwgiYZhmIwsyx5JkkzXdW06MBBDFbhAJAw5xLLcQQQgdl2HMy074br2QQDgNQjRDrMRTFAcQYxc4NZnWIa1LMtj23bdoxH9NE8VZ1kWBdd3EMJDHMftsixrJ8Mwguu6fkVRJNM0vZqmIVVVjxiW4UIXmqqqGhBCFgNQKYqijZCLMUaKYRg8xwhhxCGbYRjDsux0hJApikIIY6YuywpGwONxVNP0s4iNYA7vURQHyXIIRiKqaVlJGwBAJ4YZjUatunXryj/++CMKBoPQ7/czmqZhx5El22Z9EEJiWSROiAVVVY2np6fTA4RElmUflCSUlGUHKsTEWJYwxmxC0/wCESzHsf2yHItzHGeEw+GkpmmVPM+7ADQCwaAsIVH0YNNkbWyzEHKmqcmXpqekA8MwaJ2kg1BASyYR7+VjyWQSIhu5RwNwKPAdx8E+hOw6AGDgOFUgpuMIGYYwmMOYF0maz+vzQkTcuvXqeNMC6Y09Xs9FXp+vmeM6jTBEkgsBsk2LIyyDOZbRAQQuBE7CMs2QpRm2pimRcDi0N1wZPagZ5vcYYisUinD0ZMZXX+/0GIbRsbi4uNpB778F7hMA2zcr64pAatqmdm3b/TWtft0l33z+5a69e/fWlbyeKELYUDUVGlR4rgMkSTJs02IoUBzHoVlWEITQQgjRwGtgWhbCCEHXdal24iCEAGNsU01Ko7IBANi0LaDrOrAsC9A/0R9a13F+yrjJMAzw+XxUi1BNXPW7qqpV5TmOsy3HpmrZdm3HMgwD8hxjAgBdxzRt16XGF2B4XkCGXVXewYTl6C6SIImuqqqcJHioBkeyrFIQGjzPqRAi27ZtwXEcQ1GSNEsi1ax0JVFNQ49ghLDokWzHtv3AdXlN1wWOpfPJpctBQteNIxgy/2Z57t+cIIBkPHqxbTspDMez8WiUFUTBk1BkP8uyjK6oEdd2Id3dAtDVVFUx/f6AKor8j3TjgOd5o0qbMZjmIWjCcRzVuEGPxxOV5cQhF5mSxyMoVLPJssxigvclYrLF8Zyg6aoi8p64A2yf46JKDN2Y5SAJE6BwjPgDxyEY8IiegNfH1q1T9xp/IHi5z+O7lBPEKwI+fx1ZVYBlmIDlOSBwPCAsBpapA8d1gc8ryYqqVyZkXVd1XY1Fo5+Gw7GdiiL/mEgo32GMP9+169+rvvzyqx6yrHV6552y92pDy54A2J6ZmTf6A8FN1119zfxrLmr82Ie7vj0YjUaTros7O7JTwYomeziRSOF5Hum6Hndd14McFAAEpDEIcQRjm+U4apZTIEmO43hc263al6cJICCGxtHTmxi5CEPoEE4UqYblbNv2YIz9CCHqQN9PTQPXdRsahmGLoigoitLYMAyZENIgkUjEVFWtoGUVTRE4nnd1RdtNCBYxRg6GKEUSubDruoqu6AFO4JrohhGFCDG2C3UAXBUR7JNEEWqqIXEcF9R1q5IQZAAA0+myyPO8ZBgGBsBxTdO0XNcVEQIpruuoLEMokHyWZUkIIc0wLNFxHGRbbtLr9XKyqjGGYQAIqpZdYFgmnSxUI1ZNSLp0RhNx4Fo24FnuP8usYwPoUHOHTuqqCSmKIjBNE+i6CgRBoCYQnfzAsgzAMBxgOQRYngDT1J1kMglYjrWBi6jphC3LoXTpJKO8Y6o0IISGAwBL6TMMI3MMSwiAEDgOkSRJMHRT5DihChNUOVBeBEECrmtX/U55oYc/eIGrUhymbQMXQmDZLjB1w5G8HqgpOuX7rUaNGmV+//3eGdFoeFgiEeu0bdu2Wgm3PAGw3TIyMoLBlDWXX3r54iaXXXL//u9/3Hv4yOEv3pg/r0ttzJAzpUHPW9E99v9KepydzR0LVqkh/RPSHdF2KioqmAAI8ABEgcKyLMfBdEexVCRiCmKWtsWyHPAJoiTLBme4bkLEmKIzRZO1BsG0oBOLqQKB0IrLcdGFEHGMcETTkgadJHR5rlq0q7RjDPG8FIAQChA6cmpqahNVVeuyLGsB4KTIsmxJkqRZFl3dbABdpDuOowJADgqCx4AQpGqGASzDsiirlmV7XdeVASJxBzpUQdhVqx9xAwhADyLEIgwnWJZjewJ+rCuaIIoe0XFdv2naHAJAEiSR11QjwbKELp3EBQ6xbcv2B3yxAwcOAobAqKknyy1Di1imyVnA7WbrVuu01NT3mja9uONbb7/3T4xx/7179nb/5psvqp2Z57RMgq5du+Z4BfGN9m3bPc9Iwj/iFaGvDx05vPv1uXO61RAM56xaTk6O38/zDaJytEfAE2jKcCSm61oEOLDSsMyQBfC/li799QyGp8toTk6fJrZqpjEsAxhRsm3VshCv7Fu8uKRWc8bSfnEcl64oEcfvFxOVjCYXziqkH7K1HjNAt4nLAEDpsRjDV2IUCOjW4cOpriQBJMvAAeArUFBQcNITC92zszsghIswRB9JAtcvFlfzZDl5DceiHlu3bj3hVMfpypuWP0HD9ujWrT/LsLNatbxh2pXXXTf/m8+//Pbbb7/9d96yJV1r0sC5qEOTEBPi3Ov1+bKJixrJSlJyLLvKFiaEqVpevb4AcCD4GED8XCKR+H7ZsmUf1oS37OxubQWG72Ra+k0AgOs4jpGoJ4MumQhV5b3azxD2AED4U4BI0RVXXPHJ6fofc3Jy2EAg0IolbgfdNNsBF1wWj8dT/H4ftf0TpqUnHQd9gxB8VxCEz2Ix5cvzIbFyt559MkRJXOu47ptFqwr6de7W83UCQcv9exNddu1656QZbE53DE4AbMZN1CTwLWpzY5tH6joNlu+Kf7V734EDXy5etqTn6RI/F+Vp1FRSUxaYujGUYwhIJBJAEsUq+4vajdROtBwAbNuu+njgeRFgQioOHDi0kOfwrPXr11crnXrXrl0vkgTu7mBKyoRkMumlk8C2TcAwBCiKAiTJU2Xj0XYIYYFuWMDv9x9QVXU1AEx+UdHqHaeSx6RJLZlk8tLODMPeahhmtqqq1CNSRT8lJQXYjgni8XhVv6gdSm1clmF0lhPedhB4eP4b82s0CU/FV3Xfd+3ePYvjpSKEYFHx2tWDumZlLbF0+1JdS3Z7//33a2XVOQGw3Tt26Sx6xPnXXHnVfYxPKpQj0Z37Dx7at6Rg2Xlhwx4T3qBB/TrYLm4neDxlDOYKo9FYPfoxQO22SCTynaaqXxqWnSQu4DhRbMgwTFP6IwhCFZjpBxDDMp/KydAzGR0zCn5LC3bp0qUXhPA+n8/XRdPNqo8kn88HDh8+TF1HMfoDMGQhwj6GEA8hrI8ClwKKejRYjA5YpvlU27at3/i1drKzsy/lGHwvL3rGJWWVpx9msiwDSJiqieD1eqs+fihdyr/EC9RTVfV/v98PTMPc7wD70dXLVy48G6ZCdUCbmZnZjWH5In/Qt8UxrX6ypqw1NDsQCVd0+fjjj6uV3O9U7ZwA2C4dO3bw8tKi5s2bP9Ts2qtW7friq0/37N+vh6LhTmVlZedFZFJWVpc2KSnpayBhbJbzDkskky+7Lrj6yJFDixAhy1gX/eA46oGysjKNfjzt37/fD1mxOcdxOa4Lc/x+byOW5YEixwFLQCxUUf7U9u1vP38yYWVkdBwQ8AdmAIjr0/e2g8xIIv5dPBx9R/KJmtmSAAAgAElEQVT6tiiqvM/DC1pMllnTNtNTAkHNtpxMVuD6SqJ4hSjwVZrYtWwzEg3/lSD017Kysv/KetilS7seKcG6f0nKaivCcFUa1HLpJgEBhOXKCcbrw5HIdxgikxM4j6GbTTyScA3Lsi2SSgLSyefaDgW1KsvxZ1L9wWePzwhzKhDU1vuuXbv25UVhdWpa2iavKI3bf/BAWTwe21u2tSyrtto40STo0KGVyAoLmjVr9kxKw3pLKg8e/mL/oUOyoqudS0tL5dpquKZ0unXr5vf5pKWEMD0Bwt+ZLhhQcaRiMM8K+yKhw3mnmskZ3Xre5LrOAz6vvy/DEuDaOnULxZRk8patW98sOJ6vjIyMVhC6s1NSUq7XderSgWZFKL7MNo3ZkbTAe7v/c4zmZH1p1a5TC0LwOJ/PM87n9Xh0RQWEQVao4shj27e/88yxOj27dGnOesRChnCXaYYOGJavsr1tAKkD/gWe5Ted5BYYOHDg6BQLqNdD4AxiOXYC3VWkKTZN06SepqcLV6/+U01lXNN6mZmZQ3hRWNKocaPCFH/woW+/2/1BIh5/b+OGjbVmTp4A2M7t27fjEDuradOmj9dr2qT40J593x4JVe5Zs25tp5p2pKb1cnJyBA65w01T+2zZqqJPKJ2srKxJPp/ndap9TNOmNmJX13X3nI5bq13Xrg0Dgi+HE5hpDIZ+ABwQqqj8WFX1/jt27KhKmJyRkcFbljmnTp30kXQZhhDHjxw58rxlWbM+/PDDw9XpE9Xu4YSSw7HkH8gFDSFyAcewsVDoyOBt297aUvU+HHqN57mJEOIquxQiYkAAXlZtc86GdeuqdRZr8MiRPQiAr8cTiYuo6WBS1JrG0DVr1pzT+80yMzMn8KIw+7Jml+Wl16//0s4vPt8RCoU+qThS3ulUiqQ68jyplyCjXbueDGL/cVGTxn9s1LzZloN79n5UEY5EV69dfU69BDk5GR7opv5V1dTRHM+NXbFi9dqcnJx0ANyNpmm0oHvnsVhsjSAIQwoKCuj26Wk/PXv2vNPrlf4uCAJP7cQ9e/b8/d1333uIEsrM7NxdEKQ1giCJ1E4Mh8NvvP322zTFz2m7ktp37pxbP73ua5hAkdq0hOCvdDXSTdNQi0AgsNKyLIHuv3M8D6KRyL1FReteON3O9Ojdu1swmFKoyQpPTQSvx/OtpimZa9euPWfnurp3734HZsirLVr8YdklF10y+50d726KRqM7DU1vV1JSO66+EzRsp7ZthxJAHm3YqOG0S6+5cs3BPXs3Hy6vYDmR71xTYJyu8DMyMohH5P/M8fzDhBBZ07Wha9cWre/Ro9vgOnXqrqBf6IZh0RiZEUVFRatPl/6x8i1btmQaNKifhzEa9p9t4+8PHjyc9e677/7QpUvGQkHgR9GJEY/Hd1uW1X/Lli2/vF+hWk23nDSJ8ez69iGv13e9bmtxBEALnuWnm7Y9SFfVPimp6YDuVHm8nlVXX3lFzum6wY4x0b1Xr9s4zN6SlpbqpxNDTsoPFRWtPWe5CDIzMx8gLPP3jh07fXHZ5Zc/v6Fk/fyDhw59qivqjb+026sluJMUOgGwHVu37g1d+Jf69eo/sqxwzYYJuWPeK4+EHMu2M05n2a0pQ7Re//792wQCgU2WZXl1Xf9e07QuRUVFe3Nzc5dHIpEcmgo9EomUCYLQ49ec2NVtPyMjY2y9enXmUcDKsqwzDM5JJNRvg8HgDtu2A/QD6NChQw9t3br179WlebJyx3bO9PR0mKZpku2ivoIkzEUuAIpugAYNGnz9474f+28qKvr2TNrp129EXY6zRNtmHI5z5SVLllSeCb3Tqdu5c+e/8qLwSK/s7C+uuOqKvy/JX7ookUhuX1lQ0Pl06PxW2ZMAtt0Ax7Yfr1c3bfLK9es/GDNiVFkkEbPXFRWdM5NgyJAhmV6vdzP1OQIApq9cufKu4cOHXwwAeNtxnIb0j4qiPFZUVPSXMxVEr169rvV4xLd0XfdTWhzHPe3z+b45cqRiAXWBKYpy0DCMzNLS0hOyyJxJ25k9sp85GmjzIPVW0I8sWZaf3VRS9OCZ0Py963bu3PmfgiTePmDAgM+uvPKqFXPnznnqyJEjH25YX9KmJqbUyfpzAmDbtGg1nCPkHq/kG39jRvudu3d+s70yGjE0Q8+qLbV+KsGOGDGiM8bMNtM0oW2b41esWDEvN3fscE1Tl1AQ0V2lcDiatX79up/vCTgVzV97n52dnS4I3DsQwssocAKpaeUsw3y/e/futoFAACTi8XUbN2wcSONBatrGyer17jcg3wXuCIRo/CgHNMMYXLx6xarabONc0+rRo8ccRPD43r17H2jfvt2il156+cFoNLrL1I3ra2t1PgGw7Vq0Gs0QZqLHJ050WfawxHBv2wDsWb1uTd9zJYDBgwf38Hh8Ja7r0jDUTsuWLf5w+PCRNDX6C9Q2kyQJqKrecfXqgrfPlCdqL6enp60BwO1d9bHiD4BoNFrVBt1hkuXki1s3b73nTNv5Zf2evfsUMCw7hGpYQkg4Eo90KC0srFUtXts8n4peVlbWdBeCqf3799/X/qYOBS+98OI90Wh0dzwaa1FbPvwTANv2hhuHEoQm+nzSLViSKrDtbnUw2rOucN2wUzFcW+8HDsy5yevzbbYsy7QtpzXNeH3XXffdsv/A/llej1i121NZGepXUlJEryg642fYsJwVqm4MrtrKpXG8pgkQpIH6LkgmEjM2by49ZU7Y02Vi4NChC0zDHE0BK0nSnsrDB24qKSn5nz6F27Vr1ycAgtOGDBlS3qF9h7UvvPjCLZFo5PMDe/e3OmturbYtWk5lMOkjiNxELEnlXlbYElWS+0o3lY443UGpaflRoyY20rTEeoZlr+U5YdT8+bPyb7116hBZSRZoqlwVT6rr+hMrVxb8uaZtHKvXu3fvYGpq8IOkojajflDqfK/aEgVVMaMgEo2sdW1rON01O9O2jq8/ZPiIZYqiDKUmgcfrCZtKsu3KlSvP6IOrNvmrCa2MjIynCMs8mjN06K62bdqueumlFx+urKzcq6vajaWlpVVpS8/0OdGGbdnyMRaSrqJHuMVl2UN+0bMlmkzs2bR50znTsLRTvfsPmu7xeKZCgNfJ8coR6emNGiMMdtimFaQuIE1XlhUWrqWT6LT9oscLbcSIETfZtrnVsGyGbkZQG5k633d//2OVWWAo2k7XtXqtX7++VsLjjrU9ZOiQ5yzLvo9geg4Kg1g0NmLDhuKlZzqgv2f9Ll26vMqLwh2DBw3e8ocWLUpmzPjnPyoqysMJzWhTtnHj7trg7WSAvZeFJEsU2LFsIBBjAdqi2ebu4vXrc2ujwerSGJk7tpfjussd22UJxH3z8+dtHDR4WDGDSS+qYW3HVAFwhuTn559RqqCcnMELdV3PdSGqAmh6ejpgGPbN7374sTPVtq5ty0lFHr15w4Za/SDKyckZAhAsMHSrCrDRWCx/6+bSUdWVz/lYLiMjY6bH572tV+9e66666sqlCxfk5VeUlx9KxBM3lJWVVWt38FT9OokN2+oRgnCGJLBjOCeYZFPRO5ptfl5UXPyrlwefqpGavKcneEVf2lxdU/sIojCwYEne1sGDRwz1eiS6lFYdNUEYLl6y5NcvNT5Vu2PHjh2eTMYX0CO7CVmpiptt1KBxPBAIDjtcWb4oHA6nBn1+6oddo6ny6HfeqXlM56RJE3onEkma4dC2LJsTPL7vEAT5ibjMUpvcsc3DhJAuK1eurPGH19ChA8ebtt1J5MWDpm3YCMC1S5eu/OhUcqit9xkZGS+JHumuzp06r7u0efOnitet/bCiouKrZDzxh9ryMJ0I2BYtH2QJm8ULzFh/3bpHLEXbqOp6bMPm0gG11bHq0unXL6c5w+Apup58jm4c0MBmw3BmsyzJBS4CKanB4tdfn9GnuvSOL3fbbbeMCocjr7iuSzMHAsywVdFRCJK9GIGrwtH43TzHVfl56eHCSLjy5W3btt1bg7bgmNxR9yTl5F8wYXiMGWDZ9n6GkM6qZjxqWdY4qmGBa1PbeT3LsjcXFxef9gUl/fr168ByaJ1tuSmEQUCRNcDz/ISVK1efcDtODfpQrSodO3acIXqkyW3btF3Y9PJL3ti6adtbFZWVH64vLGpdLQLVKHQCYG+8rsWdvCj2xTaTK6QJiki4zYqhHirZuLF/NejVehHqdjp+dtJdsGAwWBqLJXyXX97sbZ/PN2T//v09vV7vqmefffaUUe13TZxYN2qqUzhMHghFY6zt0MN6P4GV+ncxxt+GQqEWPM97BEHYqGna9fQdhFCWZfklx3H+uXHjxkPV6Si9AM40jVc0TR9JV4SkIgOfN0DzFdyVn583PbtfvxZeQaL+Zj/9wKO2OURwg8hztxcUVP8W7pybc5rzkM+PxiM30MOJqiqDQCDlWyUpn9NYgk6dOs0URfG2Vq1a/b1OnTolH330UVkikfh49erVN57pt8YxeZ8A2JYtWtwpccIwFsMRXp6XkejZquvaR0WlGydUZ5DORZn+/fu/Ztv2rddee+3n6enpt+x4592SFH/gw/Q6ac+Wh8Mfz5o1K/ZLPqZNm0Z+/PHboX7J+0x5qLKxmlQBK/A0OgrQI+v0OLPX7wPxaOz9WCzWs6ysLJqZlTmgYb2GefFkwkNPt1qODeREsiyYFnzu8ksv3/Bbe/633jr2MsdBzx44cHiAIIlVGo8GdIuCuEzT5NHHtpQHDBg8VJTEfFmWMZ0Y1NxhGOZTwjFTVi1f/s5vyZPe/i1J0mBE8F8ikQi97+yYlyPh9fnHrVy+/Jymie/QocN0n893+w033HDnUb6++PLLL7eXl5fvwhi337hx4ylveKwOdk4AbOsWLR6kGhZgnMuybNjHC1t0w/youHTDbdUheC7K5Obm0vP5eYIghBs1avTI7t3f74xHYwBi4KSlpP7bhW4pg/B7nMjRKC5VVbUrbcsakEgmW4dDIez1+YCuGgARDHwBv6EZButYFognk8DQtFI5kRywY8cOesgPdOjQYUqDJo3/IicSfl8gABiMaTnZI4pvua7zbsAX+NB13R/oMWyMnXTkomtMx+4cCkV7R2JRel8Y8Hg8wLEBIBy7XU3ER6xbt+7g8XLq1rPX/amBwDO2bVdlr6EmguNaEYTgcobl1xMIP0cIhaoytZgmq+v6JQyD/sDzwqB4Uu4WiUQwPQFBNTTGOIkxeWrNqlXPnouxOL6Nzp07z/H7/aOaNm06PCUl5dDu3bvfjUQin1ZWVt50TJ5nytOJJkGLlo9KktiNcZ2RUJJiHobdYtr2Z4UbSs6r2/P+cz19PQAcr+M620MVlT6WZ4BpGECQeCDyAognE1Xn/mleAApQiBAQeB4kkknAMbxKGPh6MD1teSIRX2bbdmPHcdyDBw+u1pLy8OMd3ZlZWQPq1a83I5FI1KebC1ST0R23qqQftu2kpaUoCGBgWLpg6hauDIeo/fjzuTKGYTTNtBYihnl6zdKlJ70te+jw4ffZljONECIdy02g6Qp1s1kMw8TqptdJuq7t0Ew2iqIEwuGwQD/WEGGqNPdPZ8nIYV3V7l+zZs2iMwVGTep369ZtKcZ4YPPmzSlgv/3www/fk2W5tKysbFBN6J2szkkBezQYJJMFYGSlolQ2qle/1LTsz9ZvLLm7thqtTTq5ubmSZrsTOczebgPn8kQ0BlzkAui4gOF/OoQoayqgqX0i8RgIeH2m6diFwHIXrliRT2NssUPIp5FI5Jq0tDRXTiZLHF0f9Mu97/6DB7fhBeFZ07I6/SeyCxD0U9A1zTVlaiYgHAG2YVe1S+1hQRAcANztlum8dP01VxaeKmxwyPDh7Xle+qssJzLoNjH9GKTRXCxHqg4f0klAzYafElwIVTEI9P+iKKrRSHRjMBB4MT8/f3ttyvd0aLVu3bqobt26WQ0aNBjJsuzOcDi849ChQ0Vbt26tNXfdiSbBDa2eFUWxFetYww2WDUuCsB44zlfFGzf+fM356XTiXJXNzslJ5wDuZ+p6e7p1pSpKs0AgkKapmmFaRgQj8q1mGDtsy/rAVBMfHQNkRkaGJ5CevsYFoJ2qqqqu659A0+x3sp2tvn37prmEDMSENPL5fO1s2+5gGWZVUDY9jfufDC3UBo0rsvymZTn5mhwvPJ2jRSNGjEiLJNQpHq+QEwwEm8QjUZqbqmoC0BMLx04DUy3PsmylaZlbdN0ssFNTSwpnzaJplX6vB3bs2HFrMBhsm5aW1p8m+aioqNiiKMrcbdu21Zo5eTIN+6THI3WwgDuiXigUkxs13uAC8FlJ6fkN2ONHiWrNeBz4GQZUZQl0HJlmLEz8WgB6x8zM6xzL8rOMICICwls2bKC+y9/cQcvOzvYxjHgxIDgVE9TMsd1U27GP0DxcHC99em3zS74+lUb9LWQNHDg6VVWjaZxX/AN0zHaGYTH+oN80DEMwTUvkCPMVI3Ar8+fPP1+2c1GXLl3WBwKBDEEQRgIAIoqibKisrMx7++23J9bWLDoRsC1bPiaKYluI8TCSIJgNokIHgI82bC6t9Yil2urEBTrnhwTatGmzOhgMdg8Gg/0QQnooFCrVNG1hWVlZrd0OeaJJ0LLlgxzHd8IsM9g0zZSgP7BR17U3N23ZMuV8EMvIkSOD+fn5p+1YP5737Ox+UwBA/y4pWVN6Lvo0fPioTNsGhwIBEZqKKc5ffGYJL4YPH97YRlydgvwFH58L/qvTRrt27QQIYWEwGGwhSVI/27ZpNslNsVhsyfbt22vtg/0EwHZo2/YRgHDmgYMHejdr1qyOwPHbdV1bXbp58+9qw44ePboFwzAPcBzXMJlMzlm4cOGCwYMHX6bq6jjHcTjoYgdilMry3MI1K1aUZWX3GQJccDVwHIVlpfyiooKDvXr1v5vj2C8hRCMNy3o/GQ/NJki4GxHUTNO0t7Zv37KY+jYNw73Fte3mnMAvKyxc/WZW1+yugOD+Es99FomH8o+3b2koJEJ4GCT4a12Jz/f5fERVzVssy27GIrJuxZplJaNGjZ0ncOxnHMNcp2iaPW/BnFuOgaBPTk5Dr+AdFq6s2OOT+ELqn83o3v0P0EUNGeSWUfuXbp74U+pkMAwJWjq7SfSAWwGC/U012ZGaOTm5uU3keLz++rX//zX348ePb0oICZ3MJ10dANagDGzTps0qn8+XJYpif0EQlHA4XKrreuGbb75Za5F+JwC21Q03POvxeK8o2/5mv6MMXJeenl6l1jdv3nzSC9Rq0LEaVRkxYkRZo0aNvpUkaeOePXvolml3VVUfY1mWHrgLer3eK0KhUKFtuy4AztMsI36IMXZcxyFyMvmk4PG8D13ncQ4y99iM87LrkrxYLFoHQdDB4/W9F64MpWCmzrPIDd3sQtjS5/eWJWPJUZIk5SXk+J1eyf+1YeodHMu8o2hD0RbaiYEDc3oiiJ8QeO5fiYTSSPRID6iq3M0jSY/xHLPMtt1hmMF3soQZzTC4zHVBU1PVkjPnvH4/rT9s2LBrjl4O8LRqaA7P8y0UOTneMExPalraP0x672Y4/B4S2SdYRMYwhL2dMISHELwMIXbLy4/cXb9B3S6aqkrQdWchjOolE/HZxYXF9+fm5g4HGP0VuWD0ggULfnPzoUaD8SuVbrrppgJJkrpBCHvRpMmO46xPJpMlb7311lkEbMtW0xmMm+/44P0e7du3/0NqamqJqqqLNm/eXCXk3+uZPHny9qNO6W8RQjt/+OGHpxmGoUK5y7Zt6kNtF48nvT5fyjMQWtOi0eR0r8ezxAXuPFVWetgueAEhmE55X7du5asDBw4qEATPc6qq3O3aYPeadSse7927f0dNS+6URP+jCIJkIMX3vBzX1juuW1fVlO9S0wIDI6H431iGfXfV2oJlPwF22PMsQ65etnxx9piREzomdfUQx5LXGILltDoNpu7b+8MHPo/3bRe6/vS0tA9kWbYTcmLv/Plzq24EHzFsxP2IcG0XL54/ePjw3Da6bsRNy3ieYZhsjPEe13W9hGXuQAQ/jwBYjDCOCIKYiRmy48C+/ePrpPjbxJPydNe1B/I8b4dCoXD9uvV6IIJn65q2e+GChec0JPQ/gO1q23ZvhJCIENpwNK/vnO3bt589G/aGG254SZKk6xVFyWIYpmF6evp2XdeLjgbgVt2x+ns9kyZNuuHoVUNPapp2Ocb40NGkxxNlWe7kuuQTnmebm6ZD74l4T1WtYa5rvK6bzkCeFa5CBAUdCz6uW3J3nuEDhYWrXho4cPBthKAlSVXt7vf4/xyNRg9C6EYZhtypKGYTSRLu03U15DjutYSQUpp7VZaT93OcOIEQuLO4uHgblUPfvn07+7wpcxVV2c+wbHPHtqZCgiUM8bOWZVQwhFzlOPYcr9fHKYqylxDCuC7YmZc3fz6tn5MzoidCYDbLsq8dtfWa27a7SBC4a0VRfCQWix8B0K1gvZ4xImHXOa79rCAICY5hHwSu++6u736YelGTJjfbht7Ydq37Av6AvHffXq5Og/Q+PBFXR2KhexfOXVjjI/A1GGfUpk2bAp/P18lxnEEMw9D7EooNw5i+ffv2x2pA76RVTozWatt2Ns/zV9m2XRXsEgwG36YZ+DZt2lSVYOL3fKi7ShCEgN/vT77yyitVWb3/8xzrh0vLHHNf9enTp6Ft2wmaxIFGemma5issLKTHnn9OYNyjR+8uLnKu8AhC4apVq6qOqGRmZqYyjJSmaXG6tRul93cEg8EDFRWmNz2dUY4/Wt6v36AOAKFuGKMjwDELVq9eHcrJGXGTbmlXAhsATuK/cwzjIL2/AEJW4jgkz50793vaDs3F+tFH/xrEcUwbVdX3SRI/t6KiQhNF7yCe5xobhratVatWn374ySdD66SmvqMoSkOWFS5DiPnEAs4ijsOrmjRo8Ncff/xxbDyZvFTyeL7Imz9/We6Y3GmIExYumDWL3jt7rh7Yvn37ZZIkUQ1L3VpJQkiJYRh/LisrO2nespowdgJgb7rpptl0m7KioqJfo0aNvH6/f5uqqmtLS0sfrUYDJ2SyrkadWilCP16SFSBWVlZwXiSsq5VO/QaRyZMnBw/LMlq9cCENKvkvnzGdCGfiA64J7+3bt68DIVzH83wd27Z7OY7TgOf5NfQo05tvvvliTWierM6Jbq3WrV/gef7y7du39+nYsWN6MBikJsHGjRs3/urW7Pjx472mrj+ACPFAB+5heKYhz/OfHj58eGltZIuh9I/af4/5/f7L6H6/LMsfH71f4Lljmo7miD1SHn0SAmbJ+vUFnx7TullZ/VuXlq59v2t29qW27t7wZqe2K8G0abV6XPuYUHv06dOaxUwHgpCqu3aFxDDvFBQU1EqUfW0N9unQ6du37xWFp3GKt2PHjvUJIfT0h8d13XYY4x4IoddN07yvrKzstdNp+7fKngDY9u3bvy6KYtPNmzd3b9euXUpaWtq7lmWVlpSU3PlrhIYNG3hNwJfyjGm7k3RdT9JZxmE8wgGu57VZbzw4fvz46zkGXYsIDv/zn6+vnzRpEgNtu5MNnSYIMT8ahvGv+fPnR3+Nfk5OTvOUlLRS13WnO471eTyuKq5rfFJQUKBSbfLpFzv7Gap2vSRxM+hSpGkaNBzYxTasRxlCbjcMLY3nxYmiyIykE2jAgAGBWEy+WhCYCprQuHv37g1E0XuVZhsVlYcO7Tw+8KVjxx71WRZ7U1Kk7042+ejJCIDYx1hMujnA/YxAfNiwrWs9guiTVZrs49SJjGtrMGtCp1+ffg/Yts0UlxT/7XhN3bdX38GKmryesOxL1QkNzMzMvBwBtIrehqNoSqbAcf0IYWZohv7Y9u3bz55JcOONN77h8/kut227B50tPp/vHdM015WUlPyql2Ds2FHX2qaTlbd4yX8xdsvYMRsxw76iyInOR09M38cw7L0OQqu8Iv/3eDx5gHDMYdcFlzIsaq9r+mPz5y86aba9n3yK3HLHAVMMQ/42NTVVefHFF1XqVrJtZ7QgiQeVZNIyLDuFISTFMs2/JxV5VFpq6uR4IvE3jyj9aLtOO1OXH3cAecg2LQIRFHiOvc517TLDMJvSyyY8Hh9naNbW0s3Fr2RlZdVxXZIDHKcphKjCARaPMabnyIo2btz41c+atUf23aLg6UsY9u6CgsU/XzwxaFBObwywULBq6YqhQ28erOvq/rVrV75P62Vn9x3guvD7DRvWfd6//+A2SlLJEgQ+1TTtEEDmPHrcu1ev/tdalnMpITBMCBNNJhPUv/l5UdGa0uzsvp0FjmslSAI2Tf3D5cuXV30EDhkyIFPTrCsIId+vWbOmZNiwYTc4jtORECQYhvV9KBRa9cujKv379iuBEHZjOLZDQUHBB8f61Se712JMSJaWTGRs3Lbt5/7+2qTIzMxsigBYZVuOoFtGF46QzoRh5xqW+WRZWdnP6UVrMqmOr/NfGpY6qC3LWgYhbCgIQqYsy6kpKSlUw84vKSn5VRt2/PjcVsm4PHD5ilX/lZP07runromGI+9AjJsYut5vcf7Si8aOHf0MxrjDnDnzOh5jZPz4cQtUVftqyZIlJ43hvPnmm5sJgvdj0zA/NQ3jcCKR/JETPNNdx3hN07V/FRWteZzS6t27f7ejl9W97jruKACs/RAzswgSJ2paohPLMb0c2/gLx3sKFVm/AyHjA4S5VQi6XXTdeNzv97xwtJ8Xywn9CV4kd5mG+yfbsjFA1pP0iHJWVq9ODINnAODcXVxcvJm2R02RREIudV348KpVy98ZOHDYlT4ff1U8rhxBCDaAECoej7A5HI6sRgh/uGbNqio+R4wY9aZhmEssSz8i8N6HIQJ/03V6posZjCFsHo1X3g4huYNl2FFqUhvDS3w2YchEVVVGY8z4REF4UlP12Y5tRhme9FRVpdw0PQ9gHF/g9fqzjno87lZV/VJR5LMty1nuuvYBlhV6JxLReGpq6tS8vBsSoKEAACAASURBVLyqPL90vAOBwDJRFK9PJBLFhYWFd/0kx94dMcbTIYQXqao6rLS09JQZdmhKfQLROpqJUdbUjiIn9mBY8rpuGtSGrbXY3P8CbOvWrVN9Pt8KQgi/d+/ezmlpaRcFAoEdpmlSwP7q9YujRg1rCwAes3hx/s/+ttzc3CsRArNMU5vKEG6CZRqXLF6yvE/uqJGvenzefTNnvv5zcrURI0bQjYC6S5Ys+XkH6PhZNXLkyNYMFpY4ljPeQfg7CDXbNLFomfoChG26zO89Vr5ndt8thmW+pia9RYSNvK4kIxPqNmg0xTbsa3heeEnRlBcRsIbSZe6mmzK6+Xwe6oIaSXNn0V0uCMjrjuUshwjd5wDn0eLitW8do92rV5/nHcd6c8OGDevo32j+Wtt2Nquq/mRJSVHpgAGDnkAIXQaAS68dbWJZdneeZ+9TFI1GK61fu3b1Q9RbASHeYVnWhqOO9dYcK7SxbHsJxzDlqqLFHeCMxYT5s2OZ7UzbxsXFa6b27TtwpWs7h5JK7O709PofMYRxdMN8GUI3HQCnpeu6fSGE/0QItVEUpSIlJfCneDy5+ejNlU+vXFkw89jk0jRjq2EYS1atWvEK/VtWVpbk96cUiSK3xHGcruFweHpxcfG7PXv2zMMYH2AYpomu67NLSkq2nkozVq1ItlNkWVbQTYJ2UHJ6MSw327DMx8rKys4okd6valj6onXr1gtTUlKaQwi727adyvP8e0dv4Ju7fv36h3/dhh12OcMws49eXPYIy7JRXdebCYLQ1TCMtQsW/H/tvXeUVdXZP77L6efWKYCoWGNiTGyI0pmhDUyDGUAEgSgisUTjq6/GmCLG/kajxMQoKiYWFAYYps/AzACiGAu2WNIsxIIwzJ1bT93lN/uaIYBgLHd+6/vHnLVYS+ees/c5z372s5/6ef7UUVlZeWdhYeGwRx55ZN6FF14o/KkihfF+z/O6egvvzu7toPgrXTfve+yxP15//vmLFnNOavfPF5g/f9HZGOHfOm5aoBVmy1/EwnOKb7R8ey8nyhMApJOM4fkAwd8wwOf6gL5dEIg8Ee+JPxkOh3/heO5a4tH7OaD3Meqe197enpg+/fyQLGcaOafXNTQ0/HnmzJmn+x5fLSvyFdQn8xHCCUVD13d1dXHDCE7WNOU+13UW9/lhxXvMmnXu5RijRZzTK/qO1AULFhzh++QG1/UuppS2G4YxCkJ4/9NPr/qFkGpHH33M323b3sAYi2iq8S3dMK6P7emWZF2WVVUdl0wmmyllV0EI3mloqP1VZUX1tl5n/EtGj/KzVNh+MxwM/8u2nWaIgeI63ihd1yYyTh+VkPxdSZHf9jynJZVMPxINBCfX1NXsU1NmzZq7gfrkkw3167I+9aqqqkEYy8+Ew9Fre3q6R0IIj5Zl3JTJONdFIsEFiUTyQdcld7a1NTX9N4YtKioqUCSlw/dd0WzuHMT5PElW/uD63rVbt27NbpBcXJ8zuoqLi1d6nnfi0KFDSz7++ONBBQUFgmGXNzc3H1YP+exoTE0zTdPwfT8ly7Lt+/5fnnrqKZFuBy688MLvCujMxx9/PKvDXXrppSN935/kuu5gjPGnnmh3SHHr6tWPv3nBBUtKM5nESzU1NV19H7hw4cJBhPDRhLgi1r4PvLiysjLounSpJClHUurHOGcFEGOZ+vzeWGzoB2bwvRsDhh4khB4JJVynSnCDZZHrMhnztuefr7GFRKWU30wpXNnW1vBWRUXFcbKk30yocw3GelhRpN+mUqmMqqhBAeLOGN1DKfllU1NT1o/67wtOn152taIoZ3EOkwhxQ1GU76VSqXcNQ7/DsqxPJUktYUy8p1QrUBJ7225elUql/9c0tbpUwrpeltV3g+FgtyJJZ+zt7iaMa7fLkn8L4+zD5ub628tKZzzj+/6rGzc1/7iiouonlNDzonn59yYSiQyGUAA+m7bjLwkE9Nqurr3PHXXUoGvSKece23HyEAJ/DJthZDl2CaGkFCJ4fp8uXVZWfTyEZGs4HFnqeew9xtx2CGGebdt3Mqb9QVXpy5mMdYVpam/t3r33nOeff3bV4Zhu6tSpRwMOmojvKyzDi5DBK2RFvd8j/i83b958ey6YVYxxAMMOHz7cyMvLE4AR2qZNm4rKyspOliRpu+/79zY3N9+Uq0lzPc706uqjuGVJra2tfeUnWX/wfkEEOHXqVNHV2S0sLET7O/4FNHxhYaHftxFKSkryQqFQQvz/5MlzwqbifYdhVEiI81pLS4uAkz9knuycOXMClmWN4ZwP0jTtvVAotGP/xhgzZ86cTgg52/d9cdS+DwD4hyhdF9lnsVhmlGGoIwFA/0gm99YL6V8xvWoCxzDV2Lj+lRkzZo92XS8tjDTxTY5DJlhWZpqmGYWShD5JpeL3d3Z2fjx9evnFqmp0bdiwZoPwnrz55t8WIwgXeK5HGWDbEMIbNmzY5/bLnlKEsFt83326sbHxlaqq2Rf29MS/W1gYvf6TTz4xItH82wCnD7qMBajjVW7e3HHD4dZu0qRJI2SMa31CLM/3Z0tIKlFV5XbX967evHnzb3O15gczrByNRteqqjokFosVmaZ5rGmaL/i+/1Bzc/PXqcn/xu95/vnnh3pj6nczhhqefvqJrO44cH15CogNsWfPHiY2wZd/6rM7v0oAYtKkSacqklwv+vK6vlepYDxFVtQ7POJf2dnZmc2dyMX1OS8BhHCdoiiDXdctAgCcHgwGBRL28i/yEnyVF5k/f/7xwjgQaWc1NQdGpRYuPO8s1/WCa9as3yxKRRBiZxLCbqSUjpZl9UYAwJqnnnrqrwsWzD0tlXLGYIwtSkGaENKNEH+hoaEhWyIiJEfSdYeFVPVf+0vT8vKZZ3MIvi8hlAaA/uWMM87468ERodLSqpNUFZ/EGNQAoXEC3B2HA7YQ0jkSiWgbNmw4pA9ZhHjz8vJEpcMBrS5LSkqEk11vamoSkvZQEhuWTSo7TgkpqmVJu9vaaj5XIi266USjUfubIpB/lbX7ontF4CBoBDoc14Gu75UokvRDXTeu9oh/eXt7e87APD6nEgQCgVpVVfN6s8VHi3IHwzDqKKV3Nzc35ySBoXLmzEsRgvdLkvyTtWvW7HN3zDxv5rGmpG7xPR9zjk/2PK9YktDTuq6/QimL6bqan06n/7RmzbqHzjtv7rOShEem01YjYzClGebRxBN9D7yrxRFaUlJ+GmX0j6qhXN5UV7d93rwfnLK769NrwsHQkViWYr5PqSJLgzKW/RECYHljY+3rFRWzvuN51kJTDy5IW+n3g4Hgx4yzoQggobs+Wlu3VjRsO+AqKSm5LhgMnrh27dqlB/9WVFT0nYKCgnWWZb2eTCYvf/bZZ7NJ5+Xl5VWGYfwfxthIJjMvua5fr+vS02KziQ2gacEfaIo60XXd7weCpsw4T8dj8Y2RQOCxdQ3r3iqfXD6MIHCNYepF6UzKURRpm+M4L8qyXLd/4WR1dfUVnPMhPT09N/b5XkXPWkrpeb7vv9LQ0JDTrolFRUVHGZqxybFtxiCfxBn/qaHrSzziX9TR0ZEzkLsDGFa4OTKZzHpVVY/WdX1MKpU6ORwOC5zWu1paWrI+xG96LVq06EepVEpYjbYkSWfV1NRkG13MPrfq8d6UuAWRcDiWSFjfDQbV0ZpuPGQaelGKu7vtLlsW5c6O40iaJv/Fdb3mNWvWZovbJk2qyg8E0P9iSTqPM1BCKT0NIvAkBGA6pfxTysh6TdeaPcjuaqypybY1KimpPNEMmjekk/F3DUN90vdpYzgcPtL32TJC7CdOO+20ntdeey1k23QqQuAWhNitTU1Nf9r/+8vKyh7lHJ6CMSzqk+59R+kLL7z0mKZpZ3IOhvi+d29TU0MWGnTy5Kk3Dh06dBkA4PJeF9O30ynrEgBx1XvvvdM+ZNCRj4TC4XJC2QoVS50u9TOI82MlWb5RkpWAZdtllPpBCOAWxlg942QLAOxYXVfPzWQyD7S3d2btjJKSkjNVVe4UBp4sS1c0Nrb8Tvy9srLyDFWVn+ec/2rt2vUispWzS/hhNVXd5NgOdTx3girLP1JV7VrC6EXt7e2HNda+6gscwLBjxowJappWgzEeHI/HJxuGcUQwGNxMCLmhpaUlJ3rI+eef/xhCaDylNJlOp1+qr6+/6Pzzz7sYAPhLy7J3AMCLgIImAI+eZJj6Ks8lL4dCIe77HkilrEdPO+20R9566y9/TqVSW1tbN+6LvgkXlW6SvwPGfyfL6tupdPLBvGi0OpVKzw4EzCmmqZ62YsWKQ7aPLCur/IGuaysdx72wsbHuc5K0rGzGz3RdmbB2bc0BHf16s8Ee0nXzuK6u3QIpZl93wylTSi6XJOm+o48++gbHcSYnk8lzLMst2rixaUdl5czrJEm6LRQKr00k4kdBgEcnU8nppmYEsSytcT33uqamurv2X8jS0tJjdC242fe8bYZmPkwBraOMXwqA94ymaYPj8djdpmnmvffeB2fn5+crIlihqtqxkUgktXPnTsM0gzNqamp2VFdXF0PI23Xd/PETTzyRZeJcXUVFRceauiGS/Rl3wCQmk/M0Tb/Rp2RRR0dHzvqFHcCwp59+eqSgoEB4CQxCyGRd1wf3IuptJYRc09LSkk1a/iZXUdEyaejQf2wHAHwYCgWvyWSsVghBreM4CxljN0AIuaqqj4muMQihUwFgy/PyChZBCF8XPsuurq5/nHrqqbvfeeedlxljf66pqdmXo1tZOetUWZG2AoQuUxSFxvZ2r45GIuVIkr7HCF3y6afOGQdncpVVVX3PS/tuJKJrlHKRq3BTbe26AxI1hg9fKg87KrbK8Rzc0tJ4ACBERUXFNkJ4pqWlcV+nv5KS6iMUhT4ny/Jxtm0LjwDXNO2o3bv3rN+6tXNWaWn59eFw+FYIwQrP830I8JJMOv0AkvCnju0sC4VDZevXfxZq3f+qqKhq4ZRlsCytZJQ9GjCN27u6u2bKMh4ViUSSe/fu/emmTZsenjZt2s8hhDcHg8E4pVS3LEullNaEw+F5mUzmjFAotDkcDlc/+OCD/zV69VXWuqio6ETTMDe5juNC15lIZfkyRVGvdH1vwebNm3NmLB/AsCNGjDg6FArVZjKZj//85z/PGD9+/LfC4fAWQsjVuWBYQYDLLrv8iXg8sXvVqieuOffc8y7xPE9EYh7ZsGH9ktmzZ0/lHD4sy3g8pVy4gX5vGMYWQrw9CEmDEAK/UVV1ayqVelU0YovFen4NAMxDkhTRNe1Mz3Vfrqtbd0NFxcxpkWjeGitjjbesxNtmIFrLGOWe6zwWCATteDxOsCyfxRhdiAD/bVNTw33TppXerCjKItf2a8yg8WfiUo9BPpgxVoEgHMM4Xdrc3HAAVtWcOXOeZQwM9X33Fs+jcUmCH3gemRcMBhf19PT8XNfVVzKZTELXzemKovyaMTAXQj4+EolcTgibCyH6hBIiUFokQv1LZVn5bcAMKJ/u/nQJxvw9z5MdDdNju+OJOVjCl5mBwEUIoQ8hAG2+6y1VdD0OAFlHqf+yqqrjCSHfgxBvdBzrb4qivuL7XgAAJHFOzzUMY7FhGDt7ehKb8/OjV2UymYdM05Rz1ZN2SnHxGFU31zuOHWeAT+WUnqtp+q98SvpPJRCGgud5qzRNe7+zs3OW8MP2Ht+dvVb4FS0tLTlpUHbR/IuO8bBnP/7443sEaksm4307FNLfE9la4v/37k2cZNvJvxQWHlsAoXcuhPAsgUYZDIS17lj3o2vXrm6prp6zkHN+KiFEZQAFJYRSju81tzXXt4pNIXJjoUMnAOBvELplZeXioCSlf8Q5nwYxFuqFACv4iPq0NhjMFv6lRZO5YcOGneO6pMzK2KcXFBQUZDKZJMboXQzwmrqm9dn8gf0v0UbUMMwSx/YLTdM8ihD6F4yQ2pOIPbZ584F629Sp5cshBx/rph7HCIn2RsQn3m7IgSeryn1r166uq6qaM4pTfrsRMI7jjAswDtcwzWNt2+YAgt/LMrwtnXZGKbLyR+qTKxtb6hrKplX+QA9ov3Vdci3G6GRZkmcDSMb3oR8Kv63r+h3BQDjMgX+n57In8vIjdjqVeV83NBv57sKHHnvs719Fmh7q3snjx39fCwSaHMftGtvZMWLrhOIlmqbe5RH/4o6Ojm98OvfNeYCEPfPMM08uLCx83Pf9f3V2dlZPmDBhusgtEBnkzc3Ndd/0o/Z/XjDnhx9+6H4NoNuvnSQu/Irbt2/XVVXl+xtJh1yAyZPDhmGw+vr6w0J47u+nnD59+lEAAFegxxyqY4q4V8wj3GiVlZVDETIUxiyPcx4/+F2qq6uPIQTm6bokpXrsiGrij2pra98Rz4sARSrlHqkoQFQxiOoHOmPGrJJIIEIcks4QglLr1j11QHaViOABIJ2alxd603X5WaqKj5EkRfF9+0Pbttcd7F78OuucVQl0o9lxnbSiqqPsjH2Vrms3+ZQsbW9v/5xd8HXmEM8cwLAjR44809SNx0XdUeeWzjnF44sXmSHzD4SQBa2trTmrD1q0YNFPEIKXSJK80ycUc87/nkmlGizXaslVP6cvIsikSZMGq6oq8iX+crCPVSS0iIiUbds7ReRs6tSpw4PB4MmW5TqyLLxM3I7H7de2bWvbJaSXbdvfAwAEGxsbv7AF079LdETpteo4zvsH914VOQZ5eXnDMMMFsiHvXrVq1Rf2VBDjnXLKKeRgP7IIN7uuC78KPNLXZZ79nxOeCc55E6V0t+d5UwAA14ZCoasdx/lxR0fH73Mxx+EY9jHG+a7NWzZPKS4untUb7fojIeRHra2tB7h0vu4LCEmz8/0P3hfAwZCjexHmWipj/QRQelY8kZrd3Na8TizeUUccMdknZBjxvCNDeXnbP/300y37MTOsnDbt+5ppHpNKuSHC2WBFkd8ghCYpdf7236I6lZWVP+eU3eT53u1tB5X+FBUVLTGMwEOyLP+2rq72x7NmzXkwkUgsDQaDHyWTqb9qmhI0zQCLxfZe3d7e/ufp06evF+mYnudN/aJ5S0tLT0II3Ycx/p6qqs+tWbPm3P1pOLOy8jpV1ZYVDiq0U8kUzWSs+7536vduPZghRcK4pih3O7ZzUkALXVFTX/M3IUEZY5cFg8Eizrns+34mmUw+jRBaLVIjhcTuhVC6wTTN7zHGwrquJ5LJ5PuyLN/55JP/yeH9umsqnisuLj7FMIyNvcWhH7muOwlCeLEsy7/uram7pqOjY/k3GXv/Zw+QsKNHjx5laPqfOOA7Ojo7502cMKHCCAZXUkoXt7S05KQnlpBKoUDob5Ii/erBBx987IolVxzFVHbtB++9f6WiqT+SJGlDJpP5nSopthkKbCKelw8QGsspI/Fk4vq2trZ/lpaW/tDUzYXxZHyjrAXiCIDTGaMTMJbCyUT8wq1bO7/wXUtLS5erinoB4DxtOfaCtra2rFUukpCj0fw23/dP7M0Fvq+9feOVkyaV/C4SCVdmMk65iOWL0hFZVjsTifj2jo722VOnTl0TCARO3L1794Qv6oEgdORvfetbQzzP+zXn/Pja2tr9YdTh7Fmz7ouEwuNVTa9Lp1LDGWdjrUR8+Lr9es9WVVWdBDlY4TjOhFAoRGLxnpGjR49+9a233mpRVXUCpfQu27Zf9jzvmF5Ew5+k0+lXgsHgeZZlybquLwgGg4OF7t+Lii3SEUU/sml1dXVtuWCmoqKi03Vdb8hkMp9SSicGAgERTLmJECIk7CO5mONzEnbs2LHDdUV7gjPW3r6l84ri4uIy0zSfEDqsOKtzMamQnt86/oTXPc/9qYCqTNv24wAAXUCxG4ZxSyKRuENRlCWapv0xnU6/YJom8X2/OJ1OCwhH0cT4JkrpZkrpdY2NjfsMwcklpReqsnw/RvDi+vovxketrKx8GEOMOKddhMHhZ511xlQhyaZNK30YAJ4nScq3KCXPt7Q0La2omHGDJOFyyyKLLKunSNeDZyEEyjnnT7S1tVw/adKkJ3RdPyGdTo/7Mvr47Nmz7xF+aM75WFHisz9NF1+w+OpUKnl5IBAIO46Tn0glpzc3N2cNyZkzZx6rycqqYCgcliTpr59+uqtCAvLpNXU1b8+dO1c08ujp6emZ3IcUAyFsj0Qip7uue7YoA+qbZ+HChcJg/d3evXufGDJkyDW58hIUFxcPN02z3XXdlzZt2lQybty4uzRNW8IYE5GunBjsn2PYMWPGDDN1Yw1l7J2Ozo4LJ02YME4PBlt7M4wubmtry0m0QqQiIg7/gTG81XLdVRDCxwGClZaTmbB+zfpnKqtn3o8AvJQxenM0HG2nkHIr7YxVVeUWy8rcDjm8C8uycHU9YWfsP4gFElI7kbIuMnTtnlQyPaujo6112rRp35YkyRYZUQdvtPLy8j8Zimbbvns1Y6Cec9DEGItJEr4yGDRLEonkTZIkF9TXb5g7adKUm4SETSTS/xMImPcwRgUTrHRd+3IBWTRt2rQ2VVV1RVEmf5m4/uTJk/+vsLCwNJPJjOoz6ObMmSPK6o/TAXidKsowQsgQDNG1EEL69JrVY4XDX1e19eFwWNN17ZJkKl3iOs65e2Pd5YKhy8vLp+bl5d2dTCYJhPB9xlg+Qkj4gW8YOXLkqj61Yu7cuSdACLdbllXXiwL+uXDyNxFIEydOHK0oSq1t29u3bt1aNXHixN+KpiCu6y7uNy/B+JHjT9aC2mrO2Zub2tvnFxUVlQcCgRpCyCW50mGFhB1UUPDLSF7exhUrVjwrjAdFU35NCNm1+qnVd8yZM+dIx/Ou03TtW1jCn2CA1IxlCaCxtySEltfU1MSqZlVdLEnyfZTQh0SWPpakb2OMiwU6NaO8vK2taXNZWfl9vk92b9zY+rmO31VVVQ8Rz0s1NDVdXV4+o4IQf4WiyMD36VUtLY2rS0vL1iiKmtmwYf2FlZUzf84Yn+t5tkhwPsL36cpgMKQkk5kfbt7c9npVVdUG27anU0pF4+Z073+/EIvFnj5cq8ry8vL7g8Hg8N7CztF9KY0zZsyo0FVtVTqduiug6/Wi2QFh7H5GmVyzft3p1TOrl0EIfh4MBf+WiCd2hUKh0el0Wu+tTH3ep6RCYCFUVlaeGI1GL9m7d+81GGPHtu1ZmzZt2tfDTNB9yJAhGyRJGuq6bnFfIvw3YdL9ny0uLq42DONxz/NWb9q0afGoUaMeCIfDi3uLUv+339ILx40bd6qh6U9zxl7a2NH+g4lFRT8yAoF7/63D5sw10fehQjL2Oa8F3ur+lvPChQu/F4/HAxhjH2Oc3L+tpZAomqY9allWjSyrMdd1zjLNwNienthKVVV+JcaZOLH8SEny/EO1jJwyZYqAYIJPP/30q2IhTTO4VBgrzc2NWeOgqqpqQm89PW9ubn6mV4KO8n12PKXeOiFRRZjUcbwliqI939ra2FxcXDwjHA5PFritkiQV2Lb9Nuf8zsMZYBUVFfMty4pSSh/cX4WYWTFzaTBkXkmzWGCWJknofVlVrxbvKBLVdV0/wvd9F2Ms3Gxzie9fCCi99rThw7f1SdDy8vIbVVW9zHGcXzQ1Na3Yn6HmzZt3mW3bl0II59XW1r6ZK0btG2f8+PETTdNcl06n27dt2zZn/PjxtwQCgett2xYJ3DnLWzjA6Bo7duzxAcNczxh9c2N7+4LiCcVLzaB5NyFkbmtr6zfqOHgoAglfrCzL4ZUrV4o2Ql+6BafwNOzYsaMEQljh+1SVJCnjOO4rkUhw1Zc5lnO9WLkaT2zasKrm+RjLwWDww8Ppl591IC80D5aS4sj3PA/X1tZ+LhAgDDZJkkSiukhpzPk1ZsyYcQUFBa2JROKFLVu2TJw4ceJVCKE7e3Ekbuzs7Oy3qtnvqJKyAUG4vWVT2+KpkybNxopyvyRJcxoaGrbm8iuFvzAcDF4mS/I4y7Ylz/f/ijDaaFnW/u6rLzPlVw4kCAgjSZJGMMbyJEnNUNf7MJFJvLI/jKbIi4XMOw4r+N1kMvnB/tJQuJYQ0r6FAT2ecAJ1Xf943bov7jg4depUUX4tm6b5/hc56kVg4ODfhd6fSCRCUGAdmaZ3wgkn7N3f3fXvAIbY8F96038Zwn6Ve8aPH19qmuZTlmW9uHXr1iljx479ma7rVzHGzu3o6PhcbsRXGfuwbq3J48efgVVtFUSwubWt7ZopE6cskTX55l4H+yxRTfl1JznUcxdccMHpnLJ2AOCtELB/EsqHU+r/2Mpkfl7X2Jh1NH9mGWvnWLY1jFO+Qwtozx6Ia1UZhAwWEULyHN/5WFXVf4mW9Rs3bvxCKVJeXn4xxvg+SZLe8V0/YQYCim05OywnfbNQIaZMmna1LONZsiK9ATg8Ph7veW3rtq0inApKp5aeg2XpOizhIzgHMQ564TpIFgtgO4RweV1d3b6iv/2/u7S09G6M8WzHceo3bdp0xcE0EdKVMXRPJBKWGfN/2OdBmDt37smW5dyv68aJ4hnf92xZljrfffefVwg9ORs1g+gOwNlxElbuWlu7dl9EUuS/+o6zyCfsnGgkoqYzmY+xjJ/4b5vr66zzuHHjZgUCAcGwT2/dunXR+PHjlwvoeErpgvb29py4zj7nJRDxYKxoNQDCx9o2td02dfLk30uKUo0QmtbY2Pj61/mQwz0zf/78003DeCRjWZPze3osfvTRJ2Vs57nuWPea+qamJdUzZy7FEM2XFfmfgIvuPvKZxPdf392996aOjo73ZpSXl8qSfK7tu44qS3sAwkcR3zubEPbX5paWOV8kbcrKyi7TNONWhKQKAMjzClC+m8gkNzJKb2lua/799JLSt8PhcFzm0nkZ6p4kQ1i0et3qn1dMqxjhM/qQLOMazdBWd3V1CclLKysrh1NKFzHG3mlpacmWVR98ieYf+fn5t3qed3pDQ8OE/X8XR7xhmA+kUumLIpG8BzVN+p8+hhWVF47jzKaUqwjh4b7vLUQIAzUDQgAAIABJREFUrWpoqMt2ZsnWkqWsqRywew3T7Fy7bu0FfWOXTiu9PRQKzk2nU08qivYBZbQYI3S2T0nlV4Eh+jLrPnbs2KpejN6n0+n0k9u2bVs8fvx4gSA0rzfML7wE/ePWmjp+/HFQ1eoRxE+3bGy5derkqZdKivRLznlVS0vLn7/Mi3/Zey644IJjOeX3MMB+QV3vTlGSwzl/QZWNKwgiuxSI3zFMI+H53uuBQMjt3rPnGMdzx2qaujKRyfxPfiTyoue6HWvWr7+8b86Ksum/NozAuN1dXWO/yCdaWVm52HG8n6qqvAQB9B3AQZHtOGdEI5H/Xb12dWNpacVCwHkZIwRjSUoiAJ9saGnonFlZta7XDwxr69ZXi+qAcCC8AGAQZIy9p+u6CLmSTCaztaOjo/tQdCgtLb1AluUZdXV1VX2/C9gkx3HvjEaj8zgHb3HOj47Fev4RjebduGbNgS2MKioq7xHN5NLp5MSWlpYDkAnnzJ7d4breG/UN9Vmk9Dlz5uS5tvMCoWR9c0tL9nQ4r7JyaNLzX9R14w/ratfd+mXX6svcN3r06AXhcPhPqVTqT88+++zisWPHPiC6NPZW+87o7OzM2el8gNEl/K6Soj6BIL6vZWPLXSWTSy7GChaZ8sKB3Qey9mXe/7/e88MLf/hdh9q/jfX0VAaDwXOJ54ua/5q6hobF4pgLB0Pbfd97MxgMPue6viUhdILtOlf09PTUBcOhcwFlWyll72JFuuSUU06x/vWvf5lWInGnQ7yjNtQ1VIoXmDZt2rGO43x6cAuj0tLShQCgXyAEfgAYFNG1+bbtXty2qflhcTQriiKwEnb0BjIkz/F+4TjOuHwlf2Lcjy8zg+apAIHJAICwbblXqZosGr0JgLmZvZ6LYxhjor/rIRdIbBTOubAHpu+TgqXlt4VCoeshRCWEuFsxxmUAoPW+7zWuW7e2ou++qVOnLw6HQ3dQyq5Yv/4zQOX9r/Ky8k5GyTPNra2imkFUFwyWEH5GlpUnV9eszlY7iDyJdCr1jCKrq+saDkwS/68L9l9uGDNmzPnBYPDhRCLR/Pzzz88aO3bsLcIP63le6TPPPPPqNx2/7/mDixAnq7KyAiNpeXNb8/LpJSVXIUm6DEJY3NjYmC0tydUl4IcAACJP89eiEmBmefnZsq7f7HneL+vq6l6orq6eq2naYkDYP1zqF+qafkJ3rHsXJ2RV66ZNT80oL78wGAo/YmdSHeFQ+G3Lto7nnJd298RWtHduuVQsTjKRXC4r8gOihHn/9y4pKSmjlN/CmDSTMbM7FPBqEUIfx5M9S0zTHGan7bWyqjYjDDo5BTNlWTkLxnkJCZM8yNH9WEIf+a7/mqEbHznE8QzD+A7G+HIBmpFOp//ncAk85eXl1yKEZtbX14/Zj2F/HolEbiCEzrdt8rqiwFLTNJbv2bP7idbWluzxPmvWeeeoqrQ+k8k8WldXe0jIqBmVM1oggC9sqN+QZVihZoTM4BaAwFtnDh9+qTDS5s6eO5Uy8pDl2D/si6Dlaj1Hjhx5SSQSubunp6f+hRdemDdq1Khf6Lp+ue/7pdu2bTuA/t9kzoMl7AhJUZ+UJPxIU0vLndOmTbsMY3wpIWTql+1g/RVeBhYVFeGDrO9QNBrFfagvApmEUjqMAhA0VFXgQe3oc7bPmjWrRJKkOllCL3JKP6IeOdbx3JM911vWvGlT1p9aOnHiMWZ+/q5DVa1yjk7HGHQK5po5feYJGTdT7DO/sbdFz+4Z5TPKk6n0WFWVkQDHkFXc1tjYmAVKq5pUlZ/BzgyMwMmyrBZCxAOO4yQ1TWtOJBIbvkgVKS8vrxBNRdat+09Vg1AJPM//paYZYzzP5aZpCkjRl3zfvX7Dhg3ZU62qavYqCHkgFAqeezhXV2nJ9FqE8fbG5sZf963BtClT5gSCwStF0SGEkECIRqTTmU0+9W//MmHkr7CWYNSoUVeFw+H/i8Vij7/44osXjR49ellvXvUPXNctf+655/4rmNyXnetgCXu6KitPSRjd09TauqK0pORyhKVLkIRLDm7o+2Un6K/7ysrKorIsVzNGTpYhMonn+4TS10aMHv3H/z/BfIUky8Hiw7Ky6uMMA5uMMcmyrLcPyEyrrDyJc979b/TwQ5K0qqrq5GQyGevo6Mii7fRdIpNLxeoxCHNVQmj3qpr/AGnkcm1Gjhx5QSQSebinp+f3L7zwwo9Hjx59t67rIueitLOzM2dI4AcWIZ49ZlwobDwOELq1pa3toYqysv/FEFX7nJUdrjZ/5rRp8wRKHoLSXkVVdMrY3/MikTX3PPBATlWI/Yn7b8l7WjKZ3CyYRUSC6uvrBfI2F3mZgIBBSEGbxaKXTZ06GkvKRIjAX5V0urVmy5Z0ZUnJiUCEc5ECXep+ZFnWPw+VdC1wBRRFGQYAOEoByrt1LXXZCl9xfYbA4gzjPh+CFL+rvr7tn32/iepjReFDAVDdg3MZRLCEO84RHMLBlp9J1NY2Cemzz38qQtUAgCGWZaWampoE3sG+38R3cs7p8OHDncNsys+dWrlkyi8aa9TZZ883zMDKVCp5+4svv3zTOWef84iha2Nd35+6ffv2L8zt/SrveADDjhs3rkST5AdkSb6zeVPbA1MnT74CcnBuiJLpYqEPNXBVyfSthYV5OoToDlVX8izLrWIAHKXJcvn9jz764SWXXHKsBNkIRdGPT8TTb3LMn1m5cmU2i1+4bKjnlVmuq2AMPgUAv6Yoyu7/Fq2aPXu2AOFdlkqlftbe3r4PjlzkZEYjkVWu6yqO6xZRl56clxdeCTh4BWN0IqXkXx7nl0LG7hhSOLi8JxF/EyCocA53xZPx6zo6OvZFiMrLy0/Dwr8JoOM5Tg+DYAgEcF3rxtZHRHhWxvg2jPAJhLEuXVcLemLdrWYQ/q62tqO7cvr0MT6nvzUMU/V8cmEfBsC8efMG2+nUckPXTxT9mACABclM+g+mGRQ5Et6MGeWl4VD4Stf2jmeMWY7j3d3Q3CBqvnjp1KnjzVDkGuozxXasvzkZ+9HNz27OuhqnTJnyLYSk83RNOc3J2N0Q4Edb2v/j1RGBhRe2b58ja5pdX1+/ryCwsnL6GYiisZSRYMgId6XSic31bf/ZeH3rPXny+DMYk/YIOKTDMdeos8++yDADv0kmU798acdLy0eNGPGgrhtFnm1Nf/all/bHIvsq/Pm5ew9g2HOGD59qBsP3csivF5WOFdOn/8z1yESP+mWHahaclTQzZ7brirTtsTVrf7V06dJ8nYGl7364839MRSkN5eefADG6Q1LkVyUs/1Vgh6bTmeHUZZd93PXxO3nR6FOckZMJY08hhAKMsSiEQIAL397U9FmO6qGuGZWVKxCULoAQfuAR97w+o6pofNF9gwYV/rCrq+tvhNGJAcNYpKraL/KjkVkYYxzvSZziMrJWk+R6CUt/Lxw65CrXdc98/90PREuhB5tbGrPuH3GVTit72AyYx6XSyYscx/koGooWp9OZ3yJZ+YHvOhUB07jAc72FXT1dLxYWFp6i63pNLBZbsXXr1tuEywtjvEjTtN9wzs9rbm5uFGNWzZhxazAYWuI59nzquu8BrEyjxL/T990LU65bFzECb0AIdwYj0RUYop+lU6khLveHM8tSsWK0yZLyRiQYadjbs/fHjDKvvq1+zOTxk09WTeUxCNELEoRvIAmfRjx7tJOxqzc+88z7RUVFkYhp/lzCeCmD7Or1dY0Pi3epnlG6hBJ2DSOsFQL+EQJorGKoUU7Bkpr6+v+cFkVFF2EV3+pT/oc+3INDrcnZZ539I9M0bkmnkte+9MorD406a8SDqqaNyrhO2UsvvfThN+LS/R4+gGEnTJhQ7Lve8khe9Eci8WNycfFKjKVhyUy64vnnnz8gd7NvjJnlZa2yhFvyw9GXu+PxVQihsGYYP5M876k49V8JhUJHFxYUPEIpfMV33eMSqeR1ru2sQRiutTLWA1hV5q9bty4bCRFQnJ988tF6sdB1dQ2HBRCbUV5ZBxF2MUR7YsnYcZzzWYSQ0woLCv/kOW7a891ExLLKY4ZhBE3zqkw6MzwcicJ0Mv7QsJ6ehp2R6FPhcPg0z/casaQQANDwZCJ+x6bOTdlWniLZelDBkE5KWevG9pasv1KoAMSjzzJKH4mnUrqp6ZfannXFhAkTNm/btu07AghakqRVHR0dWaQ+Uaev63obY+zqtra2LFzl3Dnn1vfE487GTRuz1QZlkyYdb4TCz3mO+0TCztw0pKDwVd+jcc/z39I0tdTzvJ3KB+oYd5j7HUVVn0UY/1mRpOd8Qi50Xe/TDz/dOS4ajY5RVfXcpqambMn7wnnzxvbEetZJGJXELeuDgKz+2ife4mg0nyYTPSskSbrX4XxXUFW3IAgzNfX1ApIKXCD8wZBtdSz3oQ1tbVnMgpKJ438SzSu8wXXtUKwnvnLrs9svOhzjjRg+4krTNG5NpZI37Hj11fvOHj7ifk1Vh/ucTn/++ec/B7X0dRn4YKiiYkPXlwMIl2zbtu3FqZOntLmeB76dSZev2LHjkCAUc6pmboxG87avWLly2QULz7/Htuw5DGGROvevuXPnvGmaphkIBH6jSkomkUwfnUwmrvSJvzo/EtkQi8V/73O6QLixxAfMr64+3oNwg5XJ/Ka5tfWPwvkt0gkP/rjZVXM2I4xexDL6dSqVac9k7NcgBkcwQv8SDIabJQlfL0lwTjwePx2h4N/z8lTmON7NlNCZnu0s1A19CeP8SMexV0uKultm6KUNLRv2GQaCYQuiBS1mILh1/Ya1N4v5hV7KGdysyvLyXXt2rQkHo9cEQoGRyWRKgQh+V5Kk533PuXTLli1ZnC2BLAMgaVIV6Ue9bqwsBsC8eQuafN/7ZO3aNVng5ilTKocqGnzOtu0nTd14GSL4uOu492um+ZLrODMChjnRspLTKIUFCOEaJKHHfeK/RzxSoanGYItkzt+ycWM28yoLFWQEZvg+qdZV7WW/y70VhfntkqSWIcx+h6AUI8wv9T1yBmPg2oKC6DWJeOLdhtbmRX30PXfGjJaeRLp105aO5eXTpv1U09SfRPMKHkim41Uf7fxk83MvPH/YNvJnDz97vqary5Pp1I2vvfba/WefeeZvFFktdhmp7DcJO3LkyDGcsJvDeZGLRDx+8sSJWwAA3e2dnbMOtyMuvPAHN0OIt61cuTIrnS78wcJfeoRoTz751A3z5s0Za5qhWzGGn3oOjauaekKiJ57k1L/56XXrXps3Z+5WylkEIfhwOmXZEIMSEXWSoDxJ0qXdPbGeu0Lh0PV9/bP63mHWzFlPAgj+tq523a9KSktnyVh+GGO0gzNa5fv8FN/3ropGQ4sYQ/cz5n/fdf17IQSiV+tJEIIrXNu9GwDc2tzacNh2PBVlFZd5nl/KIVuuSVqPT/2RjLEFkiItaWpqyjLJ5MnTqmUZP+F6Xh1G4JpNmzZ90veOkyZN+q5uBBpFy83a2pps1cCsWXPu831/Qi9E5tJEwt2jaXi467l3UU6Xqop2qqTIt3keqQqb2paE7U2TMV7u+c4MQtgUXdOvlVVpbF1NzduV1XMqU+nUgxKSLop1Dd1kRnfOi4bDPwGMHy9jfKeuy78WFcmKrG0T3oVINFQtdORF8xcV98RiIpJ5ued7lRgj+axRI6qEAVdaVDrE5VZ9NBj5+afxvYqhqitUTU9Qn7xsBMzJqWRyV8axL3z22WcPGaI/66yzZuuqdn86lfnpq2+8+sjI4SP+KMnSGZbnznrllVf2qRhfV7L2PXewW2ushKRfDD5i8EVPPvnkx5UVFVs4AO82NDQsPtxES5cuNYYOHeotW7ZsH1TPJZdcMmjIkCHZjKKlS+cVJJP8nEBA123b2+l53ut9RtWsGRW/kWWt3HW9NWbACFhpKwQxzEOyvAAAoOhIHod0ZevBHWbmVs09CevYPemkkz7csmULkjWtlEH4z46WlreFu0tRAsNqa1e/Xll53lAs0yscK6MbRmCnZaVqRMOLysrK8b7v721padln9R/8fcJQeePVV+cQQkcAziCl3ImEg81PrlkjolhZy72itGIeBfT0XrDmuw/Ou62urj7Kdd2re6GE/tCXy1tdXX28oRk/isX2nq7ISoAQQimAq1tamu4tKSk5UVWNGyn1T3MctycUCmHOQc2GDeuWl5SUnNLbMOR21/VUScJ7GaP5COHnZBnfFktkJnIJrQyZAdVzvbTtOO8izuKB/MjVLOMeL0vyLbZtE13V4pIshfZ27d2jGtKVGCsjGCF3uJ7zummYb0sIn4kwznMSziJP4lFFwaf5PgkiBE1FUebZtq34Pl8oktYPxQsjzhxRrWrKH9Lp1M9ee+ONh0cOH/EklqWTHd+buWPHjs9VfXxdxj2AYUtKSsbpqv6LY48/dukQdUjPzuTOfzDGXjjiiCNmvPXWW7CmpobNmTNHPu6441RWyFggE+BHHHGEv2vXLpxIJGA4HIbd3d00Pz+ffvDBB4FAABmeJ3WtWLFCMPPnUt8WV1YGcWHhYsDYqb7vOwjCv3BJWvfoo4/uQ9/+uh/2//JzF8y8INLDe44WJeP1+xk44p2rq6vH6LoeTSaTbzU0NByQdbZg7oIze3G5FNdx40+te0rUcQHhJtvVtesMLGkWBCCkIHSMrut7ervHdAjBMKti1imRvFCl7/u6ZWfeh5L0ZJ/AOG/WrLMY5xMzmZSqa8ZOilBrbW3tnoNpd+655xb7viPV1n6m2hzqOuuss6ZoivpwKpW+9/W/vH7PyOEjHsWydFratipef/31nLk4D2DY6upq0Yl52axZs37oeZ7z2muvvep5nqwZRpMsyyHPcyXf9wtVVSsMh0KuYRqUMuL7nqdCCJFwevuC82wnlkqnoozzMIZoN6HU4pR2IYR7EAAqY+xT7pMU5TyZl1fAQuHgd6hH0gywWCadTnMAZAixkZU/CLiAAdNj7H0ZyapHvAJVkoO8t6GCRzxiu24cSlIylUpogHMfYVmmxIsjJAcMQ+W+7WLGWKC390EIY4n5ruMRxhMyxnmc010Yg90iCoQx2iNJEnAtLwglQAmhgIvxOAr6zCeMMQchsBsA4QbjBuaYMcQLhPeBc5bEnPuEQh0h5HOEkjIANkRIxgi5jBBLxth1IPQghCbw/QKXuYy5zIeKklKI4kATUkIIlC3L7WHMCgQCGvZwyCOeDFRAOeeiFabY9HpvybZnmmbWpuhWuj3yIaG9nc3p93UdpwYPhplMhhXIsgkVX8W+Yg074gjahWLI98MiOQeqmYwUR4jquu4NHTo0C8G/bNmyrEBZunSp9Pe//50XFhZyIaD2Z85ly5bBwwVlxo8fP5r6pMZx7DuE0VU8dvw6z3NPTLtOab8x7KJFi4rD4fBtU6ZMuXLw4MHSm2++ueXZ7c8phmEA8U+UBotLlmWgKAoQVa+MEWBZllhc8U94EgilzMtk0kQsLGOiHTzXIAcKhJBRSna5joeJ65qUUtf3iBvNyxN94hUrY8kFBQVYjJ/JZGSEkCwolkqlgK6b2Xk9zwOMsezfNEPPim2fUVGyDATDybLsBwIBVzSX830fc0KBpmnYsiyBvILF8wJ0zrZtGImGAPMF1jAj0WjU832fi/t64ShRIBAA6XSaQQhlCKEkOi+Lokbx35RSSAgR36fKSBbvQxijkHMgAQ4IRFDsJ4AQ4qINu/huwciCdpxziXMumB5xBDnCsocQErTxs3/j3BHMSSnFhBCGxS5jTNCZM0YBFLtAlqmiKJKsYAAQsxgjCDDoAABMjJCDIUxBBvJ6G/Hl6arqM8aoQLuxLJvqmkYkWXS3or7rOlxVRHuKdDcVE2IsOnAL8DoXIQQ13WAAUKrKmuZzmvAJScW6Y8Rx7Ld279lNMcS7GATdtsc8wMB0WZau9jz/xmeefebOieMmrBHGaFdPbNobb7yR7eGbi+sACXvBBReMLCgouG/x4sV35RfmH80oG2a7TkiRVYgwkgDjlHGeoYQ4lJBuQsh7u3btemdvem8svTctkLC9ZDIpCK10d3f7EGYkzrNl2kIQaQLJL5lMpgQySbYyFFMpL5An4GfsQUOG5JlB4zhDNfRIXt7HScuSQiFzcCbpRLGET+WQH6soiqPrOiOExGzbRgIKnXJg7e2OpVVD02N7Y3tVRXrV8/247TixYCCQR10qZTKJgCQpZm+vhkhv/6m8XnQ/DAAIAcRiMpaOR4h/xAhx4Wfc5VuWZTqOA1RVlhzHsz5jGEYR4D6HSBREGv8mflLDMmGcFzDGg5xxkwFmYYg5gFxUCEBKGMMYugxAxClDPqNQSPzenNaTIEYJpKpphHEUIXTsv9+rRzC1J6ANPX+PoioBwYicU58DcATMnj7QF5sZYEQJ4wKORhIMyznXIABiYyYAZT5gXM1kMoqgv6FqvqqqOOPYqtisnENf13XieR7RNB0DwJFt26L+UXyamB/0dt+h/mdt0sUmQyIrTWw+VVUzqVQaKxgzRca+a1sQISTGFUUVt23q2PSrcaPHrlBkaUQsmSh79dVX9xmj35RpD2BY0XC3oKBg5dy5c+NYxpqqqpSLI5wykxAqeZ47hFBKAOc29Yk4wkDatpxEIpGw05mXLMeyqU8Truv+NZ6KH+35Xg/3uYBz/xaEUPN9ttPzLM+yLM33ucu5b0aDUT5oUJRGo/kFg4cMQSpWbNU0hVQMxWIxV1F0EAzoPVhVBcMKA4fJsvzB7t27/5rxvD3J7hRTFJDcm0rhXrRprkHopdO+LEkUptPpJMbY5TyPMdbFAoFA0PO8Qb2+UZGsItxl+x953ieffMKHDh0KE4kEzmQyRByX4qhctmyODMDnYYH+Tfw+GvJly5ZJy5YtE8/Af+v84rj9XAmPuG/37t0Ci9e55557RJhV7nbdsEaIYBhqQYh0xkQlgxAAAoI0y0UsEJAlCCXCOZGhrWAX+1SlMiUKBhi7kDGdAxDFrrvH13UPZ5jJMR+iqkrIdV1X13WFUHKEoiiGpqksbdldCsaiZXmIOE4EQHRkKBQsSKZS4WAomJQl9Z8SAnFKiOH4ZGjQNE3bcdKEkZ0yxsdywk8HnJJwyDR6enpixPe7e7oTq3//4O+fr6qsXN29tzs6+Mih03PRb7iP0Q9gWPHHiy+5+HwE8TWaph3Zi5cKfdHTUmiqnsdd1zMoJVkDCgEojjfmuq4siCF2nvg7lqXs8ee6ti6ON9dxfA6hJiMEZVl1MILiWAsjBABCQNUVTdI0Dfa2KUeaptFIfp4iTifGAKSUEsd1QTQadWOxmNB9NaEGAABoKBTy4vG47/pU7HixaYQKQV3XFccllhBEECBLUWSSSCRZMBRktm0bYgyhdgpjUeiMmqJC285QSrmtaarveeLkpipj0AaAf8AYNyj1j2AM9CAEdkKIIULAwViop+g4OVuRLU5rDignYgtIDDAFcdTFIOuWkJzHAP0X55ADwEIIKQqUGIIMewBwCyGZSBgNUSRFZ1CwIggxSB3xO0c0xQjcwSFVEYB5EIO/YoARlGBUglIPwBQQzzVlFVoYS59wzjD3WIABygCXHQkhzhETCgmUVMVSVYnpekCs3dEAgqMcz6Eh0/yYcbozP3+I6rp2ggvDIxoNSmIDAJbQZDUCsHSMqmqa69tdmqQ6jHNVqIQMwoCuG3YymbYBxt2prtTHb737Fv3o/feHvL/zX3/4+KOPPtj+4gui+iNn1+cYVow8f/784YlUYjghTEEYC4u9B1AKPEqP7sWKTXJCMqIsWjAsxrhASCyMsTA4IgghC0lIHClHCwbCEkwyCiTIeVCSJNE0Qyi+wKdZ5bEAMYaFoaaqegwhBHzuH+c5/iCIUVJRdMf3fSkvL5q15TBGR1HGhI7LhcIpkMJ1I5hMJpMZM2Dmea7niMZ2GSszRJXliOu5/8RI6pEkCQHAdAiQxgAzKSGyomgBykgUA2QhhLp7a8tk13WG+D7RRJofQrKEMbAJ4R7nxIAQByUJCUZNiY2GkOQghAo45xbn3AQchThkGHGcEV+IITYA4kwwuFBxOYOIY45kJPsMMgwZRKIpMfGIKiEsjlrQ22APCV1c2ANCz0YYurKkWIxTodsKnFcPQswh5BhCTDgg3LWSiiRDsQ5uVgoTKgtrQoIIYSQjoYsxxrJ6ryzLWPSQMAOmtqe7G0Qi4ewhEw6Hgeu6++wUMb84PXVdB705G9nfxJoJvV7YLcJmMU0T+JSDYCgKKIfZZ8VvsVhM/GMfvPeem05n/vDsn7fntPvQIRk2Z9vh6w8k9LBDtYnPZiP1WbDTp09XhHX87/Q+YcFmrViR8qcoivpfEPxgRUWF/sknn/h9oBejRpXkmSYNxDIZRYM6h9C1HUfPIJQIUYQGKRB2S5KUYIwJPdJW1XCeJBHb87Awmo7kmOmYo08kSRJ6az6QOEVY1QAHHpaE0IeaoqgpLHHGgeIgTocRxodgiBNiPN8n+YSRAsC5ATnyOaAfY6xQhIjPOTQ4IwYHIEMB8JjHBgmJLPZGVmcGEAkmB4AfJbwbgAGKkKQT4hfouh52fV/kE1NDNyK2ZUUd3x2CMJYlzAlAvLs3OugAxvcKDk+l0mEMAUNI8gnxhc6tOo4dAAC6kUj0fcvKKLIsD6WURcTcmqblZ6yMHAwE0/F43COUdqXjiTjC8M7nX3opZ+Uxgp3+X2XYr8/qA0/+VwqIMnXG9Dzf9xCEtkMpFcxMviiv99RTTxUYEnzHjh3Z1lKCd4YPH64PGjSIxmKxiEIU5EleRqiDXV1dTJQXvfHGG9kmzLm8Bhg2l9QcGKvfKTDAsP1O4oEJckmBAYbNJTUHxup3CgwwbL+TeGCCXFJggGFzSc2BsfqdAgMM2+8kHpgglxQYYNhcUnNgrH6nwADD9juJBybIJQUGGDaX1BwYq98pMMCw/U7igQlySYEBhs0lNQfG6ncKDDBsv5N4YIJcUmCAYXMmQJzLAAABBklEQVRJzYGx+p0CAwzb7yQemCCXFBhg2FxSc2CsfqfAAMP2O4kHJsglBQYYNpfUHBir3ykwwLD9TuKBCXJJgQGGzSU1B8bqdwoMMGy/k3hgglxSYIBhc0nNgbH6nQIDDNvvJB6YIJcUGGDYXFJzYKx+p8AAw/Y7iQcmyCUFBhg2l9QcGKvfKTDAsP1O4oEJckmBAYbNJTUHxup3CgwwbL+TeGCCXFJggGFzSc2BsfqdAgMM2+8kHpgglxQYYNhcUnNgrH6nwADD9juJBybIJQUGGDaX1BwYq98pMMCw/U7igQlySYEBhs0lNQfG6ncKDDBsv5N4YIJcUmCAYXNJzYGx+p0C/x8Uk0x1KhmP8QAAAABJRU5ErkJggg=='

# Función para convertir la fecha
def formatear_fecha(fecha_str):
    
    if fecha_str:
        try:
            # Convertir la fecha de "DIA mes AÑO" a "AÑO-MES-DIA"
            fecha_obj = datetime.strptime(fecha_str, "%d %B %Y")
            return fecha_obj.strftime("%Y-%m-%d")
        except ValueError:
            # Si la fecha no es válida o no está en el formato esperado, devolver el valor original
            return fecha_str
    return ''