from flask import Flask, render_template, request, redirect, url_for, flash, session
from markupsafe import Markup
import requests
import datetime
from requests.auth import HTTPProxyAuth

app = Flask(__name__, static_folder='static')

app.secret_key = 'Aasd12'

import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('flask_app.log', maxBytes=1024 * 1024 * 100, backupCount=20)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s '
        '[in %(pathname)s:%(lineno)d]'
    ))
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('Flask application started')

# Importar blueprints
from depmedico import depmedico

# Departamento medico
app.register_blueprint(depmedico, url_prefix='/depmedico')

# Array para los usuarios del area médica
usuarios_area_medica = [
    {   
        'cedula': '1717243149',                    
        'nombre': 'MACIAS VERA GINA LUISANA',
        'rol': 'doctora2'
    },
    {
        'cedula': '0925808552',                    
        'nombre': 'REYES VERA KATHERINE NARCISA',
        'rol': 'doctora'  
    },
    {
        'cedula': '0910882604',                    
        'nombre': 'FATIMA GUERRERO',
        'rol': 'doctora'               
    },
    {
        'cedula': '0955624507',                    
        'nombre': 'RICARDO VELIZ',
        'rol': 'doctora'               
    },      
]

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # session['usuario_autenticado'] = True
        form_data = request.form.to_dict()
        errores = {}
    
        if 'usuarioSma' in request.form:
            cedula = request.form['usuarioSma']
            usuario = next((u for u in usuarios_area_medica if u['cedula'] == cedula), None)
            
            if usuario:
                session['nombreColaborador'] = usuario['nombre']
                session['rol'] = usuario['rol']
                if session['rol'] == 'doctora':
                    print('Ingresa la doctora')
                elif session['rol'] == 'doctora2':
                    print('Ingresa la doctora2')
                else:
                    session['rol'] = 'colaborador'  
                    print('Ingresa el colaborador')

            try:
                response = requests.post(
                    'https://192.168.137.16:47081/api/GTHLanbot',
                    headers={'AuthKey': 'jV+lYdQlv2IO0Gc1vZOeFomzl8eEt79s'},
                    params={'identificacion': cedula},
                    verify=False 
                )
                
                if response.status_code == 200:
                    data = response.json()
                    session['nombreColaborador'] = data.get('nombreColaborador')
                    session['token'] = data.get('token')
                    session['fechaHoraTopeToken'] = data.get('fechaHoraTopeToken')
                    session['correo'] = data.get('correo')
                    session['estatusColaborador'] = data.get('estatusColaborador')
                    session['ErrorID'] = data.get('ErrorID')
                    session['ErrorMessage'] = data.get('ErrorMessage')
                    session['cedula'] = cedula

                    app.logger.info(f'Token recibido: {session["token"]}')
                    app.logger.info(f'Fecha de expiración del token: {session["fechaHoraTopeToken"]}')

                    print(session['nombreColaborador'], session['token'], session['rol'], session['fechaHoraTopeToken'])

                    if session['estatusColaborador'] in ['ALTA', 'BAJA']:
                        flash(Markup(session["ErrorMessage"]))
                        session['show_full_form'] = True
                        return render_template('depmedico/depmedico_login.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))
                    else:
                        flash('Tu estatus no permite iniciar sesión')
                else:
                    flash('Datos no válidos o error en la conexión para departamento médico')
            except requests.exceptions.RequestException as e:
                flash('No se pudo establecer una conexión con la API para departamento médico.')
                app.logger.error(f'Error al conectarse a la API de departamento médico: {e}')
        elif 'idllamada' in request.form:
            user_token = request.form['idllamada']
            if user_token == session.get('token') and datetime.datetime.now() < datetime.datetime.strptime(session['fechaHoraTopeToken'], '%Y/%m/%d %H:%M:%S'):
                flash('Autenticación exitosa. Bienvenido!')
                session['usuario_autenticado'] = True
                return redirect(url_for('principal'))
            else:
                flash('Token inválido o expirado')
                return render_template('depmedico/depmedico_login.html', errores=errores, form_data=form_data, show_full_form=session.get('show_full_form', False))

    return render_template('depmedico/depmedico_login.html')
    
@app.route('/', methods=['GET', 'POST'])
def principal():
    if 'usuario_autenticado' not in session:
        return redirect(url_for('login'))

    form_data = session.get('form_data', {})
    errores = session.get('errores', {})
    cedula = session.get('cedula')
    
    # Verificar si es doctor o colaborador
    usuario = next((u for u in usuarios_area_medica if u['cedula'] == cedula), None)
    if usuario and (usuario['rol'] == 'doctora' or usuario['rol'] == 'doctora2'):
        template_name = 'depmedico/dash_ocupacional.html'
        print('Ingresa con rol doctora')
    else:
        template_name = 'depmedico/depmedico_colaborador.html'
        print('Ingresa con rol colaborador')
    
    # Asegurar que los datos necesarios están disponibles
    if 'usuario' not in session:
        session['usuario'] = session.get('nombreColaborador', 'Usuario sin nombre')
    
    usuario = session['usuario']
    app.logger.info(f'{usuario} Using template: {template_name} with role: {session.get("rol", "No role")}')
    
    return render_template(template_name, form_data=form_data, errores=errores)

@app.route('/logout')
def logout():
    session.clear()  # Limpia la sesión completamente
    return redirect(url_for('login'))

@app.route('/favicon.ico')
def favicon():
    return ('', 204)  # Retorna un estado 204 No Content

@app.errorhandler(Exception)
def handle_exception(e):
    # Puedes decidir hacer un log del error aquí si no lo estás haciendo en otro lado
    app.logger.error(f'Error inesperado: {str(e)}', exc_info=True)
    return render_template("error.html"), 500

@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=6002)